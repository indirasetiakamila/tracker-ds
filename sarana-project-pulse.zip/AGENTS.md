<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- All stage, checklist and derived-status logic lives in `src/lib/rules.ts` as pure functions (tested in `rules.test.ts`); UI never re-implements it. Why: one source of truth for progress, standup and validation.
- Activity history and task change logs are written by database triggers (`projects_log`, `tasks_log`, `todos_log`), never from the browser. Why: every change is logged regardless of client.
- Data is read via react-query hooks in `src/lib/data.ts`; one realtime channel in the app shell invalidates queries. Forms keep local state so live updates never wipe typing.
- Roles live in `user_roles` (checked with `has_role` / `has_any_role`), never on profiles. Why: prevents privilege escalation.
- Every person picker (PIC, AM, PM, next action owner, task engineer) reads the admin-managed `people` table via `PersonSelect`; project person fields store the name as text, tasks store `assignee_person` (plus `assignee` when the person has a login). Why: people can be listed before they ever sign in.
- Rich text fields (project `next_action`, task `description`) are stored as editor HTML; edit with `RichTextEditor`, render full text with `RichText` (DOMPurify-sanitized), and use `plainText()` from `src/lib/richtext.ts` for one-line/CSV views. Why: old plain-text rows and new HTML rows both display safely.
- The external MCP server lives in `src/lib/mcp/` (one tool factory per file, `make(dbFor)`). `/mcp` uses backend OAuth; `/api/public/mcp/$key` accepts per-assistant `srn_` keys (only SHA-256 hashes stored in `mcp_keys`), mints a normal session for the key owner and runs the same tools under their RLS. No delete tools. Why: assistants act with exactly the user's permissions either way.
- AI form quick fill goes through `aiFill` in `src/lib/ai-fill.functions.ts` (auth-required server fn, strict schema per form kind); forms merge results into local state and never auto-save. Why: one reviewed path for AI-extracted data.
- Assistant insights (from Grok routines via MCP `send_insight`) land in `assistant_insights` for human review on the AI Assistants Inbox; they never change projects/tasks directly, and rows older than 28 days are purged by an insert trigger (no pg_cron on this backend). Why: AI output is always reviewed before it touches the register.
- Sign-in is invite-only: `handle_new_user` refuses emails not active in `people` (except admin emails), and the `_authenticated` gate calls `is_registered()` once per session to sign out deactivated people. Why: any email domain can sign in, access is controlled by the admin Team list.
