import { SaranaDots, SaranaLogo } from "@/components/app/brand";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { oauthReturnPath } from "@/lib/oauth-return-path";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { next?: string } => (typeof s["next"] === "string" ? { next: s["next"] as string } : {}),
  head: () => ({
    meta: [
      { title: "Sign in | Sarana DS Register" },
      { name: "description", content: "Sign in to the Sarana Delivery team's DS Project Register." },
      { property: "og:title", content: "Sign in | Sarana DS Register" },
      { property: "og:description", content: "Sign in to the Sarana Delivery team's DS Project Register." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const { next } = Route.useSearch();
  const target = next ? oauthReturnPath(next) : "/minggu-ini";
  const go = () => { if (target === "/minggu-ini") navigate({ to: "/minggu-ini" }); else window.location.assign(target); };

  useEffect(() => {
    if (sessionStorage.getItem("sarana-denied")) { sessionStorage.removeItem("sarana-denied"); toast.error("This email isn't registered. Ask an admin to add you."); }
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session) go(); });
    const { data } = supabase.auth.onAuthStateChange((e, s) => { if (e === "SIGNED_IN" && s) go(); });
    return () => data.subscription.unsubscribe();
  }, [navigate, target]); // eslint-disable-line react-hooks/exhaustive-deps

  async function signIn() {
    setBusy(true);
    const r = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: next ? `${window.location.origin}/auth?next=${encodeURIComponent(target)}` : window.location.origin + "/auth",
      extraParams: { prompt: "select_account" },
    });
    if (r.error) { toast.error("Sign-in failed. This email isn't registered. Ask an admin to add you."); setBusy(false); return; }
    if (r.redirected) return;
    go();
  }

  return (
    <div className="grid min-h-screen bg-background md:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden flex-col justify-between overflow-hidden p-10 md:flex">
        <SaranaDots className="dot-in-plain absolute w-auto opacity-70" style={{ position: "absolute", bottom: -90, right: -150, height: 480 }} />
        <div className="relative font-serif text-2xl font-extrabold tracking-tight text-heading flex items-center gap-2"><SaranaLogo className="h-7 w-7" />Sarana</div>
        <h2 className="relative max-w-lg font-serif text-6xl font-extrabold leading-[0.95]">The project register for <span className="text-primary">Delivery.</span></h2>
        <p className="relative text-lg text-muted-foreground">One minute each week keeps everyone in step.</p>
      </div>
      <div className="flex items-center justify-center px-4 py-10">
        <motion.div initial={{ opacity: 0, y: 16, rotate: 1 }} animate={{ opacity: 1, y: 0, rotate: 0 }} className="w-full max-w-sm rounded-xl border bg-card p-8">
          <p className="eyebrow text-muted-foreground">Welcome back</p>
          <div className="mb-1 font-serif text-4xl font-extrabold leading-none text-heading mt-2">DS Project <span className="text-primary">Register</span></div>
          <p className="mb-6 text-sm text-muted-foreground">Weekly project updates in under a minute.</p>
          <Button className="w-full" size="lg" onClick={signIn} disabled={busy}>Sign in with Google</Button>
          <p className="mt-4 text-center text-xs text-muted-foreground">Registered team members only</p>
        </motion.div>
      </div>
    </div>
  );
}
