import { createFileRoute, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, Plug } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

type OAuthResult = { data: { redirect_url?: string; redirect_to?: string; client?: { name?: string; client_name?: string; redirect_uri?: string }; scope?: string; redirect_uri?: string } | null; error: { message: string } | null };
type OAuthApi = {
  getAuthorizationDetails: (id: string) => Promise<OAuthResult>;
  approveAuthorization: (id: string) => Promise<OAuthResult>;
  denyAuthorization: (id: string) => Promise<OAuthResult>;
};
const oauth = () => (supabase.auth as unknown as { oauth: OAuthApi }).oauth;

export const Route = createFileRoute("/.lovable/oauth/consent")({
  ssr: false,
  validateSearch: (s: Record<string, unknown>) => ({ authorization_id: typeof s["authorization_id"] === "string" ? (s["authorization_id"] as string) : "" }),
  head: () => ({ meta: [{ title: "Connect an app | Sarana DS" }, { name: "description", content: "Allow an AI assistant to access the DS Project Register on your behalf." }, { property: "og:title", content: "Connect an app | Sarana DS" }, { property: "og:description", content: "Allow an AI assistant to access the DS Project Register on your behalf." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  beforeLoad: async ({ search, location }) => {
    if (!search.authorization_id) throw new Error("The authorization link is incomplete.");
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth", search: { next: location.pathname + location.searchStr } });
  },
  loader: async ({ location }) => {
    const id = new URLSearchParams(location.search).get("authorization_id")!;
    const { data, error } = await oauth().getAuthorizationDetails(id);
    if (error) throw new Error(error.message);
    const immediate = data?.redirect_url ?? data?.redirect_to;
    if (immediate && !data?.client) throw redirect({ href: immediate });
    const { data: u } = await supabase.auth.getUser();
    return { details: data, email: u.user?.email ?? "" };
  },
  component: Consent,
  errorComponent: ({ error }) => (
    <main className="flex min-h-screen items-center justify-center p-6"><div className="max-w-md rounded-[2rem] bg-card p-8 text-center shadow-lift">
      <h1 className="mb-2 font-serif text-2xl font-bold">Unable to open this request</h1>
      <p className="text-sm text-muted-foreground">{error instanceof Error ? error.message : String(error)}. Try connecting again from the app.</p>
    </div></main>
  ),
});

function Consent() {
  const { details, email } = Route.useLoaderData();
  const { authorization_id } = Route.useSearch();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const name = details?.client?.name ?? details?.client?.client_name ?? "Application";
  const scopes = (details?.scope ?? "openid email profile").split(" ").filter(Boolean);
  const label: Record<string, string> = { openid: "Identify your account", email: "View your email address", profile: "View your basic profile" };

  async function decide(ok: boolean) {
    setBusy(true); setErr(null);
    const { data, error } = ok ? await oauth().approveAuthorization(authorization_id) : await oauth().denyAuthorization(authorization_id);
    if (error) { setBusy(false); setErr(error.message); return; }
    const to = data?.redirect_url ?? data?.redirect_to;
    if (!to) { setBusy(false); setErr("The server did not return a redirect URL."); return; }
    window.location.href = to;
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center bg-background p-6">
      <div className="w-full max-w-md relative rounded-xl border bg-card p-8">
        <span className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground"><Plug className="h-6 w-6" /></span>
        <h1 className="font-serif text-3xl font-bold leading-tight">Connect {name} to the DS Project Register</h1>
        <p className="mt-2 text-sm text-muted-foreground">{name} will be able to use register tools as <b className="text-heading">{email}</b>: read and create projects and tasks, and submit weekly updates.</p>
        {(details?.client?.redirect_uri ?? details?.redirect_uri) && <p className="mt-2 break-all text-xs text-muted-foreground">Return to: {details?.client?.redirect_uri ?? details?.redirect_uri}</p>}
        <ul className="my-5 space-y-2 text-sm">
          {scopes.map((s) => <li key={s} className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" />{label[s] ?? `Additional permission: ${s}`}</li>)}
        </ul>
        <p className="mb-5 rounded-2xl bg-powder/40 p-3 text-xs">Your existing permissions still apply. The assistant can only change what you are allowed to change.</p>
        {err && <p role="alert" className="mb-3 rounded-xl bg-danger-soft p-2 text-sm text-destructive">{err}</p>}
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" disabled={busy} onClick={() => decide(false)}>Cancel</Button>
          <Button className="flex-1" disabled={busy} onClick={() => decide(true)}>Allow</Button>
        </div>
      </div>
    </main>
  );
}
