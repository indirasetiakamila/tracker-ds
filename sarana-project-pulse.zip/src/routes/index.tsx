import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sarana DS Project Register" },
      { name: "description", content: "The Sarana Delivery team's project register: weekly updates, standups, priorities and engineering tasks." },
      { property: "og:title", content: "Sarana DS Project Register" },
      { property: "og:description", content: "The Sarana Delivery team's project register: weekly updates, standups, priorities and engineering tasks." },
    ],
  }),
  beforeLoad: () => { throw redirect({ to: "/minggu-ini" }); },
});
