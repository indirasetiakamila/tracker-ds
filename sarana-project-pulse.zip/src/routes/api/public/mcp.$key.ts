import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { createTanStackMcpHandler } from "@lovable.dev/mcp-js/stacks/tanstack";
import { hashKey, isKeyFormat, keyIsUsable } from "@/lib/mcp-keys";

// Per-isolate cache of short-lived sessions, keyed by key hash. Never logged or returned.
const sessions = new Map<string, { token: string; uid: string; exp: number }>();

const unauthorized = () => new Response(JSON.stringify({ error: "invalid or revoked key" }), { status: 401, headers: { "Content-Type": "application/json" } });

async function sessionForKey(key: string) {
  const hash = await hashKey(key);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: row } = await supabaseAdmin.from("mcp_keys").select("id, user_id, revoked_at").eq("key_hash", hash).maybeSingle();
  if (!keyIsUsable(row) || !row) { sessions.delete(hash); return null; }
  void supabaseAdmin.from("mcp_keys").update({ last_used_at: new Date().toISOString() }).eq("id", row.id);

  const cached = sessions.get(hash);
  if (cached && cached.uid === row.user_id && cached.exp - 60 > Date.now() / 1000) return cached;

  // Mint a normal session for the key owner so every query runs under their own RLS.
  const { data: u } = await supabaseAdmin.auth.admin.getUserById(row.user_id);
  const email = u?.user?.email;
  if (!email || u?.user?.banned_until) return null;
  const { data: link, error: linkErr } = await supabaseAdmin.auth.admin.generateLink({ type: "magiclink", email });
  if (linkErr || !link?.properties?.hashed_token) return null;
  const pub = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  const anon = createClient(process.env["SUPABASE_URL"]!, pub, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: v, error: vErr } = await anon.auth.verifyOtp({ token_hash: link.properties.hashed_token, type: "email" });
  if (vErr || !v.session) return null;
  const s = { token: v.session.access_token, uid: row.user_id, exp: v.session.expires_at ?? Date.now() / 1000 + 3000 };
  sessions.set(hash, s);
  return s;
}

async function handle({ request, params }: { request: Request; params: { key: string } }) {
  if (!isKeyFormat(params.key)) return unauthorized();
  const s = await sessionForKey(params.key);
  if (!s) return unauthorized();
  const [{ mcpForKeySession }, { clientWithToken }] = await Promise.all([import("@/lib/mcp/index"), import("@/lib/mcp/supabase")]);
  const handler = createTanStackMcpHandler(mcpForKeySession(clientWithToken(s.token), s.uid), {
    resourcePath: `/api/public/mcp/${params.key}`,
    trustForwardedHost: true,
    trustForwardedProto: true,
  });
  return handler({ request });
}

export const Route = createFileRoute("/api/public/mcp/$key")({
  server: { handlers: { ANY: handle } },
});
