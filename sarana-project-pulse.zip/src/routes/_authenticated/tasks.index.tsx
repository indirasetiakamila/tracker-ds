import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { DndContext, PointerSensor, TouchSensor, useDraggable, useDroppable, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { AlertOctagon, Bug, CircleDot, Clock, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { qk, taskPerson, usePeople, useProjects, useTasks, type Task } from "@/lib/data";
import { addDays, fmtDate, relTime, todayWIB } from "@/lib/rules";
import { Chip, Empty, StatCard, Initials, PageHeader, PrioBadge, TypeBadge } from "@/components/app/bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/tasks/")({
  head: () => ({ meta: [{ title: "Engineering tasks | Sarana DS" }, { name: "description", content: "Engineering task board for the DS team." }, { property: "og:title", content: "Engineering tasks | Sarana DS" }, { property: "og:description", content: "Engineering task board for the DS team." }] }),
  component: TasksPage,
});

const STATUSES = ["To do", "In progress", "In review", "Blocked", "Done"] as const;
type Status = (typeof STATUSES)[number];

function TasksPage() {
  const { data: tasks = [] } = useTasks();
  const { data: projects = [] } = useProjects();
  const { data: people = [] } = usePeople();
  const qc = useQueryClient();
  const today = todayWIB();
  const [view, setView] = useState<"board" | "list">("board");
  const [q, setQ] = useState(""); const [proj, setProj] = useState("all"); const [eng, setEng] = useState("all"); const [type, setType] = useState("all");
  const engOf = (t: Task) => taskPerson(t, people);
  const nameOf = (t: Task) => engOf(t)?.name ?? null;
  const clientOf = (id: string) => projects.find((p) => p.id === id)?.client ?? id;

  const list = useMemo(() => tasks.filter((t) => {
    if (proj !== "all" && t.project_id !== proj) return false;
    if (eng === "none" && engOf(t)) return false;
    if (eng !== "all" && eng !== "none" && engOf(t)?.id !== eng) return false;
    if (type !== "all" && t.type !== type) return false;
    if (q && !`${t.key} ${t.title} ${nameOf(t) ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }), [tasks, proj, eng, type, q, people]); // eslint-disable-line react-hooks/exhaustive-deps

  const open = tasks.filter((t) => t.status !== "Done");
  const counts = {
    open: open.length, blocked: tasks.filter((t) => t.status === "Blocked").length,
    overdue: open.filter((t) => t.due && t.due < today).length, bugs: open.filter((t) => t.type === "Bug" && (t.prio === "P1" || t.prio === "P2")).length,
  };

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }), useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 6 } }));
  async function onDragEnd(e: DragEndEvent) {
    const id = String(e.active.id); const to = e.over?.id as Status | undefined;
    const t = tasks.find((x) => x.id === id);
    if (!t || !to || t.status === to) return;
    const prev = qc.getQueryData<Task[]>(qk.tasks);
    qc.setQueryData<Task[]>(qk.tasks, (old) => old?.map((x) => (x.id === id ? { ...x, status: to } : x)));
    const { error } = await supabase.from("tasks").update({ status: to }).eq("id", id);
    if (error) { qc.setQueryData(qk.tasks, prev); toast.error("Could not move task: " + error.message); return; }
    toast.success(`${t.key}: ${t.status} → ${to}`);
  }

  return (
    <div>
      <PageHeader title="Engineering tasks" sub="All engineering tasks by project">
        <Button asChild><Link to="/tasks/baru" search={{ project: undefined }}><Plus className="mr-1 h-4 w-4" />Task</Link></Button>
      </PageHeader>
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4"><StatCard icon={CircleDot} label="Open" value={counts.open} /><StatCard icon={AlertOctagon} tone="danger" label="Blocked" value={counts.blocked} /><StatCard icon={Clock} tone="warning" label="Overdue" value={counts.overdue} /><StatCard icon={Bug} tone="danger" label="Bug P1/P2" value={counts.bugs} /></div>
      <div className="mb-4 flex flex-col gap-2 lg:flex-row lg:items-center">
        <Input placeholder="Search key, title, engineer" value={q} onChange={(e) => setQ(e.target.value)} className="bg-card lg:max-w-xs" />
        <div className="grid grid-cols-3 gap-2 lg:flex">
          <Select value={proj} onValueChange={setProj}><SelectTrigger className="bg-card lg:w-44"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="all">All projects</SelectItem>{projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.client}</SelectItem>)}</SelectContent></Select>
          <Select value={eng} onValueChange={setEng}><SelectTrigger className="bg-card lg:w-44"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="all">All engineers</SelectItem><SelectItem value="none">Unassigned</SelectItem>{people.filter((p) => p.title === "engineer" || p.title === "lead").map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent></Select>
          <Select value={type} onValueChange={setType}><SelectTrigger className="bg-card lg:w-36"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="all">All types</SelectItem>{["Feature", "Bug", "Improvement", "Chore"].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="flex gap-1.5 lg:ml-auto"><Chip active={view === "board"} onClick={() => setView("board")}>Board</Chip><Chip active={view === "list"} onClick={() => setView("list")}>List</Chip></div>
      </div>

      {tasks.length === 0 ? <Empty title="No tasks yet">Engineering tasks will appear here by project. Select "+ Task" to create your first task.</Empty> : view === "board" ? (
        <DndContext sensors={sensors} onDragEnd={onDragEnd}>
          <div className="-mx-4 overflow-x-auto px-4 pb-4 md:mx-0 md:px-0">
            <div className="flex gap-3">
              {STATUSES.map((s) => {
                const col = list.filter((t) => t.status === s && (s !== "Done" || (t.done_at && t.done_at.slice(0, 10) >= addDays(today, -14))));
                return (
                  <Column key={s} id={s} title={s} count={col.length} hours={col.reduce((a, t) => a + Number(t.estimate_hours ?? 0), 0)}>
                    {col.map((t) => <TaskCard key={t.id} t={t} client={clientOf(t.project_id)} assignee={nameOf(t)} today={today} />)}
                  </Column>
                );
              })}
            </div>
          </div>
        </DndContext>
      ) : (
        <div className="overflow-x-auto card-soft">
          <table className="w-full text-sm">
            <thead className="border-b bg-muted/50 text-xs text-muted-foreground"><tr>{["Key", "Title", "Project", "Type", "Prio", "Status", "Engineer", "Est", "Due", "Update"].map((h) => <th key={h} className="px-3 py-2 text-left font-semibold whitespace-nowrap">{h}</th>)}</tr></thead>
            <tbody>
              {list.map((t) => (
                <ListRow key={t.id} t={t} client={clientOf(t.project_id)} assignee={nameOf(t)} today={today} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ListRow({ t, client, assignee, today }: { t: Task; client: string; assignee: string | null; today: string }) {
  const navigate = useNavigate();
  return (
    <tr onClick={() => navigate({ to: "/tasks/$key", params: { key: t.key } })} className="cursor-pointer border-b last:border-0 hover:bg-accent/50">
      <td className="px-3 py-2 font-mono text-xs">{t.key}</td><td className="max-w-64 truncate px-3 py-2 font-medium">{t.title}</td>
      <td className="px-3 py-2 whitespace-nowrap">{client}</td><td className="px-3 py-2"><TypeBadge type={t.type} /></td><td className="px-3 py-2"><PrioBadge prio={t.prio} /></td>
      <td className="px-3 py-2 whitespace-nowrap">{t.status}</td><td className="px-3 py-2 whitespace-nowrap">{assignee ?? <span className="text-muted-foreground">Unassigned</span>}</td>
      <td className="px-3 py-2">{t.estimate_hours ? `${t.estimate_hours}h` : ""}</td>
      <td className={cn("px-3 py-2 whitespace-nowrap", t.due && t.due < today && t.status !== "Done" && "font-semibold text-destructive")}>{fmtDate(t.due)}</td>
      <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{relTime(t.updated_at)}</td>
    </tr>
  );
}

function Column({ id, title, count, hours, children }: { id: string; title: string; count: number; hours: number; children: React.ReactNode }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div ref={setNodeRef} className={cn("w-64 shrink-0 rounded-lg bg-muted/70 p-2 transition-colors", isOver && "bg-primary-soft", id === "Blocked" && "bg-danger-soft/60")}>
      <div className="mb-2 flex items-center justify-between px-1 text-sm"><span className="font-bold text-heading">{title} <span className="text-muted-foreground">{count}</span></span><span className="text-xs text-muted-foreground">{hours}h</span></div>
      <div className="min-h-16 space-y-2">{children}</div>
    </div>
  );
}

function TaskCard({ t, client, assignee, today }: { t: Task; client: string; assignee: string | null; today: string }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: t.id });
  const navigate = useNavigate();
  return (
    <div ref={setNodeRef} {...attributes} {...listeners}
      style={transform ? { transform: `translate(${transform.x}px, ${transform.y}px)` } : undefined}
      onClick={() => !isDragging && navigate({ to: "/tasks/$key", params: { key: t.key } })}
      className={cn("cursor-grab touch-none card-soft p-3.5 text-sm", isDragging && "z-50 opacity-80 shadow-lg")}>
      <div className="flex items-center gap-1.5"><span className="font-mono text-[11px] text-muted-foreground">{t.key}</span><TypeBadge type={t.type} /><span className="ml-auto"><PrioBadge prio={t.prio} /></span></div>
      <div className="mt-1 font-medium text-heading">{t.title}</div>
      <div className="mt-1 truncate text-xs text-muted-foreground">{client}</div>
      <div className="mt-2 flex items-center gap-2 text-xs">
        {t.estimate_hours ? <span>{t.estimate_hours}h</span> : null}
        {t.due && <span className={cn(t.due < today && t.status !== "Done" ? "font-semibold text-destructive" : "text-muted-foreground")}>{fmtDate(t.due)}</span>}
        <span className="ml-auto">{assignee ? <Initials name={assignee} /> : <span className="text-muted-foreground">Unassigned</span>}</span>
      </div>
    </div>
  );
}
