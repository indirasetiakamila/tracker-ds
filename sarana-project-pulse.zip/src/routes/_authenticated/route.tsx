import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/app/AppShell";

// Checked once per signed-in user per page load: only emails on the admin Team list may stay in.
let checkedFor: string | null = null;

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
    const uid = data.session.user.id;
    if (checkedFor !== uid) {
      const { data: ok, error } = await supabase.rpc("is_registered");
      if (!error && ok === false) {
        await supabase.auth.signOut();
        sessionStorage.setItem("sarana-denied", "1");
        throw redirect({ to: "/auth" });
      }
      checkedFor = uid;
    }
  },
  component: () => (
    <AppShell>
      <Outlet />
    </AppShell>
  ),
});
