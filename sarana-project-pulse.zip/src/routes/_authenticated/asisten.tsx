import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Bot, Check, Clock, Copy, Inbox, KeyRound, Lightbulb, Plug, PlugZap, ShieldAlert, Sparkles, X, ChevronDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { createMcpKey } from "@/lib/mcp-keys.functions";
import { PageHeader } from "@/components/app/bits";
import { RichText } from "@/components/app/RichText";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useInsights, isOpen, type Insight } from "@/lib/insights";
import { addDays, mondayOf, relTime, todayWIB, weekBucket, fmtDate } from "@/lib/rules";
import { useUserId } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/asisten")({
  head: () => ({
    meta: [
      { title: "AI Assistants | Sarana DS" },
      { name: "description", content: "Review insights and actions from Grok, and manage assistant connections to the DS Project Register." },
      { property: "og:title", content: "AI Assistants | Sarana DS" },
      { property: "og:description", content: "Review insights and actions from Grok, and manage assistant connections to the DS Project Register." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>) => ({ tab: s["tab"] === "keys" ? ("keys" as const) : undefined }),
  component: Asisten,
});

const fmt = (d: string | null) => (d ? new Date(d).toLocaleString("en-GB", { timeZone: "Asia/Jakarta", dateStyle: "medium", timeStyle: "short" }) : "never");

function CopyBox({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="mb-1 text-xs font-semibold text-muted-foreground">{label}</p>
      <div className="flex items-stretch gap-2">
        <code className="flex-1 whitespace-pre-wrap break-all rounded-lg border bg-background px-4 py-3 font-mono text-xs leading-relaxed">{value}</code>
        <Button type="button" variant="outline" size="icon" className="h-auto w-12 shrink-0" aria-label={`Copy ${label}`}
          onClick={() => { void navigator.clipboard.writeText(value); toast.success("Copied"); }}>
          <Copy className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

const routinePrompt = (url: string) => `Add a custom MCP server called Sarana at ${url}

Routine: every weekday at 17:00 WIB, read today's WhatsApp updates from the client groups. For each meaningful item, call send_insight once:
- kind "insight" for news, risks or client sentiment; kind "action" for something a person should do.
- Link the project (call list_projects to find the DS id), suggest an owner from list_people and a due date when clear.
- Set source to the group name and date.
Before sending, call list_insights and skip anything already sent, accepted or dismissed.`;

function Asisten() {
  const { tab } = Route.useSearch();
  const navigate = useNavigate({ from: "/asisten" });
  const insights = useInsights();
  const open = (insights.data ?? []).filter((i) => isOpen(i)).length;
  const current = tab ?? "inbox";
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader art="inbox" icon={Bot} title="AI Assistants" sub="Review what Grok finds, and manage who is connected" />
      <div className="mb-6 inline-flex rounded-lg border bg-muted p-1">
        {([["inbox", "Inbox", Inbox], ["keys", "Connections", Plug]] as const).map(([k, l, I]) => (
          <button key={k} onClick={() => navigate({ search: { tab: k === "keys" ? "keys" : undefined } })}
            className={`flex items-center gap-2 rounded-md px-4 py-1.5 text-sm font-semibold transition ${current === k ? "bg-card text-heading shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
            <I className="h-4 w-4" /> {l}
            {k === "inbox" && open > 0 && <span className="rounded-full bg-primary px-1.5 text-[11px] text-primary-foreground">{open}</span>}
          </button>
        ))}
      </div>
      {current === "inbox" ? <InboxTab /> : <KeysTab />}
    </div>
  );
}

// ---------------- Inbox ----------------
const WEEK_LABEL = ["This week", "Last week", "2 weeks ago", "3 weeks ago"];
const STATUS_STYLE: Record<string, string> = {
  accepted: "bg-success/15 text-success", applied: "bg-primary-soft text-primary", dismissed: "bg-muted text-muted-foreground", snoozed: "bg-warning/15 text-warning",
};

function InboxTab() {
  const qc = useQueryClient();
  const uid = useUserId();
  const navigate = useNavigate();
  const q = useInsights();
  const today = todayWIB();
  const projects = useQuery({
    queryKey: ["insight-projects"],
    queryFn: async () => { const { data } = await supabase.from("projects").select("id, client, project"); return data ?? []; },
    staleTime: 60_000,
  });
  const pname = (id: string | null) => { const p = projects.data?.find((x) => x.id === id); return p ? `${p.client} · ${p.project}` : id ?? "No project"; };

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const patch = { status, reviewed_by: uid ?? null, reviewed_at: new Date().toISOString(), snoozed_until: status === "snoozed" ? addDays(mondayOf(today), 7) : null };
      qc.setQueryData<Insight[]>(["insights"], (old) => old?.map((i) => (i.id === id ? { ...i, ...patch } : i)));
      const { error } = await supabase.from("assistant_insights").update(patch).eq("id", id);
      if (error) throw error;
    },
    onError: (e: Error) => toast.error(e.message),
    onSettled: () => qc.invalidateQueries({ queryKey: ["insights"] }),
  });

  function apply(i: Insight) {
    setStatus.mutate({ id: i.id, status: "applied" });
    if (i.kind === "action") navigate({ to: "/tasks/baru", search: { project: i.project_id ?? undefined } });
    else if (i.project_id) navigate({ to: "/proyek/$id", params: { id: i.project_id } });
  }

  if (q.isLoading) return <p className="text-sm text-muted-foreground">Loading...</p>;
  const items = q.data ?? [];
  if (!items.length) return (
    <div className="rounded-xl border bg-card p-10 text-center shadow-card">
      <Sparkles className="mx-auto mb-3 h-8 w-8 text-primary" />
      <p className="font-semibold text-heading">Nothing from your assistants yet</p>
      <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">Connect Grok with a key and give it the routine message. Insights and actions it finds in WhatsApp land here for your review.</p>
      <Button asChild variant="outline" className="mt-4"><Link to="/asisten" search={{ tab: "keys" }}>Set up a connection</Link></Button>
    </div>
  );

  const weeks = [0, 1, 2, 3].map((w) => items.filter((i) => weekBucket(i.created_at.slice(0, 10), today) === w));
  return (
    <div className="space-y-8">
      {weeks.map((list, w) => {
        if (!list.length) return null;
        const c = (s: string) => list.filter((i) => (s === "new" ? isOpen(i, today) : i.status === s)).length;
        const groups = new Map<string, Insight[]>();
        for (const i of list) { const k = i.project_id ?? ""; groups.set(k, [...(groups.get(k) ?? []), i]); }
        return (
          <WeekSection key={w} label={WEEK_LABEL[w]!} from={addDays(mondayOf(today), -7 * w)} counts={{ new: c("new"), accepted: c("accepted"), applied: c("applied"), dismissed: c("dismissed") }} defaultOpen={w === 0 || c("new") > 0}>
            {[...groups.entries()].map(([pid, rows]) => (
              <div key={pid || "none"} className="space-y-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{pid ? pname(pid) : "No project"}</p>
                {rows.map((i) => <InsightCard key={i.id} i={i} today={today} onStatus={(s) => setStatus.mutate({ id: i.id, status: s })} onApply={() => apply(i)} />)}
              </div>
            ))}
          </WeekSection>
        );
      })}
      <p className="text-center text-xs text-muted-foreground">Items are kept for 4 weeks.</p>
    </div>
  );
}

function WeekSection({ label, from, counts, defaultOpen, children }: { label: string; from: string; counts: Record<string, number>; defaultOpen: boolean; children: React.ReactNode }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section>
      <button onClick={() => setOpen(!open)} className="mb-3 flex w-full flex-wrap items-center gap-3 text-left">
        <ChevronDown className={`h-4 w-4 transition ${open ? "" : "-rotate-90"}`} />
        <h2 className="text-lg font-bold text-heading">{label}</h2>
        <span className="text-xs text-muted-foreground">{fmtDate(from)} to {fmtDate(addDays(from, 6))}</span>
        <span className="ml-auto flex gap-2 text-xs">
          {counts["new"] ? <span className="rounded-full bg-primary px-2 py-0.5 font-semibold text-primary-foreground">{counts["new"]} to review</span> : null}
          <span className="text-muted-foreground">{counts["accepted"]} accepted · {counts["applied"]} applied · {counts["dismissed"]} dismissed</span>
        </span>
      </button>
      {open && <div className="space-y-5">{children}</div>}
    </section>
  );
}

function InsightCard({ i, today, onStatus, onApply }: { i: Insight; today: string; onStatus: (s: string) => void; onApply: () => void }) {
  const pending = isOpen(i, today);
  const isAction = i.kind === "action";
  return (
    <div className={`rounded-xl border bg-card p-4 shadow-card transition ${pending ? "" : "opacity-70"}`}>
      <div className="flex items-start gap-3">
        <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${isAction ? "bg-primary text-primary-foreground" : "bg-primary-soft text-primary"}`}>
          {isAction ? <PlugZap className="h-4 w-4" /> : <Lightbulb className="h-4 w-4" />}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wide text-primary">{isAction ? "Action" : "Insight"}</span>
            {i.confidence && <span className="text-[11px] text-muted-foreground">{i.confidence} confidence</span>}
            {!pending && <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold capitalize ${STATUS_STYLE[i.status] ?? ""}`}>{i.status}{i.status === "snoozed" && i.snoozed_until ? ` until ${fmtDate(i.snoozed_until)}` : ""}</span>}
          </div>
          <p className="mt-0.5 font-semibold text-heading">{i.title}</p>
          {i.body_html && <div className="mt-1 text-sm"><RichText value={i.body_html} /></div>}
          <p className="mt-2 text-xs text-muted-foreground">
            {[i.source, i.suggested_owner && `Owner: ${i.suggested_owner}`, i.suggested_due && `Due ${fmtDate(i.suggested_due)}`, relTime(i.created_at), i.reviewed_at && `Reviewed ${relTime(i.reviewed_at)}`].filter(Boolean).join(" · ")}
          </p>
        </div>
      </div>
      {pending && (
        <div className="mt-3 flex flex-wrap justify-end gap-2">
          <Button size="sm" variant="ghost" onClick={() => onStatus("dismissed")}><X className="h-4 w-4" /> Dismiss</Button>
          <Button size="sm" variant="ghost" onClick={() => onStatus("snoozed")}><Clock className="h-4 w-4" /> Next week</Button>
          <Button size="sm" variant="outline" onClick={() => onStatus("accepted")}><Check className="h-4 w-4" /> Accept</Button>
          {(isAction || i.project_id) && <Button size="sm" onClick={onApply}><Sparkles className="h-4 w-4" /> {isAction ? "Create task" : "Open project"}</Button>}
        </div>
      )}
    </div>
  );
}

// ---------------- Connections ----------------
function KeysTab() {
  const qc = useQueryClient();
  const create = useServerFn(createMcpKey);
  const [name, setName] = useState("Grok");
  const [fresh, setFresh] = useState<{ name: string; url: string } | null>(null);
  const [confirm, setConfirm] = useState<{ id: string; name: string } | null>(null);
  const [showOld, setShowOld] = useState(false);

  const keys = useQuery({
    queryKey: ["mcp_keys"],
    queryFn: async () => {
      const { data, error } = await supabase.from("mcp_keys").select("id, name, created_at, last_used_at, revoked_at").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const make = useMutation({
    mutationFn: async (n: string) => (await create({ data: { name: n } })).key,
    onSuccess: async (key, n) => {
      setFresh({ name: n.trim(), url: `${window.location.origin}/api/public/mcp/${key}` });
      await qc.invalidateQueries({ queryKey: ["mcp_keys"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const revoke = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("mcp_keys").update({ revoked_at: new Date().toISOString() }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: async () => { toast.success("Disconnected"); setConfirm(null); await qc.invalidateQueries({ queryKey: ["mcp_keys"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const active = (keys.data ?? []).filter((k) => !k.revoked_at);
  const old = (keys.data ?? []).filter((k) => k.revoked_at);

  return (
    <>
      <section className="rounded-xl border bg-card shadow-card">
        <div className="space-y-4 p-6">
          <p className="text-sm leading-relaxed text-muted-foreground">
            Create one key per assistant. Assistants can view projects, tasks and the team, create projects and tasks, submit weekly updates, change task status and send insights to your inbox, with exactly your permissions. They cannot delete anything.
          </p>
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (name.trim()) make.mutate(name); }}>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={60} placeholder="Assistant name, e.g. Grok" className="h-11" />
            <Button type="submit" className="h-11 px-6" disabled={!name.trim() || make.isPending}>
              <KeyRound className="h-4 w-4" /> {make.isPending ? "Creating..." : "Create key"}
            </Button>
          </form>
        </div>
        {fresh && (
          <div className="space-y-4 border-t bg-secondary/40 p-6">
            <p className="font-semibold text-heading">Copy it now. This key will not be shown again.</p>
            <CopyBox label="MCP server URL (includes your key)" value={fresh.url} />
            <CopyBox label={`Message for ${fresh.name} (connection + daily WhatsApp routine)`} value={routinePrompt(fresh.url)} />
            <p className="flex items-start gap-2 text-xs text-muted-foreground">
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
              Anyone with this URL can read and update the register on your behalf. Keep it private and disconnect it when no longer needed.
            </p>
          </div>
        )}
      </section>

      <h2 className="mb-3 mt-8 text-xl font-bold text-heading">Connected assistants</h2>
      <div className="space-y-2">
        {keys.isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {!keys.isLoading && active.length === 0 && <p className="text-sm text-muted-foreground">No assistants connected.</p>}
        {active.map((k) => (
          <div key={k.id} className="flex items-center gap-3 rounded-xl border bg-card px-4 py-3 shadow-card">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary-soft text-primary"><Bot className="h-4 w-4" /></div>
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-2 font-semibold">
                {k.name}
                {k.last_used_at
                  ? <span className="flex items-center gap-1 rounded-full bg-success/15 px-2 py-0.5 text-[11px] font-semibold text-success"><span className="h-1.5 w-1.5 rounded-full bg-success" />Connected</span>
                  : <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">Never used</span>}
              </p>
              <p className="text-xs text-muted-foreground">Created {fmt(k.created_at)} · {k.last_used_at ? `Last used ${relTime(k.last_used_at)}` : "Not used yet"}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setConfirm({ id: k.id, name: k.name })}>
              <Plug className="h-4 w-4" /> Disconnect
            </Button>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-xl border border-dashed p-4 text-xs leading-relaxed text-muted-foreground">
        <p className="font-semibold text-foreground">Disconnecting</p>
        Disconnect here and the assistant loses access at once; its URL stops working. To tidy up, also remove the Sarana server from the assistant's own settings (in Grok: Settings, Connectors, Sarana, Remove). To reconnect later, create a new key.
      </div>

      {old.length > 0 && (
        <div className="mt-6">
          <button onClick={() => setShowOld(!showOld)} className="flex items-center gap-1 text-sm font-semibold text-muted-foreground">
            <ChevronDown className={`h-4 w-4 transition ${showOld ? "" : "-rotate-90"}`} /> Disconnected ({old.length})
          </button>
          {showOld && (
            <div className="mt-2 space-y-2">
              {old.map((k) => (
                <div key={k.id} className="flex items-center gap-3 rounded-xl border bg-muted/40 px-4 py-2.5 text-sm text-muted-foreground">
                  <Bot className="h-4 w-4" /> <span className="font-semibold">{k.name}</span>
                  <span className="ml-auto text-xs">Disconnected {fmt(k.revoked_at)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <AlertDialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Disconnect {confirm?.name}?</AlertDialogTitle>
            <AlertDialogDescription>{confirm?.name} will lose access immediately. You can connect again with a new key.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); if (confirm) revoke.mutate(confirm.id); }} disabled={revoke.isPending}>Disconnect</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
