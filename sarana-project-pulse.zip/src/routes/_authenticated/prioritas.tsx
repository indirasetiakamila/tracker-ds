import { createFileRoute, Link } from "@tanstack/react-router";
import { plainText } from "@/lib/richtext";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowUp, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { optimistic, patchRows, qk, useMe, useProfiles, useProjects, useTodos, type Todo } from "@/lib/data";
import { addDays, daysOverdue, fmtDate, isActive, todayWIB } from "@/lib/rules";
import { Empty, PageHeader , ClientLogo } from "@/components/app/bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/prioritas")({
  head: () => ({ meta: [{ title: "Today's Priorities | Sarana DS" }, { name: "description", content: "Daily priorities for the DS team." }, { property: "og:title", content: "Today's Priorities | Sarana DS" }, { property: "og:description", content: "Daily priorities for the DS team." }] }),
  component: Prioritas,
});

const DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const dayLabel = (d: string) => `${DAY[new Date(d + "T00:00:00Z").getUTCDay()]}, ${fmtDate(d)}`;

function Prioritas() {
  return (
    <div>
      <PageHeader title="Today's Priorities" sub={dayLabel(todayWIB())} />
      <Tabs defaultValue="saya">
        <TabsList><TabsTrigger value="saya">Mine</TabsTrigger><TabsTrigger value="tim">Team</TabsTrigger></TabsList>
        <TabsContent value="saya"><Mine /></TabsContent>
        <TabsContent value="tim"><Team /></TabsContent>
      </Tabs>
    </div>
  );
}

function Mine() {
  const { uid, me } = useMe();
  const { data: todos = [] } = useTodos();
  const { data: projects = [] } = useProjects();
  const qc = useQueryClient();
  const today = todayWIB();
  const [text, setText] = useState("");
  const [proj, setProj] = useState("none");
  const refresh = () => qc.invalidateQueries({ queryKey: qk.todos });

  const mine = todos.filter((t) => t.owner === uid);
  const todayList = mine.filter((t) => t.date === today).sort((a, b) => a.sort_order - b.sort_order);
  const carry = mine.filter((t) => !t.done && t.date < today && t.date >= addDays(today, -14)).sort((a, b) => b.date.localeCompare(a.date));
  const myProjects = projects.filter((p) => isActive(p) && p.pic === me?.pic_name);
  const linkedToday = new Set(todayList.map((t) => t.project_id));
  const suggestions = myProjects.filter((p) => !linkedToday.has(p.id) && p.next_action && (p.health === "Red" || daysOverdue(p, today) > 0 || (p.next_action_due && p.next_action_due <= addDays(today, 2))));

  async function add(t: string, project_id: string | null) {
    if (!t.trim() || !uid) return;
    const max = Math.max(0, ...todayList.map((x) => x.sort_order));
    const { error } = await supabase.from("todos").insert({ owner: uid, date: today, text: t.trim(), project_id, sort_order: max + 1 });
    if (error) { toast.error(error.message); return; }
    toast.success("Priority added"); refresh();
  }
  async function upd(id: string, patch: Partial<Todo>, msg: string) {
    try { await optimistic<Todo>(qk.todos, patchRows([id], patch), () => supabase.from("todos").update(patch).eq("id", id), [id]); toast.success(msg); }
    catch (e) { toast.error((e as Error).message); }
  }
  async function moveUp(i: number) {
    if (i === 0) return;
    const a = todayList[i], b = todayList[i - 1];
    if (!a || !b) return;
    const sa = a.sort_order, sb = b.sort_order;
    try {
      await optimistic<Todo>(qk.todos, patchRows([a.id, b.id], (r) => ({ sort_order: r.id === a.id ? sb : sa })),
        async () => { const [x, y] = await Promise.all([supabase.from("todos").update({ sort_order: sb }).eq("id", a.id), supabase.from("todos").update({ sort_order: sa }).eq("id", b.id)]); return { error: x.error ?? y.error }; }, [a.id, b.id]);
    } catch (e) { toast.error((e as Error).message); }
  }
  async function carryOne(t: Todo) { await upd(t.id, { date: today, carried_count: t.carried_count + 1, sort_order: 999 }, "Moved to today"); }
  async function carryAll() {
    const ids = carry.map((t) => t.id); const n = carry.length;
    try {
      await optimistic<Todo>(qk.todos, patchRows(ids, (r) => ({ date: today, carried_count: r.carried_count + 1, sort_order: 999 })),
        async () => { const rs = await Promise.all(carry.map((t) => supabase.from("todos").update({ date: today, carried_count: t.carried_count + 1, sort_order: 999 }).eq("id", t.id))); return { error: rs.find((r) => r.error)?.error ?? null }; }, ids);
      toast.success(`${n} items moved to today`);
    } catch (e) { toast.error((e as Error).message); }
  }

  const days = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
  const clientOf = (id: string | null) => projects.find((p) => p.id === id)?.client;

  return (
    <div className="mt-4 grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
      <div className="min-w-0 space-y-5">
        <div className="card-soft p-4">
          <form className="flex flex-col gap-2 sm:flex-row" onSubmit={(e) => { e.preventDefault(); add(text, proj === "none" ? null : proj); setText(""); }}>
            <Input placeholder="What will you focus on today?" value={text} onChange={(e) => setText(e.target.value)} />
            <Select value={proj} onValueChange={setProj}>
              <SelectTrigger className="sm:w-48"><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="none">No project</SelectItem>{myProjects.map((p) => <SelectItem key={p.id} value={p.id}>{p.client}</SelectItem>)}</SelectContent>
            </Select>
            <Button type="submit">Add</Button>
          </form>
          {todayList.length > 5 && <p className="mt-2 rounded-md bg-warning-soft px-3 py-2 text-xs font-semibold text-warning-foreground">You have {todayList.length} items. Keep your list to five or fewer and focus on what matters most.</p>}
          <ul className="mt-3 divide-y">
            {todayList.length === 0 && <li className="py-4 text-center text-sm text-muted-foreground">No priorities for today yet. Add one above and press Enter.</li>}
            {todayList.map((t, i) => (
              <li key={t.id} className="flex items-center gap-3 py-2">
                <Checkbox checked={t.done} onCheckedChange={(v) => upd(t.id, { done: !!v }, v ? "Completed" : "Reopened")} />
                <div className="min-w-0 flex-1">
                  <div className={cn("text-sm", t.done && "text-muted-foreground line-through")}>{t.text}</div>
                  <div className="flex gap-2 text-[11px] text-muted-foreground">
                    {t.project_id && <Link to="/proyek/$id" params={{ id: t.project_id }} className="text-primary">{clientOf(t.project_id)}</Link>}
                    {t.carried_count > 0 && <span className="text-warning-foreground dark:text-warning">carried over {t.carried_count} times</span>}
                  </div>
                </div>
                <button aria-label="Move up" onClick={() => moveUp(i)} disabled={i === 0} className="text-muted-foreground disabled:opacity-30"><ArrowUp className="h-4 w-4" /></button>
                <button aria-label="Delete" onClick={async () => { try { await optimistic<Todo>(qk.todos, (rs) => rs.filter((r) => r.id !== t.id), () => supabase.from("todos").delete().eq("id", t.id), [t.id]); toast.success("Deleted"); } catch (e) { toast.error((e as Error).message); } }} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
              </li>
            ))}
          </ul>
        </div>

        {carry.length > 0 && (
          <div className="card-soft p-4">
            <div className="mb-2 flex items-center justify-between gap-2"><h2 className="font-bold">Unfinished from previous days</h2><Button size="sm" variant="outline" onClick={carryAll}>Move all to today</Button></div>
            <ul className="divide-y">
              {carry.map((t) => (
                <li key={t.id} className="flex items-center gap-3 py-2 text-sm">
                  <span className="w-24 shrink-0 text-xs text-muted-foreground">{dayLabel(t.date)}</span>
                  <span className="min-w-0 flex-1 truncate">{t.text}</span>
                  <Button size="sm" variant="ghost" onClick={() => carryOne(t)}>Move to today</Button>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="card-soft p-4">
          <h2 className="mb-3 font-bold">Last 7 days</h2>
          <div className="flex h-28 items-end gap-2">
            {days.map((d) => {
              const l = mine.filter((t) => t.date === d); const dn = l.filter((t) => t.done).length; const max = Math.max(5, ...days.map((x) => mine.filter((t) => t.date === x).length));
              return (
                <div key={d} className="flex flex-1 flex-col items-center gap-1">
                  <div className="relative w-full rounded-t bg-muted" style={{ height: `${(l.length / max) * 80}px` }}>
                    <div className="absolute bottom-0 w-full rounded-t bg-primary" style={{ height: `${l.length ? (dn / l.length) * 100 : 0}%` }} />
                  </div>
                  <span className="text-[10px] text-muted-foreground">{dn}/{l.length}</span>
                  <span className="text-[10px] font-semibold">{DAY[new Date(d + "T00:00:00Z").getUTCDay()]}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="card-soft p-4 self-start">
        <h2 className="mb-1 font-bold">Suggested from your projects</h2>
        <p className="mb-3 text-xs text-muted-foreground">Projects marked Red, overdue or due within 2 days</p>
        {suggestions.length === 0 && <p className="text-sm text-muted-foreground">No suggestions. Your projects are on track.</p>}
        <ul className="space-y-2">
          {suggestions.map((p) => (
            <li key={p.id} className="rounded-md border p-2 text-sm">
              <div className="flex items-center gap-2 font-semibold text-heading"><ClientLogo client={p.client} className="h-6 w-6 text-[9px]" />{p.client}</div>
              <div className="text-muted-foreground">{plainText(p.next_action)}</div>
              <Button size="sm" variant="secondary" className="mt-1" onClick={() => add(plainText(p.next_action), p.id)}>+ Priority</Button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Team() {
  const { data: todos = [] } = useTodos();
  const { data: profiles = [] } = useProfiles();
  const today = todayWIB();
  const people = profiles.filter((p) => todos.some((t) => t.owner === p.id && t.date === today) || p.pic_name);
  if (!people.length) return <div className="mt-4"><Empty art="done" title="No priorities added yet">Everyone's priorities for today will appear here.</Empty></div>;
  return (
    <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {people.map((p) => {
        const l = todos.filter((t) => t.owner === p.id && t.date === today);
        return (
          <div key={p.id} className="card-soft p-4">
            <div className="mb-2 flex items-center justify-between"><span className="font-semibold text-heading">{p.name}</span><span className="text-xs text-muted-foreground">{l.filter((t) => t.done).length}/{l.length} complete</span></div>
            {l.length === 0 ? <p className="text-sm text-muted-foreground">No priorities for today yet</p> : (
              <ul className="space-y-1 text-sm">{l.map((t) => <li key={t.id} className={cn("flex gap-2", t.done && "text-muted-foreground line-through")}><span>{t.done ? "✓" : "○"}</span>{t.text}</li>)}</ul>
            )}
          </div>
        );
      })}
    </div>
  );
}
