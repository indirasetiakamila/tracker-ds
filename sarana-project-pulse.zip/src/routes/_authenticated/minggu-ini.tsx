import { SaranaDots, SaranaLogo } from "@/components/app/brand";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { CountUp, Illustration, Scribble, Stagger, StaggerItem, celebrate, greeting } from "@/components/app/fun";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useProjects, qk, usePicNames } from "@/lib/data";
import { checkedThisWeek, daysOverdue, hoursUntilDeadline, isActive, masihSamaBlock, severity, staleness, todayWIB } from "@/lib/rules";
import { ProjectCard, markMasihSama } from "@/components/app/ProjectCard";
import { Empty } from "@/components/app/bits";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, X, AlertTriangle, CalendarClock, CheckCircle2, ListChecks, ChevronDown, type LucideIcon } from "lucide-react";
import { addDays } from "@/lib/rules";
import { cn } from "@/lib/utils";
import { ALL_STAGES as STAGES } from "@/lib/rules";
import type { Project } from "@/lib/data";

type WeekSearch = { q?: string | undefined; health?: string | undefined; stage?: string | undefined; pic?: string | undefined };
const str = (v: unknown, d: string) => (typeof v === "string" ? v : d);
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/minggu-ini")({
  head: () => ({ meta: [{ title: "This Week | Sarana DS" }, { name: "description", content: "Your weekly project check-in." }, { property: "og:title", content: "This Week | Sarana DS" }, { property: "og:description", content: "Your weekly project check-in." }] }),
  validateSearch: (s: Record<string, unknown>): WeekSearch => ({ q: str(s["q"], "") || undefined, health: str(s["health"], "") || undefined, stage: str(s["stage"], "") || undefined, pic: str(s["pic"], "") || undefined }),
  component: MingguIni,
});

function Ring({ done, total }: { done: number; total: number }) {
  const r = 34, c = 2 * Math.PI * r, pct = total ? done / total : 0;
  return (
    <svg width="88" height="88" viewBox="0 0 88 88" className="shrink-0">
      <circle cx="44" cy="44" r={r} fill="none" stroke="currentColor" strokeWidth="8" className="text-ink-foreground/15" />
      <circle cx="44" cy="44" r={r} fill="none" stroke="currentColor" strokeWidth="8" strokeLinecap="round" className="text-primary"
        strokeDasharray={c} strokeDashoffset={c * (1 - pct)} transform="rotate(-90 44 44)" style={{ transition: "stroke-dashoffset 1s ease-out" }} />
      <text x="44" y="50" textAnchor="middle" className="fill-current text-base font-bold">{done}/{total}</text>
    </svg>
  );
}

function MingguIni() {
  const PICS = usePicNames();
  const { me, uid } = useMe();
  const { data: projects = [] } = useProjects();
  const qc = useQueryClient();
  const today = todayWIB();
  const [busy, setBusy] = useState(false);
  const sp = Route.useSearch();
  const f = { q: sp.q ?? "", health: sp.health ?? "all", stage: sp.stage ?? "all", pic: sp.pic ?? "all" };
  const nav = Route.useNavigate();
  const setF = (patch: Partial<typeof f>) => nav({ search: (prev) => { const n = { ...prev, ...patch }; return { q: n.q || undefined, health: n.health === "all" ? undefined : n.health, stage: n.stage === "all" ? undefined : n.stage, pic: n.pic === "all" ? undefined : n.pic }; }, replace: true });
  const filtered = f.q !== "" || f.health !== "all" || f.stage !== "all" || f.pic !== "all";
  const match = (p: Project) => {
    const q = f.q.trim().toLowerCase();
    if (q && !`${p.client} ${p.project}`.toLowerCase().includes(q)) return false;
    if (f.health !== "all" && (p.health ?? "none") !== f.health) return false;
    if (f.stage !== "all" && p.stage !== f.stage) return false;
    if (f.pic !== "all" && p.pic !== f.pic) return false;
    return true;
  };

  if (me && !me.pic_name) {
    return (
      <div className="mx-auto max-w-md">
        <h1 className="text-2xl font-bold">Hello {me.name.split(" ")[0]}</h1>
        <p className="mt-2 text-sm text-muted-foreground">Select your PIC name to see your projects here.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {PICS.map((n) => (
            <Button key={n} variant="outline" onClick={async () => {
              const { error } = await supabase.from("profiles").update({ pic_name: n }).eq("id", me.id);
              if (error) toast.error(error.message); else { toast.success(`Linked to ${n}`); qc.invalidateQueries({ queryKey: qk.profiles }); }
            }}>{n}</Button>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted-foreground">Not a PIC? Go to <Link to="/tasks" className="text-primary">Engineering tasks</Link> or <Link to="/prioritas" className="text-primary">Priorities</Link>.</p>
      </div>
    );
  }

  const mineAll = projects.filter((p) => isActive(p) && p.pic === me?.pic_name);
  const showPic = f.pic !== "all" ? projects.filter((p) => isActive(p) && p.pic === f.pic) : mineAll;
  const mine = mineAll;
  const listBase = (f.pic !== "all" ? showPic : mineAll).filter(match);
  const done = mine.filter((p) => checkedThisWeek(p, today));
  const todo = mine.filter((p) => !checkedThisWeek(p, today));
  const lDone = listBase.filter((p) => checkedThisWeek(p, today));
  const lTodo = listBase.filter((p) => !checkedThisWeek(p, today));
  const needUpdate = lTodo.filter((p) => masihSamaBlock(p, today) || p.health === "Red").sort((a, b) => severity(b, today) - severity(a, today));
  const quick = lTodo.filter((p) => !needUpdate.includes(p));
  const g = greeting(me?.name);
  const allDone = mine.length > 0 && todo.length === 0;
  const prevTodo = useRef<number | null>(null);
  useEffect(() => { if (prevTodo.current !== null && prevTodo.current > 0 && todo.length === 0 && mine.length > 0) celebrate(); prevTodo.current = todo.length; }, [todo.length, mine.length]);
  const hrs = hoursUntilDeadline();
  const hrsLabel = hrs < 0 ? "The Friday 17:00 deadline has passed" : hrs < 24 ? `${hrs} hours until Friday 17:00` : `${Math.floor(hrs / 24)} days ${hrs % 24} hours until Friday 17:00`;

  async function allSame() {
    setBusy(true);
    try { for (const p of quick) await markMasihSama(p, uid); toast.success(`${quick.length} projects marked unchanged`); qc.invalidateQueries({ queryKey: qk.projects }); }
    catch (e) { toast.error((e as Error).message); }
    setBusy(false);
  }

  return (
    <div>
      <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-6">
        <div className="x-corner relative flex flex-col justify-between gap-6 overflow-hidden rounded-xl border bg-card p-6 col-span-2 md:col-span-4 md:row-span-2 md:p-8">
          <Illustration name={allDone ? "done" : "team"} className="pointer-events-none absolute -bottom-6 -right-6 hidden h-56 w-56 opacity-90 md:block" />
          <div className="relative">
            <p className="eyebrow text-muted-foreground">{g.hello}</p>
            <h1 className="mt-2 text-4xl leading-[1] md:text-6xl">{allDone ? <>All done this <em>week</em></> : <>{todo.length} projects to <em>check</em></>}</h1>
            <p className="mt-3 max-w-md text-sm text-muted-foreground">{hrsLabel}.</p>
          </div>
          <div className="relative flex items-center gap-5">
            <Ring done={done.length} total={mine.length} />
            <div className="flex flex-wrap gap-2 text-xs font-semibold">
              <span className="rounded-md bg-danger-soft px-2.5 py-1 text-destructive">{mine.filter((p) => p.health === "Red").length} Red</span>
              <span className="rounded-md bg-warning-soft px-2.5 py-1 text-warning-foreground">{mine.filter((p) => daysOverdue(p, today) > 0).length} Overdue</span>
              <span className="rounded-md bg-muted px-2.5 py-1 text-muted-foreground">{mine.filter((p) => staleness(p, today)).length} Stale</span>
            </div>
          </div>
        </div>
        {mine.length > 0 && <>
          <Tile icon={AlertTriangle} label="Red" value={mine.filter((p) => p.health === "Red").length} tone="red" active={f.health === "Red"} onClick={() => setF({ health: f.health === "Red" ? "all" : "Red" })} />
          <Tile icon={CheckCircle2} label="Checked" value={done.length} sub={mine.length ? `${Math.round((done.length / mine.length) * 100)}% done` : undefined} tone="green" />
          <Tile icon={ListChecks} label="Need check" value={todo.length} sub={`of ${mine.length}`} wide />
          <Tile icon={CalendarClock} label="Next action due this week" value={mine.filter((p) => p.next_action_due && p.next_action_due <= addDays(today, 7)).length} tone="amber" wide />
        </>}
      </div>

      {mine.length === 0 && !filtered ? (
        <Empty art="team" title="No projects assigned to you yet">Projects assigned to {me?.pic_name} will appear here. Add one via <Link to="/proyek/baru" className="text-primary">New project</Link>.</Empty>
      ) : (
        <div className="space-y-8">
          <div className="flex flex-col gap-2 rounded-xl border bg-card p-3 md:flex-row md:items-center">
            <div className="relative md:w-72">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search client or use case" value={f.q} onChange={(e) => setF({ q: e.target.value })} className="pl-9" />
            </div>
            <Select value={f.health} onValueChange={(v) => setF({ health: v })}><SelectTrigger className="md:w-40"><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="all">All health</SelectItem>{["Green", "Yellow", "Red"].map((h) => <SelectItem key={h} value={h}>{h}</SelectItem>)}</SelectContent></Select>
            <Select value={f.stage} onValueChange={(v) => setF({ stage: v })}><SelectTrigger className="md:w-44"><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="all">All stages</SelectItem>{STAGES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
            <Select value={f.pic} onValueChange={(v) => setF({ pic: v })}><SelectTrigger className="md:w-40"><SelectValue placeholder="My projects" /></SelectTrigger>
              <SelectContent><SelectItem value="all">My projects</SelectItem>{PICS.map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}</SelectContent></Select>
            {filtered && <Button variant="ghost" size="sm" onClick={() => setF({ q: "", health: "all", stage: "all", pic: "all" })}><X className="mr-1 h-4 w-4" />Clear</Button>}
            <span className="ml-auto text-xs text-muted-foreground">{listBase.length} shown</span>
          </div>
          {filtered && listBase.length === 0 && <Empty art="empty" title="No matching projects"><button className="text-primary" onClick={() => setF({ q: "", health: "all", stage: "all", pic: "all" })}>Clear filters</button></Empty>}
          {needUpdate.length > 0 && <Group title="Updates needed" count={needUpdate.length}>{needUpdate.map((p) => <StaggerItem key={p.id}><ProjectCard p={p} /></StaggerItem>)}</Group>}
          {quick.length > 0 && (
            <Group title="Quick check" count={quick.length} action={<Button size="sm" onClick={allSame} disabled={busy}>Mark all unchanged</Button>}>
              {quick.map((p) => <StaggerItem key={p.id}><ProjectCard p={p} /></StaggerItem>)}
            </Group>
          )}
          {!filtered && todo.length === 0 && <div className="rounded-xl border bg-success-soft p-4 text-sm font-semibold text-success">All your projects are checked for the week. </div>}
          {lDone.length > 0 && <Group title="Checked" count={lDone.length} collapsible>{lDone.map((p) => <StaggerItem key={p.id}><ProjectCard p={p} faded /></StaggerItem>)}</Group>}
        </div>
      )}
    </div>
  );
}

function Tile({ icon: I, label, value, sub, tone, active, onClick, wide }: { wide?: boolean; icon: LucideIcon; label: string; value: number; sub?: string | undefined; tone?: "red" | "amber" | "green"; active?: boolean; onClick?: () => void }) {
  const t = tone === "red" ? "bg-destructive/10 text-destructive" : tone === "amber" ? "bg-warning/15 text-warning-foreground" : tone === "green" ? "bg-success/10 text-success" : "bg-primary/10 text-primary";
  const C = onClick ? "button" : "div";
  return (
    <C type={onClick ? "button" : undefined} onClick={onClick} className={cn("card-soft flex flex-col justify-between gap-4 p-5 text-left", wide ? "md:col-span-3" : "md:col-span-2", active && "ring-2 ring-primary")}>
      <span className="flex items-center justify-between gap-2"><span className="eyebrow truncate text-muted-foreground">{label}</span><span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-md", t)}><I className="h-4 w-4" /></span></span>
      <span className="flex items-baseline gap-2"><span className="stat-num text-5xl leading-none text-heading">{value}</span>{sub && <span className="text-xs text-muted-foreground">{sub}</span>}</span>
    </C>
  );
}

function Group({ title, count, action, children, collapsible }: { title: string; count: number; action?: React.ReactNode; children: React.ReactNode; collapsible?: boolean }) {
  const [open, setOpen] = useState(!collapsible);
  return (
    <section>
      <div className="mb-3 flex items-center justify-between gap-2">
        <button type="button" disabled={!collapsible} onClick={() => setOpen((o) => !o)} className="flex items-center gap-2 text-left">
          <h2 className="text-2xl font-bold">{title} <span className="ml-1 rounded-full bg-primary-soft px-2 py-0.5 align-middle font-sans text-xs text-primary">{count}</span></h2>
          {collapsible && <ChevronDown className={cn("h-5 w-5 text-muted-foreground transition-transform", open && "rotate-180")} />}
        </button>
        {action}
      </div>
      {open && <Stagger className="grid gap-3 md:grid-cols-6 [&>*]:md:col-span-3 [&>*:first-child]:md:col-span-4 [&>*:nth-child(2)]:md:col-span-2 [&>*:nth-child(3)]:md:col-span-2 [&>*:nth-child(4)]:md:col-span-4">{children}</Stagger>}
    </section>
  );
}
