import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { qk, TITLE_LABEL, useMe, usePeople, usePicNames, useProfiles, type Person, type PersonTitle } from "@/lib/data";
import { Empty, PageHeader } from "@/components/app/bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin | Sarana DS" }, { name: "description", content: "Manage the team, job titles and access." }, { property: "og:title", content: "Admin | Sarana DS" }, { property: "og:description", content: "Manage the team, job titles and access." }] }),
  component: Admin,
});

type Role = "pic" | "engineer" | "lead" | "admin";
const TITLES = Object.keys(TITLE_LABEL) as PersonTitle[];

function Admin() {
  const { isAdmin } = useMe();
  if (!isAdmin) return <Empty art="lost" title="Admins only">This page is restricted to admins.</Empty>;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Admin" sub="Manage team members and sign-in access" />
      <Tabs defaultValue="tim">
        <TabsList className="mb-4 rounded-full"><TabsTrigger value="tim" className="rounded-full">Team</TabsTrigger><TabsTrigger value="akses" className="rounded-full">Access</TabsTrigger></TabsList>
        <TabsContent value="tim"><Team /></TabsContent>
        <TabsContent value="akses"><Access /></TabsContent>
      </Tabs>
    </div>
  );
}

function Team() {
  const { data: people = [] } = usePeople();
  const qc = useQueryClient();
  const [n, setN] = useState({ name: "", email: "", title: "engineer" as PersonTitle });
  const refresh = () => qc.invalidateQueries({ queryKey: qk.people });

  async function add() {
    const email = n.email.trim().toLowerCase();
    if (!n.name.trim()) { toast.error("Name is required"); return; }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast.error("Enter a valid email"); return; }
    const { error } = await supabase.from("people").insert({ name: n.name.trim(), email: email || null, title: n.title });
    if (error) { toast.error(error.message.includes("duplicate") ? "This email is already registered" : error.message); return; }
    toast.success(`${n.name.trim()} added`); setN({ name: "", email: "", title: "engineer" }); refresh();
  }
  async function upd(p: Person, patch: Partial<Person>, msg: string) {
    const { error } = await supabase.from("people").update(patch).eq("id", p.id);
    if (error) { toast.error(error.message); return; }
    toast.success(msg); refresh();
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-2 card-soft p-4 sm:grid-cols-[1fr_1fr_140px_auto]">
        <Input placeholder="Name" value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} />
        <Input placeholder="Email (needed to sign in)" value={n.email} onChange={(e) => setN({ ...n, email: e.target.value })} />
        <Select value={n.title} onValueChange={(v) => setN({ ...n, title: v as PersonTitle })}><SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{TITLES.map((t) => <SelectItem key={t} value={t}>{TITLE_LABEL[t]}</SelectItem>)}</SelectContent></Select>
        <Button onClick={add}><Plus className="mr-1 h-4 w-4" />Add</Button>
      </div>
      <div className="overflow-x-auto card-soft">
        <table className="w-full text-sm">
          <thead className="border-b bg-muted/50 text-xs text-muted-foreground"><tr><th className="px-3 py-2 text-left">Name</th><th className="px-3 py-2 text-left">Email</th><th className="px-3 py-2 text-left">Job title</th><th className="px-3 py-2 text-left">Account</th><th className="px-3 py-2 text-left">Active</th></tr></thead>
          <tbody>
            {people.map((p) => (
              <tr key={p.id} className={p.active ? "border-b last:border-0" : "border-b opacity-50 last:border-0"}>
                <td className="px-3 py-2"><Input defaultValue={p.name} className="h-8 min-w-36 bg-transparent hover:bg-muted/70" onBlur={(e) => { const v = e.target.value.trim(); if (v && v !== p.name) upd(p, { name: v }, "Name updated"); }} /></td>
                <td className="px-3 py-2 text-muted-foreground">{p.email ?? "-"}</td>
                <td className="px-3 py-2">
                  <Select value={p.title} onValueChange={(v) => upd(p, { title: v as PersonTitle }, "Job title updated")}><SelectTrigger className="h-8 w-28 bg-transparent hover:bg-muted/70"><SelectValue /></SelectTrigger>
                    <SelectContent>{TITLES.map((t) => <SelectItem key={t} value={t}>{TITLE_LABEL[t]}</SelectItem>)}</SelectContent></Select>
                </td>
                <td className="px-3 py-2 text-xs">{p.user_id ? <span className="rounded-full bg-success-soft px-2 py-0.5 font-semibold text-success">Signed in</span> : <span className="text-muted-foreground">Not yet</span>}</td>
                <td className="px-3 py-2"><Switch checked={p.active} onCheckedChange={(v) => upd(p, { active: v }, v ? "Activated" : "Deactivated")} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-muted-foreground">Team members can be selected before they sign in. Their account links automatically when they sign in with the same email.</p>
    </div>
  );
}

function Access() {
  const { uid } = useMe();
  const { data: profiles = [] } = useProfiles();
  const PICS = usePicNames();
  const qc = useQueryClient();

  async function setRole(userId: string, role: Role) {
    const del = await supabase.from("user_roles").delete().eq("user_id", userId);
    if (del.error) { toast.error(del.error.message); return; }
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) { toast.error(error.message); return; }
    toast.success("Role updated"); qc.invalidateQueries({ queryKey: qk.profiles });
  }
  async function setPic(userId: string, pic: string) {
    const { error } = await supabase.from("profiles").update({ pic_name: pic === "none" ? null : pic }).eq("id", userId);
    if (error) { toast.error(error.message); return; }
    toast.success("PIC updated"); qc.invalidateQueries({ queryKey: qk.profiles });
  }

  return (
    <>
      <div className="overflow-x-auto card-soft">
        <table className="w-full text-sm">
          <thead className="border-b bg-muted/50 text-xs text-muted-foreground"><tr><th className="px-3 py-2 text-left">Name</th><th className="px-3 py-2 text-left">Email</th><th className="px-3 py-2 text-left">Role</th><th className="px-3 py-2 text-left">PIC</th></tr></thead>
          <tbody>
            {profiles.map((p) => (
              <tr key={p.id} className="border-b last:border-0">
                <td className="px-3 py-2 font-semibold">{p.name}</td>
                <td className="px-3 py-2 text-muted-foreground">{p.email}</td>
                <td className="px-3 py-2">
                  <Select value={p.role} onValueChange={(v) => setRole(p.id, v as Role)} disabled={p.id === uid}>
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>{["engineer", "pic", "lead", "admin"].map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
                <td className="px-3 py-2">
                  <Select value={p.pic_name ?? "none"} onValueChange={(v) => setPic(p.id, v)}>
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="none">Not a PIC</SelectItem>{PICS.map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">You cannot change your own role here, so admins never lock themselves out.</p>
    </>
  );
}
