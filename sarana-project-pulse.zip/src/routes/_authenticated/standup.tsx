import { createFileRoute, Link } from "@tanstack/react-router";
import { plainText } from "@/lib/richtext";
import { RichText } from "@/components/app/RichText";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { qk, useActivity, useMe, useProfiles, useProjects, type Project, usePicNames } from "@/lib/data";
import { checkedThisWeek, daysOverdue, fmtDate, isActive, needsStandup, reasons, relTime, severity, staleness, todayWIB, TARGET_LABEL } from "@/lib/rules";
import { Empty, HealthPill, PageHeader, PicBadge, ProgressBar, ReasonChips, StagePill , ClientLogo } from "@/components/app/bits";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";

export const Route = createFileRoute("/_authenticated/standup")({
  head: () => ({ meta: [{ title: "Standup | Sarana DS" }, { name: "description", content: "The DS team's standup agenda." }, { property: "og:title", content: "Standup | Sarana DS" }, { property: "og:description", content: "The DS team's standup agenda." }] }),
  component: Standup,
});

function sortAgenda(list: Project[], today: string) {
  const tier = (p: Project) => (p.health === "Red" ? 0 : daysOverdue(p, today) > 0 ? 1 : 2);
  return [...list].sort((a, b) => tier(a) - tier(b) || severity(b, today) - severity(a, today));
}

function Standup() {
  const PICS = usePicNames();
  const { data: projects = [] } = useProjects();
  const { data: act = [] } = useActivity();
  const { data: profiles = [] } = useProfiles();
  const today = todayWIB();
  const active = projects.filter(isActive);
  const agenda = sortAgenda(active.filter((p) => needsStandup(p, today)), today);
  const [focus, setFocus] = useState<number | null>(null);
  const nameOf = (id: string | null) => profiles.find((p) => p.id === id)?.name ?? "System";
  const clientOf = (id: string) => projects.find((p) => p.id === id)?.client ?? id;

  return (
    <div>
      <PageHeader title={`Standup: ${agenda.length} projects to discuss`} sub="Red projects first, then overdue projects, then the rest">
        <Button disabled={!agenda.length} onClick={() => setFocus(0)}>Start standup</Button>
      </PageHeader>
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_400px]">
        <div className="min-w-0 space-y-2">
          {agenda.length === 0 && <Empty art="done" title="Nothing to discuss">Red, overdue, or stale projects, and overdue actions owned by Sarana, appear here.</Empty>}
          {agenda.map((p, i) => (
            <button key={p.id} onClick={() => setFocus(i)} className="card-soft card-ribbon-danger block w-full p-3.5 text-left">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-muted-foreground">{i + 1}</span>
                <ClientLogo client={p.client} className="h-7 w-7 text-[10px]" /><span className="font-semibold text-heading">{p.client}</span>
                <span className="min-w-0 flex-1 truncate text-sm text-muted-foreground">{p.project}</span>
                <span className="ml-auto shrink-0"><PicBadge name={p.pic} /></span>
              </div>
              <div className="mt-1.5"><ReasonChips reasons={reasons(p, today)} /></div>
              <div className="mt-1.5 truncate text-sm"><span className="text-muted-foreground">Next: </span>{plainText(p.next_action) || "Not provided"}</div>
            </button>
          ))}
        </div>
        <div className="min-w-0 space-y-5">
          <div className="card-soft overflow-x-auto p-4">
            <h2 className="mb-3 font-bold">By PIC</h2>
            <table className="w-full text-sm">
              <thead className="text-xs text-muted-foreground"><tr><th className="text-left">PIC</th><th className="text-left">Checked</th><th>Red</th><th>Overdue</th><th>Stale</th></tr></thead>
              <tbody>
                {PICS.map((n) => {
                  const m = active.filter((p) => p.pic === n); const c = m.filter((p) => checkedThisWeek(p, today)).length;
                  return (
                    <tr key={n} className="border-t">
                      <td className="py-2 font-semibold">{n}</td>
                      <td className="py-2"><div className="flex items-center gap-2"><span className="w-10 text-xs">{c}/{m.length}</span><ProgressBar value={m.length ? (c / m.length) * 100 : 0} className="w-16" /></div></td>
                      <td className="text-center text-destructive font-semibold">{m.filter((p) => p.health === "Red").length || ""}</td>
                      <td className="text-center">{m.filter((p) => daysOverdue(p, today) > 0).length || ""}</td>
                      <td className="text-center">{m.filter((p) => staleness(p, today)).length || ""}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="card-soft p-4">
            <h2 className="mb-3 font-bold">Recent activity</h2>
            <ol className="space-y-2">
              {act.slice(0, 40).map((a) => (
                <li key={a.id} className="text-sm">
                  <Link to="/proyek/$id" params={{ id: a.project_id }} className="font-semibold text-heading hover:text-primary">{clientOf(a.project_id)}</Link>
                  <span className="ml-1 break-words">{a.text}</span>
                  <div className="text-[11px] text-muted-foreground">{nameOf(a.by)} · {relTime(a.at)}</div>
                </li>
              ))}
              {act.length === 0 && <li className="text-sm text-muted-foreground">No activity yet.</li>}
            </ol>
          </div>
        </div>
      </div>
      {focus !== null && agenda[focus] && <Focus list={agenda} idx={focus} setIdx={setFocus} />}
    </div>
  );
}

function Focus({ list, idx, setIdx }: { list: Project[]; idx: number; setIdx: (n: number | null) => void }) {
  const p = list[idx]!;
  const today = todayWIB();
  const { uid } = useMe();
  const qc = useQueryClient();
  const [notes, setNotes] = useState<Record<string, string>>({});
  const note = notes[p.id] ?? "";

  async function saveNext() {
    if (note.trim()) {
      const { error } = await supabase.from("activity").insert({ project_id: p.id, by: uid, kind: "note", text: `Standup: ${note.trim()}` });
      if (error) { toast.error(error.message); return; }
      toast.success("Standup decision saved");
      qc.invalidateQueries({ queryKey: qk.activity });
    }
    if (idx < list.length - 1) setIdx(idx + 1); else { toast.success("Standup complete"); setIdx(null); }
  }

  const Row = ({ l, v }: { l: string; v: React.ReactNode }) => <div><div className="text-xs text-muted-foreground">{l}</div><div className="text-sm font-medium break-words">{v || <i className="text-muted-foreground">Not provided</i>}</div></div>;
  return (
    <Dialog open onOpenChange={(o) => !o && setIdx(null)}>
      <DialogContent className="max-h-[95vh] max-w-3xl overflow-y-auto">
        <div className="text-xs text-muted-foreground">{idx + 1} of{list.length} · {p.id}</div>
        <DialogTitle className="text-2xl">{p.client}</DialogTitle>
        <p className="-mt-2 text-muted-foreground">{p.project}</p>
        <div className="flex flex-wrap gap-2"><PicBadge name={p.pic} /><StagePill s={p.stage} /><HealthPill h={p.health} /><ReasonChips reasons={reasons(p, today)} /></div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Row l="Blocker" v={p.blocker} />
          <div><div className="text-xs text-muted-foreground">Next action</div><RichText value={p.next_action} empty="-" /></div>
          <Row l="Owner" v={p.next_action_owner} />
          <Row l="Due" v={fmtDate(p.next_action_due)} />
          <Row l={TARGET_LABEL[p.stage]} v={fmtDate(p.target_date)} />
          <Row l="Sign-off" v={p.signoff_status} />
        </div>
        <Textarea rows={3} placeholder="Standup decision" value={note} onChange={(e) => setNotes((n) => ({ ...n, [p.id]: e.target.value }))} />
        <div className="flex justify-between gap-2">
          <Button variant="outline" disabled={idx === 0} onClick={() => setIdx(idx - 1)}>Previous</Button>
          <Button onClick={saveNext}>Save & continue</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
