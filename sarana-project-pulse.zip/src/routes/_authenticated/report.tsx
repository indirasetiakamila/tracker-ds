import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Copy } from "lucide-react";
import { useActivity, useProfiles, useProjects, useTasks, useTodos, usePicNames } from "@/lib/data";
import { healthMix, needsAttention, stageSummary } from "@/lib/rules";
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, AlertTriangle, CheckCircle2, Coins, FolderKanban, Radio, Wrench, Bug } from "lucide-react";
import { BOARD_STAGES, addDays, daysOverdue, fmtDate, isActive, mondayOf, todayWIB } from "@/lib/rules";
import { Chip, PageHeader } from "@/components/app/bits";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/report")({
  head: () => ({ meta: [{ title: "Report | Sarana DS" }, { name: "description", content: "The DS team's weekly report." }, { property: "og:title", content: "Report | Sarana DS" }, { property: "og:description", content: "The DS team's weekly report." }] }),
  component: Report,
});

function Report() {
  const PICS = usePicNames();
  const { data: projects = [] } = useProjects();
  const { data: act = [] } = useActivity();
  const { data: tasks = [] } = useTasks();
  const { data: todos = [] } = useTodos();
  const { data: profiles = [] } = useProfiles();
  const today = todayWIB();
  const [off, setOff] = useState(0);
  const start = addDays(mondayOf(today), -7 * off);
  const end = addDays(start, 6);
  const inP = (d: string | null | undefined) => !!d && d.slice(0, 10) >= start && d.slice(0, 10) <= end;
  // activity timestamps are UTC; convert to WIB date
  const wib = (iso: string) => todayWIB(new Date(iso));

  const active = projects.filter(isActive);
  const live = active.filter((p) => p.stage === "Hypercare");
  const updated = active.filter((p) => inP(p.last_updated));
  const red = active.filter((p) => p.health === "Red");
  const overdue = active.filter((p) => daysOverdue(p, today) > 0);
  const arr = active.reduce((s, p) => s + Number(p.potential_arr_idr_million ?? 0), 0);
  const tasksDone = tasks.filter((t) => t.done_at && inP(wib(t.done_at)));
  const bugs = tasks.filter((t) => t.status !== "Done" && t.type === "Bug" && (t.prio === "P1" || t.prio === "P2"));
  const moves = act.filter((a) => a.kind === "stage" && inP(wib(a.at)));
  const prioDone = todos.filter((t) => t.done && inP(t.date));
  const nameOf = (id: string | null) => profiles.find((p) => p.id === id)?.name ?? "System";
  const clientOf = (id: string) => projects.find((p) => p.id === id)?.client ?? id;

  function copy() {
    const lines = [
      `*DS summary ${fmtDate(start)} to ${fmtDate(end)}*`,
      `Active ${active.length} · Live ${live.length} · Updated ${updated.length}/${active.length} · Red ${red.length} · Overdue ${overdue.length}`,
      `Potential ARR IDR ${arr.toLocaleString("en-US")} million · Tasks completed ${tasksDone.length} · Open P1/P2 bugs ${bugs.length}`,
      "", "*Stage changes*", ...(moves.length ? moves.map((m) => `- ${clientOf(m.project_id)}: ${m.text}`) : ["- None"]),
      "", "*Red*", ...(red.length ? red.map((p) => `- ${p.client} (${p.pic}): ${p.blocker || "no blocker provided"}`) : ["- None"]),
    ];
    navigator.clipboard.writeText(lines.join("\n")).then(() => toast.success("Summary copied. Ready to paste into WhatsApp."));
  }

  const Kpi = ({ l, v, tone, icon: I }: { l: string; v: React.ReactNode; tone?: "red" | "amber"; icon: typeof Activity }) => (
    <div className="card-soft p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className={`flex h-7 w-7 items-center justify-center rounded-md ${tone === "red" ? "bg-destructive/10 text-destructive" : tone === "amber" ? "bg-warning/15 text-warning-foreground" : "bg-primary/10 text-primary"}`}><I className="h-3.5 w-3.5" /></span>{l}</div>
      <div className={`stat-num mt-3 text-5xl leading-none ${tone === "red" ? "text-destructive" : "text-heading"}`}>{v}</div></div>
  );
  const sums = stageSummary(active);
  const mix = healthMix(active);
  const mixData = [{ n: "Green", v: mix.Green, c: "var(--success)" }, { n: "Yellow", v: mix.Yellow, c: "var(--warning)" }, { n: "Red", v: mix.Red, c: "var(--destructive)" }, { n: "Not set", v: mix["Not set"], c: "var(--muted-foreground)" }].filter((x) => x.v > 0);
  const arrByPic = PICS.map((n) => ({ n, v: active.filter((p) => p.pic === n).reduce((s, p) => s + Number(p.potential_arr_idr_million ?? 0), 0) })).filter((x) => x.v > 0).sort((a, b) => b.v - a.v);
  const attention = active.map((p) => ({ p, why: needsAttention(p, today) })).filter((x) => x.why);
  const rate = active.length ? Math.round((updated.length / active.length) * 100) : 0;

  return (
    <div>
      <PageHeader art="report" title="Report" sub={`${fmtDate(start)} to ${fmtDate(end)}`}>
        <Button onClick={copy}><Copy className="mr-1 h-4 w-4" />Copy summary</Button>
      </PageHeader>
      <div className="mb-5 flex gap-1.5">{["This Week", "Last week", "2 weeks ago"].map((l, i) => <Chip key={l} active={off === i} onClick={() => setOff(i)}>{l}</Chip>)}</div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 [&>*:first-child]:x-corner">
        <Kpi icon={FolderKanban} l="Active projects" v={active.length} /><Kpi icon={Radio} l="Live (Hypercare)" v={live.length} />
        <Kpi icon={CheckCircle2} l="Updated this period" v={<>{rate}%<span className="ml-1 text-sm font-semibold text-muted-foreground">{updated.length}/{active.length}</span></>} />
        <Kpi icon={Coins} l="Potential ARR (IDR million)" v={arr.toLocaleString("en-US")} />
        <Kpi icon={AlertTriangle} l="Red" v={red.length} tone="red" /><Kpi icon={Activity} l="Overdue" v={overdue.length} tone="amber" />
        <Kpi icon={Wrench} l="Tasks completed" v={tasksDone.length} /><Kpi icon={Bug} l="Open P1/P2 bugs" v={bugs.length} tone="red" />
      </div>

      <div className="mt-5 grid gap-3 lg:grid-cols-3 [&>*:first-child]:lg:col-span-2 [&>*:nth-child(4)]:lg:col-span-2">
        <Box title="Projects by stage">
          <div className="h-56"><ResponsiveContainer width="100%" height="100%">
            <BarChart data={sums} margin={{ left: -20, right: 8 }}>
              <XAxis dataKey="stage" tick={{ fontSize: 10 }} interval={0} angle={-25} textAnchor="end" height={50} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ fill: "var(--muted)" }} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="count" name="Projects" fill="var(--primary)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="red" name="of which Red" fill="var(--destructive)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer></div>
        </Box>
        <Box title="Health mix">
          <div className="flex items-center gap-4">
            <div className="h-48 w-48 shrink-0"><ResponsiveContainer width="100%" height="100%">
              <PieChart><Pie data={mixData} dataKey="v" nameKey="n" innerRadius={50} outerRadius={80} paddingAngle={2} stroke="none">
                {mixData.map((d) => <Cell key={d.n} fill={d.c} />)}
              </Pie><Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} /></PieChart>
            </ResponsiveContainer></div>
            <ul className="space-y-2 text-sm">{mixData.map((d) => <li key={d.n} className="flex items-center gap-2"><span className="h-3 w-3 rounded-sm" style={{ background: d.c }} />{d.n}<b className="ml-2 tabular-nums">{d.v}</b><span className="text-xs text-muted-foreground">{active.length ? Math.round((d.v / active.length) * 100) : 0}%</span></li>)}</ul>
          </div>
        </Box>
        <Box title="Potential ARR by PIC (IDR million)">
          {arrByPic.length === 0 ? <p className="text-sm text-muted-foreground">No ARR recorded yet.</p> : (
            <div className="h-56"><ResponsiveContainer width="100%" height="100%">
              <BarChart data={arrByPic} layout="vertical" margin={{ left: 0, right: 16 }}>
                <XAxis type="number" tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="n" width={60} tick={{ fontSize: 12 }} />
                <Tooltip cursor={{ fill: "var(--muted)" }} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="v" name="ARR" fill="var(--primary)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer></div>
          )}
        </Box>
        <Box title={`Needs attention (${attention.length})`}>
          {attention.length === 0 ? <p className="text-sm text-muted-foreground">Everything looks on track.</p> : (
            <ul className="max-h-56 space-y-1.5 overflow-y-auto pr-1 text-sm">{attention.map(({ p, why }) => (
              <li key={p.id} className="flex items-center justify-between gap-2 rounded-md px-2 py-1 hover:bg-muted">
                <Link to="/proyek/$id" params={{ id: p.id }} className="truncate font-semibold text-heading hover:text-primary">{p.client} <span className="font-normal text-muted-foreground">{p.pic}</span></Link>
                <span className={`shrink-0 rounded px-1.5 py-0.5 text-[11px] font-semibold ${why === "Red" ? "bg-destructive/10 text-destructive" : "bg-warning/15 text-warning-foreground"}`}>{why}</span>
              </li>))}</ul>
          )}
        </Box>
        <Box title="Stage changes">
          {moves.length === 0 ? <p className="text-sm text-muted-foreground">No stage changes this period.</p> : (
            <ul className="space-y-1.5 text-sm">{moves.map((m) => <li key={m.id}><span className="text-xs text-muted-foreground">{fmtDate(wib(m.at))}</span> <b className="text-heading">{clientOf(m.project_id)}</b> {(m.text.split(";")[0] ?? "").replace("Stage: ", "")} <span className="text-xs text-muted-foreground">· {nameOf(m.by)}</span></li>)}</ul>
          )}
        </Box>
        <Box title="Currently Red">
          {red.length === 0 ? <p className="text-sm text-muted-foreground">No Red projects.</p> : (
            <ul className="space-y-2 text-sm">{red.map((p) => <li key={p.id}><Link to="/proyek/$id" params={{ id: p.id }} className="font-semibold text-heading hover:text-primary">{p.client}</Link> <span className="text-xs text-muted-foreground">{p.pic}{daysOverdue(p, today) > 0 && ` · ${daysOverdue(p, today)} days overdue`}</span><div className="text-muted-foreground">{p.blocker || "No blocker provided"}</div></li>)}</ul>
          )}
        </Box>
        <Box title="By PIC">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground"><tr><th className="text-left">PIC</th><th className="text-left">Updated</th><th className="text-left">Priorities</th><th>Red</th></tr></thead>
            <tbody>{PICS.map((n) => {
              const m = active.filter((p) => p.pic === n); const prof = profiles.find((p) => p.pic_name === n);
              const pt = todos.filter((t) => t.owner === prof?.id && inP(t.date));
              return <tr key={n} className="border-t"><td className="py-1.5 font-semibold">{n}</td><td>{m.filter((p) => inP(p.last_updated)).length}/{m.length}</td><td>{pt.filter((t) => t.done).length}/{pt.length}</td><td className="text-center text-destructive">{m.filter((p) => p.health === "Red").length || ""}</td></tr>;
            })}</tbody>
          </table>
        </Box>
        <Box title="Completed priorities" className="lg:col-span-2">
          {prioDone.length === 0 ? <p className="text-sm text-muted-foreground">No priorities completed this period.</p> : (
            <ul className="grid gap-1 text-sm md:grid-cols-2">{prioDone.map((t) => <li key={t.id}>✓ {t.text} <span className="text-xs text-muted-foreground">· {nameOf(t.owner)}, {fmtDate(t.date)}</span></li>)}</ul>
          )}
        </Box>
      </div>
    </div>
  );
}

function Box({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return <div className={`card-soft p-4 ${className ?? ""}`}><h2 className="mb-3 font-bold">{title}</h2>{children}</div>;
}
