import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { qk, useMe, usePeople, useProjects } from "@/lib/data";
import { isActive, todayWIB } from "@/lib/rules";
import { PageHeader, PrioBadge, TypeBadge } from "@/components/app/bits";
import { PersonSelect } from "@/components/app/PersonSelect";
import { Illustration } from "@/components/app/fun";
import { RichTextEditor } from "@/components/app/RichText";
import { ChipSelect, Field, FormActions, FormSection, IconInput, Stepper } from "@/components/app/form";
import { Bug, CalendarClock, Circle, ClipboardList, Flame, FolderKanban, Hammer, Loader, Plus, Settings2, Sparkles, Type, Wrench, Zap, ArrowDown, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QuickFill, AiMark } from "@/components/app/QuickFill";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TEMPLATE = "<h3>Context</h3><p></p><h3>Work required</h3><ul data-type=\"taskList\"><li data-type=\"taskItem\" data-checked=\"false\"><p></p></li></ul><h3>Acceptance criteria</h3><p></p>";

export const Route = createFileRoute("/_authenticated/tasks/baru")({
  validateSearch: (s: Record<string, unknown>) => ({ project: typeof s["project"] === "string" ? (s["project"] as string) : undefined }),
  head: () => ({ meta: [{ title: "New task | Sarana DS" }, { name: "description", content: "Create a new engineering task." }, { property: "og:title", content: "New task | Sarana DS" }, { property: "og:description", content: "Create a new engineering task." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: NewTask,
});

function NewTask() {
  const { project } = Route.useSearch();
  const { data: projects = [] } = useProjects();
  const { data: people = [] } = usePeople();
  const { uid } = useMe();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const today = todayWIB();
  const [f, setF] = useState({ title: "", project_id: project ?? "", assignee: "none", type: "Feature", prio: "P3", status: "To do", estimate: "", due: "", description: TEMPLATE });
  const [busy, setBusy] = useState(false);
  const [ai, setAi] = useState<Set<string>>(new Set());
  const set = (k: keyof typeof f, v: string) => { setF((x) => ({ ...x, [k]: v })); setAi((a) => { if (!a.has(k)) return a; const n = new Set(a); n.delete(k); return n; }); };
  function applyAi(v: Record<string, unknown>) {
    const map: [keyof typeof f, string, string][] = [["title", "title", "title"], ["project_id", "project_id", "project"], ["assignee", "engineer_id", "engineer"], ["type", "type", "type"], ["prio", "prio", "priority"], ["estimate", "estimate_hours", "estimate"], ["due", "due", "due"], ["description", "description_html", "description"]];
    const patch: Partial<typeof f> = {}; const keys: string[] = []; const labels: string[] = [];
    for (const [k, src, label] of map) {
      const val = v[src]; if (val === null || val === undefined || val === "") continue;
      if (k === "project_id" && !projects.some((p) => p.id === val)) continue;
      if (k === "assignee" && !people.some((p) => p.id === val)) continue;
      patch[k] = String(val); keys.push(k); labels.push(label);
    }
    setF((x) => ({ ...x, ...patch })); setAi(new Set(keys));
    return labels;
  }
  const A = (k: string) => ai.has(k);
  const proj = projects.find((p) => p.id === f.project_id);
  const eng = people.find((p) => p.id === f.assignee);

  async function create() {
    if (!f.title.trim() || !f.project_id) { toast.error("Title and project are required"); return; }
    if (f.due && f.due < today) { toast.error("The due date cannot be in the past"); return; }
    setBusy(true);
    const { data, error } = await supabase.from("tasks").insert({
      title: f.title.trim(), project_id: f.project_id, assignee_person: f.assignee === "none" ? null : f.assignee, assignee: eng?.user_id ?? null, reporter: uid,
      type: f.type as "Feature", prio: f.prio as "P3", status: f.status as "To do", estimate_hours: f.estimate ? Number(f.estimate) : null,
      due: f.due || null, description: f.description,
    }).select("key").single();
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success(`${data.key} created`);
    qc.invalidateQueries({ queryKey: qk.tasks });
    navigate({ to: "/tasks/$key", params: { key: data.key } });
  }

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader icon={Wrench} title="New task" sub="One task, one clear outcome." />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="space-y-5">
          <QuickFill kind="task" onFill={applyAi} />
          <FormSection i={0} icon={ClipboardList} title="Task details" hint="A concise title and its project">
            <Field label="Title" req><AiMark on={A("title")}><IconInput icon={Type} value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="Example: Core banking API integration" /></AiMark></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Project" req><AiMark on={A("project_id")}>
                <Select value={f.project_id} onValueChange={(v) => set("project_id", v)}>
                  <SelectTrigger className="h-11 rounded-2xl"><FolderKanban className="mr-2 h-4 w-4 shrink-0 text-muted-foreground" /><span className="flex-1 truncate text-left"><SelectValue placeholder="Select project" /></span></SelectTrigger>
                  <SelectContent>{projects.filter(isActive).map((p) => <SelectItem key={p.id} value={p.id}>{p.client} ({p.id})</SelectItem>)}</SelectContent>
                </Select>
              </AiMark></Field>
              <Field label="Engineer"><AiMark on={A("assignee")}><PersonSelect by="id" titles={["engineer", "lead"]} value={f.assignee === "none" ? null : f.assignee} onChange={(v) => set("assignee", v ?? "none")} emptyLabel="Unassigned" placeholder="Unassigned" /></AiMark></Field>
            </div>
          </FormSection>

          <FormSection i={1} icon={Settings2} title="Type & urgency">
            <Field label="Type"><AiMark on={A("type")}><ChipSelect value={f.type} onChange={(v) => set("type", v)} options={[
              { v: "Feature", l: "Feature", icon: Sparkles }, { v: "Bug", l: "Bug", icon: Bug, tone: "bg-destructive text-destructive-foreground" },
              { v: "Improvement", l: "Improvement", icon: Zap }, { v: "Chore", l: "Chore", icon: Hammer, tone: "bg-heading text-background" }]} /></AiMark></Field>
            <Field label="Priority"><AiMark on={A("prio")}><ChipSelect value={f.prio} onChange={(v) => set("prio", v)} options={[
              { v: "P1", l: "P1", icon: Flame, tone: "bg-destructive text-destructive-foreground" }, { v: "P2", l: "P2", icon: Zap, tone: "bg-warning text-warning-foreground" },
              { v: "P3", l: "P3", icon: Minus }, { v: "P4", l: "P4", icon: ArrowDown, tone: "bg-muted-foreground text-background" }]} /></AiMark></Field>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Status"><ChipSelect value={f.status} onChange={(v) => set("status", v)} options={[{ v: "To do", l: "To do", icon: Circle }, { v: "In progress", l: "In progress", icon: Loader }]} /></Field>
              <Field label="Estimate (hours)"><AiMark on={A("estimate")}><Stepper value={f.estimate} onChange={(v) => set("estimate", v)} /></AiMark></Field>
              <Field label="Due"><AiMark on={A("due")}><IconInput icon={CalendarClock} type="date" min={today} value={f.due} onChange={(e) => set("due", e.target.value)} /></AiMark></Field>
            </div>
          </FormSection>

          <FormSection i={2} icon={ClipboardList} title="Description" hint="Format with bold, highlights, headings and checklists">
            <AiMark on={A("description")}><RichTextEditor value={f.description} onChange={(v) => set("description", v)} minHeight={220} /></AiMark>
          </FormSection>

          <FormActions>
            <Button variant="ghost" asChild><Link to="/tasks">Cancel</Link></Button>
            <Button onClick={create} disabled={busy}><Plus className="mr-1 h-4 w-4" />Create task</Button>
          </FormActions>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-6 lg:self-start">
          <div className="rounded-[1.75rem] rounded-tl-[3rem] bg-card p-5 shadow-lift">
            <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">Preview</div>
            <div className="flex gap-1.5"><TypeBadge type={f.type} /><PrioBadge prio={f.prio} /></div>
            <div className="mt-2 font-serif text-xl font-bold leading-tight text-heading">{f.title || "Task title"}</div>
            <div className="mt-1 text-sm text-muted-foreground">{proj ? `${proj.client} · ${proj.id}` : "No project selected"}</div>
            <div className="mt-3 text-sm">{eng ? eng.name : <i className="text-muted-foreground">Unassigned</i>}{f.estimate && ` · ${f.estimate} hours`}</div>
          </div>
          <div className="rounded-[1.75rem] bg-powder/40 p-5 text-sm">
            <Illustration name="team" className="mx-auto mb-2 h-28 w-28" />
            “Define what done looks like before getting started.”
          </div>
        </aside>
      </div>
    </div>
  );
}
