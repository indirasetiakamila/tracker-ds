import { Skeleton } from "@/components/app/fun";
import { plainText } from "@/lib/richtext";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowUpDown, Download, ExternalLink, Plus } from "lucide-react";
import { useProfiles, useProjects, type Project, usePicNames } from "@/lib/data";
import { checkedThisWeek, daysOverdue, fmtDate, isActive, itemsBehind, needsStandup, progress, staleness, todayWIB } from "@/lib/rules";
import { Chip, Empty, HealthPill, PageHeader, ProgressBar, StagePill , ClientLogo } from "@/components/app/bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/register")({
  head: () => ({ meta: [{ title: "Register | Sarana DS" }, { name: "description", content: "All DS projects in one table." }, { property: "og:title", content: "Register | Sarana DS" }, { property: "og:description", content: "All DS projects in one table." }] }),
  component: RegisterPage,
});

const SHEET = "https://docs.google.com/spreadsheets/d/1QslFs7Z6no9AGEiLowhn8fBd4QifhWCiQFZSJvkc_Go/edit#gid=";
type Filter = "aktif" | "standup" | "red" | "belum" | "closed" | "semua";
type SortKey = "id" | "client" | "pic" | "stage" | "progress" | "health" | "target" | "overdue" | "due" | "arr" | "updated";

function RegisterPage() {
  const PICS = usePicNames();
  const { data: projects = [], isLoading } = useProjects();
  const { data: profiles = [] } = useProfiles();
  const navigate = useNavigate();
  const today = todayWIB();
  const [q, setQ] = useState("");
  const [pic, setPic] = useState("all");
  const [filter, setFilter] = useState<Filter>("aktif");
  const [sort, setSort] = useState<{ k: SortKey; dir: 1 | -1 }>({ k: "id", dir: 1 });

  const rows = useMemo(() => {
    let r = projects.filter((p) => {
      if (filter === "aktif" && !isActive(p)) return false;
      if (filter === "closed" && isActive(p)) return false;
      if (filter === "standup" && !needsStandup(p, today)) return false;
      if (filter === "red" && (p.health !== "Red" || !isActive(p))) return false;
      if (filter === "belum" && (checkedThisWeek(p, today) || !isActive(p))) return false;
      if (pic !== "all" && p.pic !== pic) return false;
      if (q) {
        const s = `${p.id} ${p.client} ${p.project} ${p.product} ${p.am} ${plainText(p.next_action)}`.toLowerCase();
        if (!s.includes(q.toLowerCase())) return false;
      }
      return true;
    });
    const val = (p: Project): string | number => {
      switch (sort.k) {
        case "client": return p.client.toLowerCase();
        case "pic": return p.pic;
        case "stage": return ["Pipeline", "POC", "Go/No-Go", "Development", "UAT", "Go-Live", "Hypercare", "On Hold", "Closed-No Go"].indexOf(p.stage);
        case "progress": return progress(p) ?? -1;
        case "health": return p.health === "Red" ? 0 : p.health === "Yellow" ? 1 : p.health === "Green" ? 2 : 3;
        case "target": return p.target_date ?? "9999";
        case "overdue": return daysOverdue(p, today);
        case "due": return p.next_action_due ?? "9999";
        case "arr": return Number(p.potential_arr_idr_million ?? 0);
        case "updated": return p.last_updated ?? "0000";
        default: return p.id;
      }
    };
    r = [...r].sort((a, b) => (val(a) > val(b) ? 1 : val(a) < val(b) ? -1 : 0) * sort.dir);
    return r;
  }, [projects, filter, pic, q, sort, today]);

  const totalArr = rows.reduce((s, p) => s + Number(p.potential_arr_idr_million ?? 0), 0);
  const picOptions = Array.from(new Set([...PICS, ...projects.map((p) => p.pic)])).filter(Boolean);

  function downloadCsv() {
    const nameOf = (id: string | null) => profiles.find((x) => x.id === id)?.name ?? "";
    const head = ["ID", "Client", "Project", "Product", "PIC", "AM", "Stage", "Target date", "Health", "Ball in court", "Blocker", "Next action", "Next action owner", "Next action due", "Sign-off status", "Potential ARR (IDR million)", "Last updated", "Progress %", "Updated by"];
    const esc = (v: unknown) => { const s = v === null || v === undefined ? "" : String(v); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const lines = projects.map((p) => [p.id, p.client, p.project, p.product, p.pic, p.am, p.stage, p.target_date, p.health, p.ball_in_court, p.blocker, plainText(p.next_action), p.next_action_owner, p.next_action_due, p.signoff_status, p.potential_arr_idr_million, p.last_updated, progress(p) ?? "n/a", nameOf(p.last_updated_by)].map(esc).join(","));
    const blob = new Blob(["\uFEFF" + [head.join(","), ...lines].join("\r\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `DS-Project-Register-${today}.csv`;
    a.click();
  }

  const H = ({ k, children, className }: { k: SortKey; children: React.ReactNode; className?: string }) => (
    <th className={cn("px-3 py-2 text-left font-semibold whitespace-nowrap", className)}>
      <button className="inline-flex items-center gap-1 hover:text-primary" onClick={() => setSort((s) => ({ k, dir: s.k === k ? (s.dir === 1 ? -1 : 1) : 1 }))}>
        {children}<ArrowUpDown className={cn("h-3 w-3", sort.k === k ? "opacity-100" : "opacity-30")} />
      </button>
    </th>
  );

  return (
    <div>
      <PageHeader title="Register" sub={<>{rows.length} projects · total potential ARR <b className="text-heading">IDR {totalArr.toLocaleString("en-US")} million</b></>}>
        <Button variant="outline" onClick={downloadCsv}><Download className="mr-1 h-4 w-4" />Download CSV</Button>
        <Button asChild><Link to="/proyek/baru"><Plus className="mr-1 h-4 w-4" />New Project</Link></Button>
      </PageHeader>

      <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center">
        <Input placeholder="Search client, use case, next action..." value={q} onChange={(e) => setQ(e.target.value)} className="md:max-w-xs bg-card" />
        <Select value={pic} onValueChange={setPic}>
          <SelectTrigger className="md:w-40 bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All PICs</SelectItem>
            {picOptions.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex gap-1.5 overflow-x-auto">
          {([["aktif", "Active"], ["standup", "Standup"], ["red", "Red"], ["belum", "Not reviewed"], ["closed", "Closed"], ["semua", "All"]] as const).map(([k, l]) => (
            <Chip key={k} active={filter === k} onClick={() => setFilter(k)}>{l}</Chip>
          ))}
        </div>
      </div>

      {isLoading ? <Skeleton rows={4} /> : projects.length === 0 ? (
        <Empty title="No projects yet">Projects from the Excel register will appear here after import. Or select "New Project" to get started.</Empty>
      ) : (
        <div className="overflow-x-auto card-soft">
          <table className="w-full text-sm">
            <thead className="border-b bg-muted/50 text-xs text-muted-foreground">
              <tr>
                <H k="id">ID</H><H k="client">Client</H><th className="px-3 py-2 text-left font-semibold">Project</th><H k="pic">PIC</H><H k="stage">Stage</H>
                <H k="progress">Progress</H><H k="health">Health</H><H k="target">Target</H><H k="overdue">Overdue</H>
                <th className="px-3 py-2 text-left font-semibold">Ball in court</th><th className="px-3 py-2 text-left font-semibold">Next action</th>
                <H k="due">Due</H><H k="arr" className="text-right">ARR (IDR million)</H><H k="updated">Update</H><th className="px-3 py-2 text-left font-semibold">Source</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => {
                const pr = progress(p); const ib = itemsBehind(p); const od = daysOverdue(p, today); const st = staleness(p, today);
                return (
                  <tr key={p.id} onClick={() => navigate({ to: "/proyek/$id", params: { id: p.id } })}
                    className={cn("cursor-pointer border-b last:border-0 hover:bg-accent/50", needsStandup(p, today) && "shadow-[inset_3px_0_0_var(--destructive)]")}>
                    <td className="px-3 py-2 font-mono text-xs whitespace-nowrap">{p.id}</td>
                    <td className="px-3 py-2 font-semibold text-heading whitespace-nowrap"><span className="flex items-center gap-2"><ClientLogo client={p.client} className="h-7 w-7 text-[10px]" />{p.client}</span></td>
                    <td className="max-w-48 truncate px-3 py-2">{p.project}</td>
                    <td className="px-3 py-2">{p.pic}</td>
                    <td className="px-3 py-2"><StagePill s={p.stage} /></td>
                    <td className="min-w-32 px-3 py-2">
                      {pr === null ? <span className="text-xs text-muted-foreground">n/a</span> : (<>
                        <div className="flex items-center gap-2"><span className="w-8 text-xs font-semibold">{pr}%</span><ProgressBar value={pr} /></div>
                        {ib > 0 && <div className="mt-0.5 text-[11px] font-semibold text-warning-foreground dark:text-warning">{ib} outstanding items</div>}
                      </>)}
                    </td>
                    <td className="px-3 py-2"><HealthPill h={p.health} /></td>
                    <td className="px-3 py-2 whitespace-nowrap">{fmtDate(p.target_date)}</td>
                    <td className="px-3 py-2 font-semibold text-destructive">{od > 0 ? `${od} days` : ""}</td>
                    <td className="px-3 py-2">{p.ball_in_court === "Client" ? "Client" : p.ball_in_court ?? ""}</td>
                    <td className="max-w-56 truncate px-3 py-2">{plainText(p.next_action)}</td>
                    <td className={cn("px-3 py-2 whitespace-nowrap", p.next_action_due && p.next_action_due < today && "font-semibold text-destructive")}>{fmtDate(p.next_action_due)}</td>
                    <td className="px-3 py-2 text-right tabular-nums">{p.potential_arr_idr_million ? Number(p.potential_arr_idr_million).toLocaleString("en-US") : ""}</td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      <span className="text-xs">{fmtDate(p.last_updated)}</span>
                      {st && <span className="ml-1 rounded bg-danger-soft px-1 text-[10px] font-bold text-destructive">{st.label}</span>}
                    </td>
                    <td className="px-3 py-2">
                      {p.source_gid && <a href={SHEET + p.source_gid} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="text-primary"><ExternalLink className="h-4 w-4" /></a>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
