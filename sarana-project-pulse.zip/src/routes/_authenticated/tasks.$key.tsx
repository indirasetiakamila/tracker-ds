import { RichTextEditor } from "@/components/app/RichText";
import { Skeleton } from "@/components/app/fun";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { optimistic, patchRows, qk, taskPerson, usePeople, useMe, useProfiles, useProjects, useTaskComments, useTasks, type Task } from "@/lib/data";
import { fmtDate, relTime } from "@/lib/rules";
import { Empty, Initials, PrioBadge, TypeBadge } from "@/components/app/bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/tasks/$key")({
  head: ({ params }) => ({ meta: [{ title: `${params.key} | Sarana DS` }, { name: "description", content: "Engineering task details." }, { property: "og:title", content: `${params.key} | Sarana DS` }, { property: "og:description", content: "Engineering task details." }] }),
  component: TaskPage,
});

function TaskPage() {
  const { key } = Route.useParams();
  const { data: tasks, isLoading } = useTasks();
  const t = tasks?.find((x) => x.key === key);
  if (isLoading) return <Skeleton rows={4} />;
  if (!t) return <Empty art="lost" title="Task not found"><Link to="/tasks" className="text-primary">Back to tasks</Link></Empty>;
  return <TaskView key={t.id} t={t} />;
}

function TaskView({ t }: { t: Task }) {
  const { data: projects = [] } = useProjects();
  const { data: profiles = [] } = useProfiles();
  const { data: comments = [] } = useTaskComments(t.id);
  const { data: people = [] } = usePeople();
  const { uid } = useMe();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [title, setTitle] = useState(t.title);
  const [desc, setDesc] = useState(t.description);
  const [comment, setComment] = useState("");
  const [confirmDel, setConfirmDel] = useState(false);
  const [openAssignee, setOpenAssignee] = useState(false);
  const proj = projects.find((p) => p.id === t.project_id);
  const nameOf = (id: string | null) => profiles.find((p) => p.id === id)?.name ?? null;

  async function patch(p: Partial<Task>, msg = "Saved") {
    try { await optimistic<Task>(qk.tasks, patchRows([t.id], p), () => supabase.from("tasks").update(p).eq("id", t.id), [t.id]); }
    catch (e) { toast.error((e as Error).message); return; }
    toast.success(msg);
    qc.invalidateQueries({ queryKey: qk.comments(t.id) });
  }
  async function addComment() {
    if (!comment.trim()) return;
    const { error } = await supabase.from("task_comments").insert({ task_id: t.id, by: uid, kind: "comment", text: comment.trim() });
    if (error) { toast.error(error.message); return; }
    setComment(""); toast.success("Comment added"); qc.invalidateQueries({ queryKey: qk.comments(t.id) });
  }
  async function del() {
    const { error } = await supabase.from("tasks").delete().eq("id", t.id);
    if (error) { toast.error(error.message); return; }
    toast.success(`${t.key} deleted`); qc.invalidateQueries({ queryKey: qk.tasks }); navigate({ to: "/tasks" });
  }

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => <div><Label className="text-xs text-muted-foreground">{label}</Label>{children}</div>;
  const Sel = ({ value, opts, on }: { value: string; opts: string[] | [string, string][]; on: (v: string) => void }) => (
    <Select value={value} onValueChange={on}><SelectTrigger><SelectValue /></SelectTrigger>
      <SelectContent>{opts.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return <SelectItem key={v} value={v}>{l}</SelectItem>; })}</SelectContent></Select>
  );

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-3 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
        <Link to="/tasks" className="hover:text-primary">Engineering tasks</Link><span>/</span>
        {proj && <><Link to="/proyek/$id" params={{ id: proj.id }} className="hover:text-primary">{proj.client}</Link><span>/</span></>}
        <span className="font-mono">{t.key}</span>
      </div>
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0 space-y-4">
          <div className="flex items-center gap-2"><TypeBadge type={t.type} /><PrioBadge prio={t.prio} /><span className="font-mono text-sm text-muted-foreground">{t.key}</span></div>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} onBlur={() => title.trim() && title !== t.title && patch({ title: title.trim() }, "Title saved")}
            className="h-auto border-transparent bg-transparent px-0 text-2xl font-bold text-heading shadow-none focus-visible:border-input focus-visible:bg-card focus-visible:px-2" />
          <div className="card-soft p-4">
            <Label className="text-xs text-muted-foreground">Description</Label>
            <RichTextEditor value={desc ?? ""} onChange={setDesc} minHeight={200} className="mt-1" />
            {desc !== t.description && <Button size="sm" className="mt-2" onClick={() => patch({ description: desc }, "Description saved")}>Save description</Button>}
          </div>
          <div className="card-soft p-4">
            <h2 className="mb-3 font-bold">Activity</h2>
            <ol className="space-y-2">
              {comments.map((c) => (
                <li key={c.id} className={cn("flex gap-2 text-sm", c.kind === "log" && "text-muted-foreground")}>
                  {c.kind === "comment" ? <Initials name={nameOf(c.by)} /> : <span className="mt-1.5 ml-2 mr-1 h-2 w-2 shrink-0 rounded-full bg-border" />}
                  <div className="min-w-0 flex-1">
                    <div className={cn("break-words", c.kind === "comment" && "rounded-md bg-muted px-3 py-2 text-foreground")}>{c.text}</div>
                    <div className="mt-0.5 text-[11px] text-muted-foreground">{nameOf(c.by) ?? "System"} · {relTime(c.at)}</div>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-4 flex gap-2">
              <Textarea rows={2} placeholder="Write a comment" value={comment} onChange={(e) => setComment(e.target.value)} />
              <Button onClick={addComment} disabled={!comment.trim()}>Send</Button>
            </div>
          </div>
        </div>
        <div className="space-y-3 self-start card-soft p-4">
          <Field label="Status"><Sel value={t.status} opts={["To do", "In progress", "In review", "Blocked", "Done"]} on={(v) => patch({ status: v as Task["status"] }, `Status: ${v}`)} /></Field>
          <Field label="Engineer">
            <Popover open={openAssignee} onOpenChange={setOpenAssignee}>
              <PopoverTrigger asChild><Button variant="outline" className="w-full justify-start font-normal">{taskPerson(t, people)?.name ?? "Unassigned"}</Button></PopoverTrigger>
              <PopoverContent className="p-0" align="start">
                <Command><CommandInput placeholder="Search people" /><CommandList><CommandEmpty>No results found</CommandEmpty>
                  <CommandItem onSelect={() => { setOpenAssignee(false); patch({ assignee: null, assignee_person: null }, "Engineer unassigned"); }}>Unassigned</CommandItem>
                  {people.filter((p) => p.active && (p.title === "engineer" || p.title === "lead")).map((p) => <CommandItem key={p.id} value={p.name} onSelect={() => { setOpenAssignee(false); patch({ assignee_person: p.id, assignee: p.user_id }, `Assigned to ${p.name}`); }}>{p.name}</CommandItem>)}
                </CommandList></Command>
              </PopoverContent>
            </Popover>
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Priority"><Sel value={t.prio} opts={["P1", "P2", "P3", "P4"]} on={(v) => patch({ prio: v as Task["prio"] })} /></Field>
            <Field label="Type"><Sel value={t.type} opts={["Feature", "Bug", "Improvement", "Chore"]} on={(v) => patch({ type: v as Task["type"] })} /></Field>
          </div>
          <Field label="Project"><Sel value={t.project_id} opts={projects.map((p) => [p.id, p.client] as [string, string])} on={(v) => patch({ project_id: v })} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Estimate (hours)"><Input type="number" defaultValue={t.estimate_hours ?? ""} onBlur={(e) => { const v = e.target.value === "" ? null : Number(e.target.value); if (v !== t.estimate_hours) patch({ estimate_hours: v }); }} /></Field>
            <Field label="Due"><Input type="date" defaultValue={t.due ?? ""} onChange={(e) => patch({ due: e.target.value || null })} /></Field>
          </div>
          <div className="space-y-1 border-t pt-3 text-xs text-muted-foreground">
            <div>Created by {nameOf(t.reporter) ?? "?"} · {fmtDate(t.created_at.slice(0, 10))}</div>
            <div>Update {relTime(t.updated_at)}</div>
            {t.done_at && <div>Completed {fmtDate(t.done_at.slice(0, 10))}</div>}
          </div>
          <div className="border-t pt-3">
            {!confirmDel ? <Button variant="ghost" size="sm" className="text-destructive" onClick={() => setConfirmDel(true)}>Delete task</Button> : (
              <div className="flex items-center gap-2 text-xs"><span>Delete this task?</span><Button size="sm" variant="destructive" onClick={del}>Yes, delete</Button><Button size="sm" variant="ghost" onClick={() => setConfirmDel(false)}>Cancel</Button></div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
