import { QuickFill } from "@/components/app/QuickFill";
import { RichTextEditor } from "@/components/app/RichText";
import { Skeleton } from "@/components/app/fun";
import { PersonSelect } from "@/components/app/PersonSelect";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { ChevronDown, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { qk, updateProject, useClientLogos, saveClientLogo, fileToLogoDataUrl, useActivity, useMe, useProfiles, useProjects, useTasks, type Project } from "@/lib/data";
import {
  CAN_CLOSE_NO_GO, CHECKLIST, FLOW, HANDOVER, HOLD, TARGET_LABEL, canAdvance, fmtDate, getChecks, nextStage, progress,
  reasons, relTime, stageBehind, todayWIB, validateUpdate, type Ball, type Health, type Stage, type CheckItem,
} from "@/lib/rules";
import { Empty, HealthPill, ReasonChips, StagePill, PicBadge, TypeBadge, PrioBadge , ClientLogo } from "@/components/app/bits";
import { MasihSamaButton } from "@/components/app/ProjectCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/proyek/$id")({
  head: ({ params }) => ({ meta: [{ title: `${params.id} | Sarana DS` }, { name: "description", content: "Project details, checklists and weekly status." }, { property: "og:title", content: `${params.id} | Sarana DS` }, { property: "og:description", content: "Project details, checklists and weekly status." }] }),
  component: ProjectPage,
});

function ProjectPage() {
  const { id } = Route.useParams();
  const { data: projects, isLoading } = useProjects();
  const p = projects?.find((x) => x.id === id);
  if (isLoading) return <Skeleton rows={4} />;
  if (!p) return <Empty art="lost" title="Project not found"><Link to="/register" className="text-primary">Back to Register</Link></Empty>;
  return <ProjectView p={p} />;
}

type Prompt = { kind: "advance" | "hold" | "nogo" } | null;

function ProjectView({ p }: { p: Project }) {
  const today = todayWIB();
  const qc = useQueryClient();
  const { uid, canEditProjects, isLead } = useMe();
  const pr = progress(p);
  const r = reasons(p, today);
  const [prompt, setPrompt] = useState<Prompt>(null);

  async function save(patch: Record<string, unknown>, msg: string) {
    try {
      await updateProject(p.id, { ...patch, last_updated: today, last_updated_by: uid });
      toast.success(msg);
      qc.invalidateQueries({ queryKey: qk.projects });
      qc.invalidateQueries({ queryKey: qk.activity });
    } catch (e) { toast.error((e as Error).message); }
  }

  async function changePic(next: string) {
    if (next === p.pic) return;
    await save({ pic: next, handover_pp: HANDOVER.map(() => false), handover_active: true }, `PIC changed to ${next}. Handover checklist opened.`);
  }

  async function toggle(stage: string, i: number, v: boolean) {
    const c = { ...p.checklist, [stage]: getChecks(p, stage).map((x, j) => (j === i ? v : x)) };
    await save({ checklist: c }, v ? "Item checked" : "Item unchecked");
  }

  const viewStage: Stage = p.stage === "On Hold" && p.prev_stage ? p.prev_stage : p.stage;
  const curIdx = FLOW.indexOf(viewStage);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <Link to="/register" className="hover:text-primary">Register</Link><span>/</span><span className="font-mono">{p.id}</span>
        {p.am && <span>· AM {p.am}</span>}{p.pm && <span>· PM {p.pm}</span>}{p.product && <span>· {p.product}</span>}
      </div>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex min-w-0 items-start gap-4">
          <LogoEditor client={p.client} canEdit={canEditProjects} />
          <div className="min-w-0">
          <h1 className="text-3xl font-bold md:text-4xl">{p.client}</h1>
          <p className="text-muted-foreground">{p.project}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2"><StagePill s={p.stage} /><HealthPill h={p.health} /><ReasonChips reasons={r} /></div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-sm"><span className="text-muted-foreground">PIC</span>
            <PersonSelect value={p.pic} onChange={(v) => v && changePic(v)} titles={["pic", "lead"]} allowEmpty={false} disabled={!canEditProjects} className="w-40" /></div>
          {canEditProjects && <MasihSamaButton p={p} size="default" />}
        </div>
      </div>

      {/* progress + stepper */}
      <div className="mt-5 card-soft p-4">
        <div className="flex flex-col gap-4 md:flex-row md:items-center">
          <div className="text-4xl font-bold text-heading tabular-nums">{pr === null ? "n/a" : `${pr}%`}</div>
          <div className="grid flex-1 grid-cols-7 gap-1">
            {FLOW.map((s, i) => {
              const behind = stageBehind(p, s);
              const items = (CHECKLIST[s] ?? []).length || 1;
              const fill = i < curIdx ? 100 : i === curIdx ? Math.round(((items - behind) / items) * 100) : 0;
              const amber = i < curIdx && behind > 0;
              return (
                <div key={s} className="min-w-0">
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div className={cn("h-full", amber ? "bg-warning" : "bg-primary")} style={{ width: `${fill}%` }} />
                  </div>
                  <div className={cn("mt-1 truncate text-[10px] sm:text-xs", i === curIdx ? "font-bold text-heading" : "text-muted-foreground")}>{s}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_420px]">
        {/* LEFT */}
        <div className="min-w-0 space-y-3">
          {p.stage === "On Hold" && <HoldCard p={p} save={save} editable={canEditProjects} />}
          {p.stage === "Closed-No Go" && <div className="rounded-lg border bg-muted p-4 text-sm">Project closed as No Go. Reason: <b>{p.blocker || "Not recorded"}</b></div>}
          {FLOW.map((s, i) => {
            const isCur = s === p.stage;
            const behind = i < curIdx && stageBehind(p, s) > 0;
            const nxt = nextStage(s);
            return (
              <StageCard key={s} title={s} items={CHECKLIST[s] ?? []} checks={getChecks(p, s)} current={isCur} behind={behind} defaultOpen={isCur || (s === viewStage)}
                disabled={!canEditProjects} onToggle={(i2, v) => toggle(s, i2, v)}>
                {isCur && canEditProjects && (
                  <div className="flex flex-wrap gap-2 border-t pt-3">
                    {nxt && <Button size="sm" disabled={!canAdvance(p)} onClick={() => setPrompt({ kind: "advance" })} title={canAdvance(p) ? "" : "Complete all checklist items first"}>Naik ke {nxt}</Button>}
                    <Button size="sm" variant="outline" onClick={() => setPrompt({ kind: "hold" })}>Put on hold</Button>
                    {CAN_CLOSE_NO_GO.includes(s) && (
                      <Button size="sm" variant="outline" className="text-destructive" disabled={!isLead} title={isLead ? "" : "Only leads can close a project as No Go"} onClick={() => setPrompt({ kind: "nogo" })}>Close as No Go</Button>
                    )}
                    {nxt && !canAdvance(p) && <span className="self-center text-xs text-muted-foreground">Complete all checklist items to advance</span>}
                  </div>
                )}
              </StageCard>
            );
          })}
          <StageCard title="PIC to PIC handover" items={HANDOVER} checks={HANDOVER.map((_, i) => !!p.handover_pp?.[i])} current={false} behind={!!p.handover_active} defaultOpen={!!p.handover_active}
            disabled={!canEditProjects} onToggle={(i, v) => {
              const arr = HANDOVER.map((_, j) => (j === i ? v : !!p.handover_pp?.[j]));
              save({ handover_pp: arr, handover_active: !arr.every(Boolean) }, arr.every(Boolean) ? "Handover complete" : "Handover updated");
            }} />
          <TasksCard projectId={p.id} />
        </div>

        {/* RIGHT */}
        <div className="min-w-0 space-y-5">
          <StatusForm key={p.id} p={p} editable={canEditProjects} />
          <History projectId={p.id} />
        </div>
      </div>

      <StageDialog p={p} prompt={prompt} onClose={() => setPrompt(null)} save={save} />
    </div>
  );
}

function StageCard({ title, items, checks, current, behind, defaultOpen, disabled, onToggle, children }: {
  title: string; items: CheckItem[]; checks: boolean[]; current: boolean; behind: boolean; defaultOpen: boolean; disabled: boolean;
  onToggle: (i: number, v: boolean) => void; children?: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const n = checks.filter(Boolean).length;
  return (
    <Collapsible open={open} onOpenChange={setOpen} className={cn("card-soft", current && "border-2 border-primary", behind && !current && "border-warning bg-warning-soft/40")}>
      <CollapsibleTrigger className="flex w-full items-center justify-between px-4 py-3 text-left">
        <span className="font-semibold text-heading">{title}{current && <span className="ml-2 text-xs font-normal text-primary">current stage</span>}</span>
        <span className="flex items-center gap-2 text-xs">
          <span className={cn("font-semibold", behind ? "text-warning-foreground dark:text-warning" : "text-muted-foreground")}>{n}/{items.length}</span>
          <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
        </span>
      </CollapsibleTrigger>
      <CollapsibleContent className="space-y-2 px-4 pb-4">
        {items.map((it, i) => (
          <label key={i} className="flex cursor-pointer items-start gap-2.5 text-sm">
            <Checkbox checked={!!checks[i]} disabled={disabled} onCheckedChange={(v) => onToggle(i, !!v)} className="mt-0.5" />
            <span className={cn("flex-1", it.gate && "font-semibold", checks[i] && "text-muted-foreground line-through")}>{it.t}{it.gate && <span className="ml-1 text-xs text-primary">(gate)</span>}</span>
            <PicBadge name={it.owner} />
          </label>
        ))}
        {children}
      </CollapsibleContent>
    </Collapsible>
  );
}

function HoldCard({ p, save, editable }: { p: Project; save: (x: Record<string, unknown>, m: string) => Promise<void>; editable: boolean }) {
  const [to, setTo] = useState<Stage>(p.prev_stage ?? "Pipeline");
  const checks = HOLD.map((_, i) => !!p.hold_checklist?.[i]);
  return (
    <div className="rounded-lg border-2 border-warning bg-card p-4">
      <div className="mb-2 font-semibold text-heading">On Hold <span className="text-xs font-normal text-muted-foreground">previously {p.prev_stage ?? "?"}</span></div>
      <div className="space-y-2">
        {HOLD.map((it, i) => (
          <label key={i} className="flex items-start gap-2.5 text-sm">
            <Checkbox checked={!!checks[i]} disabled={!editable} onCheckedChange={(v) => save({ hold_checklist: checks.map((x, j) => (j === i ? !!v : x)) }, "On-hold checklist updated")} className="mt-0.5" />
            <span className="flex-1">{it.t}</span><PicBadge name={it.owner} />
          </label>
        ))}
      </div>
      {editable && (
        <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
          <Select value={to} onValueChange={(v) => setTo(v as Stage)}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>{FLOW.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
          <Button size="sm" onClick={() => save({ stage: to, prev_stage: null, target_date: null }, `Project resumed at ${to}. Set a new target date.`)}>Resume project</Button>
        </div>
      )}
    </div>
  );
}

function StageDialog({ p, prompt, onClose, save }: { p: Project; prompt: Prompt; onClose: () => void; save: (x: Record<string, unknown>, m: string) => Promise<void> }) {
  const [date, setDate] = useState("");
  const [text, setText] = useState("");
  const today = todayWIB();
  if (!prompt) return null;
  const nxt = nextStage(p.stage);
  const cfg = prompt.kind === "advance"
    ? { title: `Advance to ${nxt}`, dateLabel: TARGET_LABEL[nxt as Stage], textLabel: null, needDate: true, needText: false }
    : prompt.kind === "hold"
      ? { title: "Put on hold", dateLabel: "Review date", textLabel: "Reason for hold (saved as blocker)", needDate: true, needText: true }
      : { title: "Close as No Go", dateLabel: null, textLabel: "Reason for No Go (saved as blocker)", needDate: false, needText: true };
  const ok = (!cfg.needDate || (date && date >= today)) && (!cfg.needText || text.trim());
  async function go() {
    if (prompt!.kind === "advance") await save({ stage: nxt, target_date: date }, `Advance to ${nxt}`);
    if (prompt!.kind === "hold") await save({ stage: "On Hold", prev_stage: p.stage, target_date: date, blocker: text, hold_checklist: [true, false, true] }, "Project put on hold");
    if (prompt!.kind === "nogo") await save({ stage: "Closed-No Go", prev_stage: p.stage, target_date: null, blocker: text }, "Project closed as No Go");
    setDate(""); setText(""); onClose();
  }
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>{cfg.title}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {cfg.dateLabel && <div><Label>{cfg.dateLabel}</Label><Input type="date" min={today} value={date} onChange={(e) => setDate(e.target.value)} /></div>}
          {cfg.textLabel && <div><Label>{cfg.textLabel}</Label><Textarea value={text} onChange={(e) => setText(e.target.value)} /></div>}
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button><Button disabled={!ok} onClick={go}>Save</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Seg<T extends string>({ value, options, onChange, disabled }: { value: T | null; options: { v: T; l: string; cls: string }[]; onChange: (v: T) => void; disabled?: boolean }) {
  return (
    <div className="flex rounded-md border bg-muted p-0.5">
      {options.map((o) => (
        <button key={o.v} type="button" disabled={disabled} onClick={() => onChange(o.v)}
          className={cn("flex-1 rounded px-2 py-1.5 text-xs font-semibold transition-colors", value === o.v ? o.cls : "text-muted-foreground hover:text-foreground")}>{o.l}</button>
      ))}
    </div>
  );
}

function StatusForm({ p, editable }: { p: Project; editable: boolean }) {
  const today = todayWIB();
  const qc = useQueryClient();
  const { uid } = useMe();
  const init = () => ({
    health: p.health as Health | null, ball_in_court: p.ball_in_court as Ball | null, target_date: p.target_date ?? "",
    next_action: p.next_action ?? "", next_action_owner: p.next_action_owner ?? "", next_action_due: p.next_action_due ?? "",
    blocker: p.blocker ?? "", signoff_status: p.signoff_status ?? "", potential_arr_idr_million: p.potential_arr_idr_million?.toString() ?? "",
    client: p.client, project: p.project, product: p.product ?? "", am: p.am ?? "", pm: p.pm ?? "",
  });
  const [f, setF] = useState(init);
  const [errors, setErrors] = useState<string[]>([]);
  const set = <K extends keyof ReturnType<typeof init>>(k: K, v: ReturnType<typeof init>[K]) => setF((x) => ({ ...x, [k]: v }));

  async function submit() {
    const e = validateUpdate({ ...f, next_action_due: f.next_action_due || null, target_date: f.target_date || null }, p.stage, today, p.target_date);
    setErrors(e);
    if (e.length) { toast.error(e[0]); return; }
    const next: Record<string, unknown> = {
      health: f.health, ball_in_court: f.ball_in_court, target_date: f.target_date || null, next_action: f.next_action, next_action_owner: f.next_action_owner,
      next_action_due: f.next_action_due || null, blocker: f.blocker, signoff_status: f.signoff_status,
      potential_arr_idr_million: f.potential_arr_idr_million === "" ? null : Number(f.potential_arr_idr_million),
      client: f.client, project: f.project, product: f.product, am: f.am, pm: f.pm,
    };
    const patch: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(next)) {
      const old = (p as Record<string, unknown>)[k];
      if (String(old ?? "") !== String(v ?? "")) patch[k] = v;
    }
    try {
      await updateProject(p.id, { ...patch, last_updated: today, last_updated_by: uid });
      toast.success(Object.keys(patch).length ? "Status saved" : "Reviewed. No changes.");
      qc.invalidateQueries({ queryKey: qk.projects }); qc.invalidateQueries({ queryKey: qk.activity });
    } catch (err) { toast.error((err as Error).message); }
  }

  const changed = JSON.stringify(f) !== JSON.stringify(init());
  return (
    <div className="card-soft p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-bold">This Week's Status</h2>
        {changed && <button className="text-xs text-muted-foreground hover:text-primary" onClick={() => setF(init())}>Load latest data</button>}
      </div>
      {editable && <div className="mb-4"><QuickFill kind="update" defaultOpen={false} onFill={(v) => {
        const labels: string[] = []; const patch: Record<string, unknown> = {};
        const m: [string, string, string][] = [["health", "health", "health"], ["ball_in_court", "ball_in_court", "ball in court"], ["next_action", "next_action_html", "next action"], ["next_action_due", "next_action_due", "due"], ["next_action_owner", "next_action_owner", "owner"], ["blocker", "blocker", "blocker"]];
        for (const [k, src, l] of m) { const val = v[src]; if (val === null || val === undefined || val === "") continue; patch[k] = val; labels.push(l); }
        setF((x) => ({ ...x, ...patch })); return labels;
      }} /></div>}
      <fieldset disabled={!editable} className="space-y-3">
        <div><Label className="mb-1 block text-xs">Health</Label>
          <Seg value={f.health} onChange={(v) => set("health", v)} options={[{ v: "Green", l: "Green", cls: "bg-success text-success-foreground" }, { v: "Yellow", l: "Yellow", cls: "bg-warning text-warning-foreground" }, { v: "Red", l: "Red", cls: "bg-destructive text-destructive-foreground" }]} /></div>
        <div><Label className="mb-1 block text-xs">Ball in court</Label>
          <Seg value={f.ball_in_court} onChange={(v) => set("ball_in_court", v)} options={[{ v: "Sarana", l: "Sarana", cls: "bg-primary text-primary-foreground" }, { v: "Client", l: "Client", cls: "bg-heading text-background" }]} /></div>
        <div><Label className="text-xs">{TARGET_LABEL[p.stage]}</Label><Input type="date" value={f.target_date} onChange={(e) => set("target_date", e.target.value)} /></div>
        <div><Label className="text-xs">Next action</Label><RichTextEditor value={f.next_action} onChange={(v) => set("next_action", v)} minHeight={90} disabled={!editable} /></div>
        <div className="grid grid-cols-2 gap-2">
          <div><Label className="text-xs">Owner</Label><PersonSelect value={f.next_action_owner} onChange={(v) => set("next_action_owner", v ?? "")} placeholder="Select owner" /></div>
          <div><Label className="text-xs">Due</Label><Input type="date" min={today} value={f.next_action_due} onChange={(e) => set("next_action_due", e.target.value)} /></div>
        </div>
        <div><Label className="text-xs">Blocker</Label><Textarea rows={2} value={f.blocker} onChange={(e) => set("blocker", e.target.value)} /></div>
        <div className="grid grid-cols-2 gap-2">
          <div><Label className="text-xs">Sign-off status</Label><Input value={f.signoff_status} onChange={(e) => set("signoff_status", e.target.value)} /></div>
          <div><Label className="text-xs">ARR (IDR million)</Label><Input type="number" value={f.potential_arr_idr_million} onChange={(e) => set("potential_arr_idr_million", e.target.value)} /></div>
        </div>
        <Collapsible>
          <CollapsibleTrigger className="flex items-center gap-1 text-xs font-semibold text-primary">Edit project details <ChevronDown className="h-3 w-3" /></CollapsibleTrigger>
          <CollapsibleContent className="mt-2 grid grid-cols-2 gap-2">
            <div><Label className="text-xs">Client</Label><Input value={f.client} onChange={(e) => set("client", e.target.value)} /></div>
            <div><Label className="text-xs">Use case</Label><Input value={f.project} onChange={(e) => set("project", e.target.value)} /></div>
            <div><Label className="text-xs">Product</Label><Input value={f.product} onChange={(e) => set("product", e.target.value)} /></div>
            <div><Label className="text-xs">AM</Label><PersonSelect value={f.am} onChange={(v) => set("am", v ?? "")} titles={["am"]} placeholder="Select AM" /></div>
            <div><Label className="text-xs">PM</Label><PersonSelect value={f.pm} onChange={(v) => set("pm", v ?? "")} titles={["pm"]} placeholder="Select PM" /></div>
          </CollapsibleContent>
        </Collapsible>
        {errors.length > 0 && <ul className="rounded-md bg-danger-soft p-2 text-xs text-destructive">{errors.map((e) => <li key={e}>{e}</li>)}</ul>}
        {editable && <Button className="w-full" onClick={submit}>Save update</Button>}
        {!editable && <p className="text-xs text-muted-foreground">View only. Only PICs and leads can update projects.</p>}
      </fieldset>
    </div>
  );
}

function History({ projectId }: { projectId: string }) {
  const { data: act = [] } = useActivity();
  const { data: profiles = [] } = useProfiles();
  const qc = useQueryClient();
  const { uid } = useMe();
  const [note, setNote] = useState("");
  const rows = useMemo(() => act.filter((a) => a.project_id === projectId), [act, projectId]);
  const nameOf = (id: string | null) => profiles.find((p) => p.id === id)?.name ?? "System";

  async function addNote() {
    if (!note.trim() || !uid) return;
    const { error } = await supabase.from("activity").insert({ project_id: projectId, by: uid, kind: "note", text: note.trim() });
    if (error) { toast.error(error.message); return; }
    setNote(""); toast.success("Note added"); qc.invalidateQueries({ queryKey: qk.activity });
  }

  return (
    <div className="card-soft p-4">
      <h2 className="mb-3 font-bold">History</h2>
      <div className="flex gap-2">
        <Textarea rows={2} placeholder="Add a note" value={note} onChange={(e) => setNote(e.target.value)} />
        <Button onClick={addNote} disabled={!note.trim()}>Add</Button>
      </div>
      <ol className="mt-4 space-y-2">
        {rows.length === 0 && <li className="text-sm text-muted-foreground">No history yet. All changes will appear here.</li>}
        {rows.map((a) => (
          <li key={a.id} className={cn("rounded-md border-l-2 px-3 py-2 text-sm", a.kind === "note" ? "border-warning bg-warning-soft" : a.kind === "stage" ? "border-primary bg-primary-soft" : "border-border")}>
            <div className="break-words">{a.text}</div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">{nameOf(a.by)} · {relTime(a.at)}</div>
          </li>
        ))}
      </ol>
    </div>
  );
}

function TasksCard({ projectId }: { projectId: string }) {
  const { data: tasks = [] } = useTasks();
  const list = tasks.filter((t) => t.project_id === projectId);
  const open = list.filter((t) => t.status !== "Done");
  const statuses = ["To do", "In progress", "In review", "Blocked", "Done"] as const;
  return (
    <div className="card-soft p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-bold">Engineering tasks</h2>
        <Button size="sm" asChild><Link to="/tasks/baru" search={{ project: projectId }}><Plus className="mr-1 h-4 w-4" />Task</Link></Button>
      </div>
      <div className="mb-3 flex flex-wrap gap-2 text-xs">
        {statuses.map((s) => <span key={s} className="rounded-md bg-muted px-2 py-1">{s} <b>{list.filter((t) => t.status === s).length}</b></span>)}
      </div>
      {open.length === 0 ? <p className="text-sm text-muted-foreground">No open tasks. Add a task to track engineering work on this project.</p> : (
        <ul className="divide-y">
          {open.map((t) => (
            <li key={t.id}><Link to="/tasks/$key" params={{ key: t.key }} className="flex items-center gap-2 py-2 text-sm hover:text-primary">
              <TypeBadge type={t.type} /><span className="font-mono text-xs">{t.key}</span><span className="flex-1 truncate">{t.title}</span>
              <PrioBadge prio={t.prio} /><span className="text-xs text-muted-foreground">{t.status}</span>
            </Link></li>
          ))}
        </ul>
      )}
    </div>
  );
}


function LogoEditor({ client, canEdit }: { client: string; canEdit: boolean }) {
  const { data: logos } = useClientLogos();
  const has = !!logos?.[client.trim().toLowerCase()];
  const qc = useQueryClient();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  async function run(fn: () => Promise<void>, ok: string) {
    setBusy(true);
    try { await fn(); toast.success(ok); qc.invalidateQueries({ queryKey: qk.logos }); } catch (e) { toast.error((e as Error).message); }
    setBusy(false);
  }
  return (
    <div className="flex shrink-0 flex-col items-center gap-1">
      <ClientLogo client={client} className="h-16 w-16 text-lg" />
      {canEdit && (
        <>
          <input ref={ref} type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp" className="hidden" onChange={(e) => {
            const file = e.target.files?.[0]; e.target.value = "";
            if (!file) return;
            if (file.size > 2 * 1024 * 1024) { toast.error("Logo must be 2 MB or smaller"); return; }
            run(async () => saveClientLogo(client, await fileToLogoDataUrl(file)), "Logo updated");
          }} />
          <div className="flex gap-2 text-[11px] font-semibold">
            <button disabled={busy} className="text-primary hover:underline" onClick={() => ref.current?.click()}>{has ? "Replace" : "Upload logo"}</button>
            {has && <button disabled={busy} className="text-muted-foreground hover:text-destructive" onClick={() => run(() => saveClientLogo(client, null), "Logo removed")}>Remove</button>}
          </div>
        </>
      )}
    </div>
  );
}
