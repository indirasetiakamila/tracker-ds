import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Building2, CalendarClock, Coins, FolderPlus, Lightbulb, Package, Rocket, Sparkles, Target, Users, FlaskConical, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { qk, useMe } from "@/lib/data";
import { emptyChecklist, todayWIB } from "@/lib/rules";
import { plainText } from "@/lib/richtext";
import { PersonSelect } from "@/components/app/PersonSelect";
import { HealthPill, PageHeader, StagePill } from "@/components/app/bits";
import { Illustration } from "@/components/app/fun";
import { RichTextEditor } from "@/components/app/RichText";
import { ChipSelect, Field, FormActions, FormSection, IconInput } from "@/components/app/form";
import { Button } from "@/components/ui/button";
import { QuickFill, AiMark } from "@/components/app/QuickFill";

export const Route = createFileRoute("/_authenticated/proyek/baru")({
  head: () => ({ meta: [{ title: "New project | Sarana DS" }, { name: "description", content: "Add a new project to the register." }, { property: "og:title", content: "New project | Sarana DS" }, { property: "og:description", content: "Add a new project to the register." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: NewProject,
});

function NewProject() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { me, uid, canEditProjects } = useMe();
  const today = todayWIB();
  const [nextId, setNextId] = useState("DS-...");
  const [f, setF] = useState({ client: "", project: "", pic: "", next_action: "", next_action_due: "", product: "", am: "", pm: "", stage: "Pipeline", target_date: "", arr: "" });
  const [busy, setBusy] = useState(false);
  const [ai, setAi] = useState<Set<string>>(new Set());
  const set = (k: keyof typeof f, v: string) => { setF((x) => ({ ...x, [k]: v })); setAi((a) => { if (!a.has(k)) return a; const n = new Set(a); n.delete(k); return n; }); };
  function applyAi(v: Record<string, unknown>) {
    const map: [keyof typeof f, string, string][] = [["client", "client", "client"], ["project", "project", "use case"], ["product", "product", "product"], ["pic", "pic", "PIC"], ["am", "am", "AM"], ["pm", "pm", "PM"], ["stage", "stage", "stage"], ["next_action", "next_action_html", "next action"], ["next_action_due", "next_action_due", "due"], ["target_date", "target_date", "target date"], ["arr", "arr_idr_million", "ARR"]];
    const patch: Partial<typeof f> = {}; const keys: string[] = []; const labels: string[] = [];
    for (const [k, src, label] of map) { const val = v[src]; if (val === null || val === undefined || val === "") continue; patch[k] = String(val); keys.push(k); labels.push(label); }
    setF((x) => ({ ...x, ...patch })); setAi(new Set(keys));
    return labels;
  }
  const A = (k: string) => ai.has(k);

  useEffect(() => { supabase.rpc("peek_project_id").then(({ data }) => data && setNextId(data)); }, []);
  useEffect(() => { if (me?.pic_name && !f.pic) set("pic", me.pic_name); }, [me]); // eslint-disable-line react-hooks/exhaustive-deps

  const nextText = plainText(f.next_action);
  const missing = [!f.client.trim() && "client", !f.project.trim() && "use case", !f.pic && "PIC", !nextText && "next action", (!f.next_action_due || f.next_action_due < today) && "due"].filter(Boolean) as string[];
  const done = 5 - missing.length;

  async function create() {
    if (missing.length) { toast.error(`Complete: ${missing.join(", ")}`); return; }
    setBusy(true);
    const { data, error } = await supabase.from("projects").insert({
      client: f.client.trim(), project: f.project.trim(), pic: f.pic, next_action: f.next_action, next_action_due: f.next_action_due,
      product: f.product, am: f.am, pm: f.pm, stage: f.stage as "Pipeline" | "POC", target_date: f.target_date || null,
      potential_arr_idr_million: f.arr ? Number(f.arr) : null, checklist: emptyChecklist(), health: "Yellow", ball_in_court: "Sarana",
      last_updated: today, last_updated_by: uid,
    } as never).select("id").single();
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success(`Project ${data.id} created`);
    qc.invalidateQueries({ queryKey: qk.projects });
    navigate({ to: "/proyek/$id", params: { id: data.id } });
  }

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader icon={FolderPlus} title={<>New project <span className="font-mono text-muted-foreground">{nextId}</span></>} sub="Starts with Yellow health and the ball with Sarana. You can change these later." />
      {!canEditProjects && <p className="mb-4 rounded-2xl bg-warning-soft p-3 text-sm">You do not have permission to create projects. Ask an admin to assign you the PIC role.</p>}
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-5">
          <QuickFill kind="project" onFill={applyAi} />
          <FormSection i={0} icon={Building2} title="Client & scope" hint="The client and use case">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Client" req><AiMark on={A("client")}><IconInput icon={Building2} value={f.client} onChange={(e) => set("client", e.target.value)} placeholder="Example: Bank Nusantara" /></AiMark></Field>
              <Field label="Product"><AiMark on={A("product")}><IconInput icon={Package} value={f.product} onChange={(e) => set("product", e.target.value)} placeholder="Example: Sarana Chat" /></AiMark></Field>
            </div>
            <Field label="Use case" req><AiMark on={A("project")}><IconInput icon={Lightbulb} value={f.project} onChange={(e) => set("project", e.target.value)} placeholder="Example: Customer support chatbot" /></AiMark></Field>
          </FormSection>

          <FormSection i={1} icon={Users} title="Team" hint="The people responsible for this project">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="PIC" req><AiMark on={A("pic")}><PersonSelect value={f.pic} onChange={(v) => set("pic", v ?? "")} titles={["pic", "lead"]} placeholder="Select PIC" allowEmpty={false} /></AiMark></Field>
              <Field label="AM"><AiMark on={A("am")}><PersonSelect value={f.am} onChange={(v) => set("am", v ?? "")} titles={["am"]} placeholder="Select AM" /></AiMark></Field>
              <Field label="PM"><AiMark on={A("pm")}><PersonSelect value={f.pm} onChange={(v) => set("pm", v ?? "")} titles={["pm"]} placeholder="Select PM" /></AiMark></Field>
            </div>
          </FormSection>

          <FormSection i={2} icon={Target} title="Next steps" hint="Format with bold, highlights, headings and checklists">
            <Field label="Next action" req><AiMark on={A("next_action")}>
              <RichTextEditor value={f.next_action} onChange={(v) => set("next_action", v)} placeholder="What needs to happen next? Type ## for a heading, - for a list, [] for a checklist" minHeight={110} />
            </AiMark></Field>
            <Field label="Due" req hint="Today or later" className="sm:max-w-xs"><AiMark on={A("next_action_due")}><IconInput icon={CalendarClock} type="date" min={today} value={f.next_action_due} onChange={(e) => set("next_action_due", e.target.value)} /></AiMark></Field>
          </FormSection>

          <FormSection i={3} icon={Rocket} title="Detail" hint="Initial stage and business potential">
            <Field label="Stage"><AiMark on={A("stage")}>
              <ChipSelect value={f.stage} onChange={(v) => set("stage", v)} options={[{ v: "Pipeline", l: "Pipeline", icon: Sparkles }, { v: "POC", l: "POC", icon: FlaskConical }]} />
            </AiMark></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={f.stage === "POC" ? "Target Go/No-Go" : "Planned POC kickoff"}><AiMark on={A("target_date")}><IconInput icon={CalendarClock} type="date" value={f.target_date} onChange={(e) => set("target_date", e.target.value)} /></AiMark></Field>
              <Field label="Potential ARR"><AiMark on={A("arr")}><IconInput icon={Coins} prefix="Rp" suffix="million" inputMode="numeric" value={f.arr} onChange={(e) => set("arr", e.target.value.replace(/[^0-9.]/g, ""))} placeholder="0" /></AiMark></Field>
            </div>
          </FormSection>

          <FormActions>
            <span className="mr-auto pl-3 text-xs text-muted-foreground">{missing.length ? `Missing: ${missing.join(", ")}` : "Ready to create"}</span>
            <Button variant="ghost" asChild><Link to="/register">Cancel</Link></Button>
            <Button onClick={create} disabled={busy || !canEditProjects}><FolderPlus className="mr-1 h-4 w-4" />Create project</Button>
          </FormActions>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-6 lg:self-start">
          <div className="rounded-[1.75rem] rounded-tl-[3rem] bg-card p-5 shadow-lift">
            <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">Card preview</div>
            <div className="font-mono text-xs text-muted-foreground">{nextId}</div>
            <div className="font-serif text-2xl font-bold leading-tight text-heading">{f.client || "Client name"}</div>
            <div className="text-sm text-muted-foreground">{f.project || "Project use case"}</div>
            <div className="mt-3 flex flex-wrap gap-1.5"><StagePill s={f.stage as "Pipeline"} /><HealthPill h="Yellow" /></div>
            <div className="mt-3 line-clamp-3 text-sm"><span className="mr-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Next</span>{nextText || <i className="text-muted-foreground">not provided</i>}</div>
            <div className="mt-4">
              <div className="mb-1 flex justify-between text-xs text-muted-foreground"><span>Completeness</span><span>{done}/5</span></div>
              <div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${done * 20}%` }} /></div>
            </div>
          </div>
          <div className="rounded-[1.75rem] bg-powder/40 p-5">
            <Illustration name="busy" className="mx-auto mb-2 h-28 w-28" />
            <ul className="space-y-1.5 text-sm">
              {["A clear next action can be reviewed next week", "Use a checklist for multiple steps", "Highlight items that need the client's attention"].map((t) => (
                <li key={t} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{t}</li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
