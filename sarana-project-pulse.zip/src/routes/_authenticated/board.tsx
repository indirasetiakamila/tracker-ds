import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { ArrowLeft, ArrowRight, CalendarDays, Columns3, List, Plus, Search, X, Sparkles, FlaskConical, Scale, Code2, ClipboardCheck, Rocket, LifeBuoy, PauseCircle, type LucideIcon } from "lucide-react";
import { useProjects, usePicNames, useMe, type Project } from "@/lib/data";
import { BOARD_STAGES, daysOverdue, fmtDate, progress, stageSummary, todayWIB } from "@/lib/rules";
import { HealthDot, PageHeader, ProgressBar, ClientLogo } from "@/components/app/bits";
import { Illustration } from "@/components/app/fun";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { plainText } from "@/lib/richtext";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/board")({
  head: () => ({ meta: [{ title: "Project Kanban | Sarana DS" }, { name: "description", content: "The delivery portfolio, organised by stage with project owners, next actions and deadlines." }, { property: "og:title", content: "Project Kanban | Sarana DS" }, { property: "og:description", content: "Follow every delivery project from pipeline to hypercare on the Sarana Board." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Board,
});

const ICON: Record<string, LucideIcon> = { Pipeline: Sparkles, POC: FlaskConical, "Go/No-Go": Scale, Development: Code2, UAT: ClipboardCheck, "Go-Live": Rocket, Hypercare: LifeBuoy, "On Hold": PauseCircle };
const fmtArr = (n: number) => (n >= 1000 ? `${(n / 1000).toFixed(1)}B` : `${n.toLocaleString("en-US")}M`);

function Board() {
  const PICS = usePicNames();
  const { me } = useMe();
  const { data: projects = [], isPending } = useProjects();
  const [pic, setPic] = useState("all");
  const [health, setHealth] = useState("all");
  const [search, setSearch] = useState("");
  const [compact, setCompact] = useState(false);
  const board = useRef<HTMLDivElement>(null);
  const today = todayWIB();
  const query = search.trim().toLowerCase();
  const list = projects.filter((p) => (pic === "all" || p.pic === pic) && (health === "all" || p.health === health) && (!query || `${p.client} ${p.project} ${p.id} ${plainText(p.next_action)}`.toLowerCase().includes(query)));
  const sums = stageSummary(list);
  const total = sums.reduce((n, s) => n + s.count, 0);
  const totalArr = sums.reduce((n, s) => n + s.arr, 0);
  const filtered = pic !== "all" || health !== "all" || !!search;
  const reset = () => { setPic("all"); setHealth("all"); setSearch(""); };
  const scroll = (direction: number) => board.current?.scrollBy({ left: direction * 310, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" });
  const jump = (index: number) => {
    const container = board.current;
    const column = container?.querySelectorAll<HTMLElement>("[data-stage]")[index];
    if (container && column) container.scrollTo({ left: column.offsetLeft - container.offsetLeft, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" });
  };

  return (
    <div className="min-w-0">
      <PageHeader title="Project Board" sub={`${total} projects · Rp ${fmtArr(totalArr)} potential ARR`}>
        <Button asChild><Link to="/proyek/baru"><Plus />New Project</Link></Button>
      </PageHeader>

      <div className="mb-5 flex items-center justify-between gap-5 border-y py-4">
        <div className="min-w-0">
          <div className="eyebrow text-muted-foreground">The delivery portfolio</div>
          <p className="mt-1 font-serif text-2xl text-heading">From first conversation to <em>go-live.</em></p>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span>{total} in view</span><span className="inline-flex items-center gap-1.5"><HealthDot h="Red" />{sums.reduce((n, s) => n + s.red, 0)} at risk</span>
          </div>
        </div>
        <Illustration name="team" className="h-24 w-32 shrink-0 object-contain sm:h-28 sm:w-40" />
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-0 basis-full sm:basis-auto sm:flex-1 sm:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input aria-label="Search projects" placeholder="Search clients, projects or actions" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={pic} onValueChange={setPic}>
          <SelectTrigger aria-label="Filter by owner" className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All owners</SelectItem>{PICS.map((name) => <SelectItem key={name} value={name}>{name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={health} onValueChange={setHealth}>
          <SelectTrigger aria-label="Filter by health" className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All health</SelectItem>{(["Green", "Yellow", "Red"] as const).map((h) => <SelectItem key={h} value={h}><span className="inline-flex items-center gap-2"><HealthDot h={h} />{h}</span></SelectItem>)}</SelectContent>
        </Select>
        {me?.pic_name && <Button size="sm" variant={pic === me.pic_name ? "default" : "ghost"} onClick={() => setPic(pic === me.pic_name ? "all" : me.pic_name ?? "all")} aria-pressed={pic === me.pic_name}>Only mine</Button>}
        {filtered && <Button variant="ghost" size="sm" onClick={reset}><X />Clear</Button>}
        <div className="ml-auto flex items-center gap-1">
          <Button variant="ghost" size="icon" aria-label={compact ? "Show detailed cards" : "Show compact cards"} title={compact ? "Detailed cards" : "Compact cards"} aria-pressed={compact} onClick={() => setCompact(!compact)}>{compact ? <Columns3 /> : <List />}</Button>
          <Button variant="outline" size="icon" aria-label="Previous columns" title="Previous columns" onClick={() => scroll(-1)}><ArrowLeft /></Button>
          <Button variant="outline" size="icon" aria-label="Next columns" title="Next columns" onClick={() => scroll(1)}><ArrowRight /></Button>
        </div>
      </div>

      <nav aria-label="Jump to stage" className="mb-4 flex flex-wrap gap-x-4 gap-y-2 border-b pb-3">
        {sums.map((sum, index) => <Button key={sum.stage} size="sm" variant="ghost" onClick={() => jump(index)} className="h-7 gap-2 px-0 text-xs text-muted-foreground hover:bg-transparent hover:text-primary">{sum.stage}<span className="tabular-nums text-foreground">{sum.count}</span></Button>)}
      </nav>

      {filtered && total === 0 && !isPending && <div className="mb-4 flex flex-wrap items-center justify-between gap-3 bg-muted px-4 py-3 text-sm"><span>No projects match these filters.</span><Button size="sm" variant="link" onClick={reset}>Clear filters</Button></div>}
      <div ref={board} tabIndex={0} role="region" aria-label="Project Kanban" aria-busy={isPending} className="relative flex max-w-full snap-x snap-proximity gap-4 overflow-x-auto overscroll-x-contain pb-5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
        {sums.map((sum, index) => {
          const col = list.filter((p) => p.stage === sum.stage);
          const Icon = ICON[sum.stage] ?? Sparkles;
          return (
            <section data-stage={sum.stage} aria-label={`${sum.stage} projects`} key={sum.stage} className="w-[286px] max-w-[85vw] shrink-0 snap-start">
              <header className="mb-3 border-t-2 border-primary/25 pt-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2"><span className="text-[10px] tabular-nums text-muted-foreground">{String(index + 1).padStart(2, "0")}</span><h2 className="text-2xl"><em>{sum.stage}</em></h2><span className="flex h-5 min-w-5 items-center justify-center rounded bg-muted px-1 text-xs tabular-nums">{sum.count}</span></div>
                  <Icon className="h-4 w-4 shrink-0 text-primary/60" />
                </div>
                <div className="mt-1.5 flex items-center justify-between gap-2 text-xs text-muted-foreground"><span>Rp {fmtArr(sum.arr)} ARR</span>{sum.red > 0 && <span className="text-destructive">{sum.red} at risk</span>}</div>
              </header>
              <div className="min-h-72 space-y-3 border-t border-border/60 bg-muted/40 px-2 py-3">
                {isPending ? [0, 1].map((n) => <div key={n} className="h-44 animate-pulse rounded-lg border bg-card p-4"><div className="h-5 w-2/3 rounded bg-muted" /><div className="mt-4 h-3 w-full rounded bg-muted" /><div className="mt-2 h-3 w-1/2 rounded bg-muted" /></div>) : col.map((p) => <BoardCard key={p.id} p={p} today={today} compact={compact} />)}
                {!isPending && col.length === 0 && <div className="flex min-h-64 flex-col items-center justify-center gap-3 text-muted-foreground"><Illustration name="empty" className="h-20 w-20 opacity-70" /><span className="font-serif text-lg italic">No projects yet</span></div>}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function BoardCard({ p, today, compact }: { p: Project; today: string; compact: boolean }) {
  const od = daysOverdue(p, today);
  const pr = progress(p);
  const due = p.next_action_due;
  const dueLate = !!due && due < today;
  const action = plainText(p.next_action);
  return (
    <Link to="/proyek/$id" params={{ id: p.id }} className="group block min-w-0 rounded-lg border bg-card p-4 text-sm transition-colors hover:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
      <div className="mb-3 flex items-center justify-between gap-2"><span className="truncate font-mono text-[10px] text-muted-foreground">{p.id}</span><span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground"><HealthDot h={p.health} />{p.health}</span></div>
      <div className="flex items-start gap-2.5"><ClientLogo client={p.client} className="h-9 w-9 shrink-0 text-[10px]" /><div className="min-w-0"><div className="break-words font-serif text-xl font-semibold leading-tight text-heading group-hover:text-primary">{p.client}</div><div className="mt-1 line-clamp-2 break-words text-xs leading-relaxed text-muted-foreground">{p.project}</div></div></div>
      {!compact && <>
        {action && <div className="mt-4 border-t pt-3"><div className="mb-1 text-[10px] font-semibold uppercase text-muted-foreground">Next action</div><p className="line-clamp-2 break-words text-xs leading-relaxed">{action}</p></div>}
        {pr !== null && <div className="mt-3 flex items-center gap-2"><ProgressBar value={pr} className="flex-1" /><span className="text-[10px] tabular-nums text-muted-foreground">{pr}%</span></div>}
      </>}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t pt-3 text-[11px]"><span className="inline-flex min-w-0 items-center gap-1.5"><span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary-soft text-[9px] font-semibold text-primary">{p.pic.slice(0, 2).toUpperCase()}</span><span className="max-w-28 truncate">{p.pic}</span></span>{due && <span className={cn("inline-flex items-center gap-1", dueLate ? "text-destructive" : "text-muted-foreground")}><CalendarDays className="h-3 w-3" />{fmtDate(due)}</span>}</div>
      {od > 0 && <div className="mt-2 text-[11px] font-semibold text-destructive">Stage overdue by {od}d</div>}
    </Link>
  );
}
