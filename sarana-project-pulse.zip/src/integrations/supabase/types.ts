export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      activity: {
        Row: {
          at: string
          by: string | null
          id: string
          kind: string
          project_id: string
          text: string
        }
        Insert: {
          at?: string
          by?: string | null
          id?: string
          kind?: string
          project_id: string
          text?: string
        }
        Update: {
          at?: string
          by?: string | null
          id?: string
          kind?: string
          project_id?: string
          text?: string
        }
        Relationships: [
          {
            foreignKeyName: "activity_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      assistant_insights: {
        Row: {
          body_html: string
          confidence: string | null
          created_at: string
          created_by: string
          id: string
          key_name: string | null
          kind: string
          project_id: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          snoozed_until: string | null
          source: string | null
          status: string
          suggested_due: string | null
          suggested_owner: string | null
          title: string
        }
        Insert: {
          body_html?: string
          confidence?: string | null
          created_at?: string
          created_by?: string
          id?: string
          key_name?: string | null
          kind?: string
          project_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          snoozed_until?: string | null
          source?: string | null
          status?: string
          suggested_due?: string | null
          suggested_owner?: string | null
          title: string
        }
        Update: {
          body_html?: string
          confidence?: string | null
          created_at?: string
          created_by?: string
          id?: string
          key_name?: string | null
          kind?: string
          project_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          snoozed_until?: string | null
          source?: string | null
          status?: string
          suggested_due?: string | null
          suggested_owner?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "assistant_insights_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      client_logos: {
        Row: {
          client: string
          updated_at: string
          updated_by: string | null
          url: string
        }
        Insert: {
          client: string
          updated_at?: string
          updated_by?: string | null
          url: string
        }
        Update: {
          client?: string
          updated_at?: string
          updated_by?: string | null
          url?: string
        }
        Relationships: []
      }
      mcp_keys: {
        Row: {
          created_at: string
          id: string
          key_hash: string
          last_used_at: string | null
          name: string
          revoked_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          key_hash: string
          last_used_at?: string | null
          name: string
          revoked_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          key_hash?: string
          last_used_at?: string | null
          name?: string
          revoked_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      people: {
        Row: {
          active: boolean
          created_at: string
          email: string | null
          id: string
          name: string
          title: Database["public"]["Enums"]["person_title"]
          user_id: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          email?: string | null
          id?: string
          name: string
          title?: Database["public"]["Enums"]["person_title"]
          user_id?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          title?: Database["public"]["Enums"]["person_title"]
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "people_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          id: string
          name: string
          pic_name: string | null
        }
        Insert: {
          created_at?: string
          email?: string
          id: string
          name?: string
          pic_name?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          name?: string
          pic_name?: string | null
        }
        Relationships: []
      }
      projects: {
        Row: {
          am: string | null
          ball_in_court: Database["public"]["Enums"]["ball"] | null
          blocker: string | null
          checklist: Json
          client: string
          created_at: string | null
          handover_active: boolean | null
          handover_pp: Json | null
          health: Database["public"]["Enums"]["health"] | null
          hold_checklist: Json | null
          id: string
          last_updated: string | null
          last_updated_by: string | null
          next_action: string | null
          next_action_due: string | null
          next_action_owner: string | null
          pic: string
          pm: string | null
          potential_arr_idr_million: number | null
          prev_stage: Database["public"]["Enums"]["stage"] | null
          product: string | null
          project: string
          signoff_status: string | null
          source_gid: string | null
          stage: Database["public"]["Enums"]["stage"]
          target_date: string | null
        }
        Insert: {
          am?: string | null
          ball_in_court?: Database["public"]["Enums"]["ball"] | null
          blocker?: string | null
          checklist?: Json
          client: string
          created_at?: string | null
          handover_active?: boolean | null
          handover_pp?: Json | null
          health?: Database["public"]["Enums"]["health"] | null
          hold_checklist?: Json | null
          id?: string
          last_updated?: string | null
          last_updated_by?: string | null
          next_action?: string | null
          next_action_due?: string | null
          next_action_owner?: string | null
          pic: string
          pm?: string | null
          potential_arr_idr_million?: number | null
          prev_stage?: Database["public"]["Enums"]["stage"] | null
          product?: string | null
          project?: string
          signoff_status?: string | null
          source_gid?: string | null
          stage?: Database["public"]["Enums"]["stage"]
          target_date?: string | null
        }
        Update: {
          am?: string | null
          ball_in_court?: Database["public"]["Enums"]["ball"] | null
          blocker?: string | null
          checklist?: Json
          client?: string
          created_at?: string | null
          handover_active?: boolean | null
          handover_pp?: Json | null
          health?: Database["public"]["Enums"]["health"] | null
          hold_checklist?: Json | null
          id?: string
          last_updated?: string | null
          last_updated_by?: string | null
          next_action?: string | null
          next_action_due?: string | null
          next_action_owner?: string | null
          pic?: string
          pm?: string | null
          potential_arr_idr_million?: number | null
          prev_stage?: Database["public"]["Enums"]["stage"] | null
          product?: string | null
          project?: string
          signoff_status?: string | null
          source_gid?: string | null
          stage?: Database["public"]["Enums"]["stage"]
          target_date?: string | null
        }
        Relationships: []
      }
      task_comments: {
        Row: {
          at: string
          by: string | null
          id: string
          kind: string
          task_id: string
          text: string
        }
        Insert: {
          at?: string
          by?: string | null
          id?: string
          kind?: string
          task_id: string
          text: string
        }
        Update: {
          at?: string
          by?: string | null
          id?: string
          kind?: string
          task_id?: string
          text?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_comments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          assignee: string | null
          assignee_person: string | null
          created_at: string
          description: string
          done_at: string | null
          due: string | null
          estimate_hours: number | null
          id: string
          key: string
          prio: Database["public"]["Enums"]["task_prio"]
          project_id: string
          reporter: string | null
          sort_order: number
          status: Database["public"]["Enums"]["task_status"]
          title: string
          type: Database["public"]["Enums"]["task_type"]
          updated_at: string
        }
        Insert: {
          assignee?: string | null
          assignee_person?: string | null
          created_at?: string
          description?: string
          done_at?: string | null
          due?: string | null
          estimate_hours?: number | null
          id?: string
          key?: string
          prio?: Database["public"]["Enums"]["task_prio"]
          project_id: string
          reporter?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["task_status"]
          title: string
          type?: Database["public"]["Enums"]["task_type"]
          updated_at?: string
        }
        Update: {
          assignee?: string | null
          assignee_person?: string | null
          created_at?: string
          description?: string
          done_at?: string | null
          due?: string | null
          estimate_hours?: number | null
          id?: string
          key?: string
          prio?: Database["public"]["Enums"]["task_prio"]
          project_id?: string
          reporter?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["task_status"]
          title?: string
          type?: Database["public"]["Enums"]["task_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assignee_fkey"
            columns: ["assignee"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_assignee_person_fkey"
            columns: ["assignee_person"]
            isOneToOne: false
            referencedRelation: "people"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      todos: {
        Row: {
          carried_count: number
          created_at: string
          date: string
          done: boolean
          done_at: string | null
          id: string
          owner: string
          project_id: string | null
          sort_order: number
          text: string
        }
        Insert: {
          carried_count?: number
          created_at?: string
          date?: string
          done?: boolean
          done_at?: string | null
          id?: string
          owner?: string
          project_id?: string | null
          sort_order?: number
          text: string
        }
        Update: {
          carried_count?: number
          created_at?: string
          date?: string
          done?: boolean
          done_at?: string | null
          id?: string
          owner?: string
          project_id?: string | null
          sort_order?: number
          text?: string
        }
        Relationships: [
          {
            foreignKeyName: "todos_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      checklist_items: { Args: { _stage: string }; Returns: string[] }
      create_mcp_key: {
        Args: { _hash: string; _name: string }
        Returns: string
      }
      empty_checklist: { Args: never; Returns: Json }
      has_any_role: {
        Args: {
          _roles: Database["public"]["Enums"]["app_role"][]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_registered: { Args: never; Returns: boolean }
      next_project_id: { Args: never; Returns: string }
      peek_project_id: { Args: never; Returns: string }
      pname: { Args: { _id: string }; Returns: string }
    }
    Enums: {
      app_role: "pic" | "engineer" | "lead" | "admin"
      ball: "Sarana" | "Client"
      health: "Green" | "Yellow" | "Red"
      person_title: "engineer" | "pm" | "am" | "pic" | "lead"
      stage:
        | "Pipeline"
        | "POC"
        | "Go/No-Go"
        | "Development"
        | "UAT"
        | "Go-Live"
        | "Hypercare"
        | "On Hold"
        | "Closed-No Go"
      task_prio: "P1" | "P2" | "P3" | "P4"
      task_status: "To do" | "In progress" | "In review" | "Blocked" | "Done"
      task_type: "Feature" | "Bug" | "Improvement" | "Chore"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["pic", "engineer", "lead", "admin"],
      ball: ["Sarana", "Client"],
      health: ["Green", "Yellow", "Red"],
      person_title: ["engineer", "pm", "am", "pic", "lead"],
      stage: [
        "Pipeline",
        "POC",
        "Go/No-Go",
        "Development",
        "UAT",
        "Go-Live",
        "Hypercare",
        "On Hold",
        "Closed-No Go",
      ],
      task_prio: ["P1", "P2", "P3", "P4"],
      task_status: ["To do", "In progress", "In review", "Blocked", "Done"],
      task_type: ["Feature", "Bug", "Improvement", "Chore"],
    },
  },
} as const
