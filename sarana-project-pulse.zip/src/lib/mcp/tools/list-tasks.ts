import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "list_tasks",
  title: "List tasks",
  description: "List engineering tasks, optionally filtered by project ID or status.",
  inputSchema: {
    project_id: z.string().optional().describe("Project ID like DS-012."),
    status: z.enum(["To do", "In progress", "In review", "Blocked", "Done"]).optional().describe("Status filter."),
  },
  annotations: { readOnlyHint: true, openWorldHint: false },
  handler: async ({ project_id, status }, ctx) => {
    let q = dbFor(ctx).db.from("tasks").select("key, title, project_id, type, prio, status, due, assignee_person").order("created_at", { ascending: false }).limit(200);
    if (project_id) q = q.eq("project_id", project_id.toUpperCase());
    if (status) q = q.eq("status", status);
    const { data, error } = await q;
    if (error) fail(error.message);
    const tasks = (data ?? []).map((t) => ({ key: t.key, title: t.title, project_id: t.project_id, type: t.type, prio: t.prio, status: t.status, due: t.due }));
    return { content: [{ type: "text", text: tasks.map((t) => `${t.key} [${t.status}] ${t.prio} ${t.type}: ${t.title} (${t.project_id})`).join("\n") || "No tasks found." }], structuredContent: { tasks } };
  },
});

export default make(supabaseForUser);
