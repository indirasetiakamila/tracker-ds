import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail, plain } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "list_projects",
  title: "List projects",
  description: "List projects in the DS Project Register, optionally filtered by PIC, stage, health, or a search term.",
  inputSchema: {
    pic: z.string().optional().describe("PIC name, e.g. Indira."),
    stage: z.string().optional().describe("Stage, e.g. Pipeline, POC, Development."),
    health: z.enum(["Green", "Yellow", "Red"]).optional().describe("Health filter."),
    search: z.string().optional().describe("Text to match in client or use case."),
  },
  annotations: { readOnlyHint: true, openWorldHint: false },
  handler: async ({ pic, stage, health, search }, ctx) => {
    const { db } = dbFor(ctx);
    let q = db.from("projects").select("id, client, project, pic, stage, health, ball_in_court, next_action, next_action_due, last_updated").order("id").limit(200);
    if (pic) q = q.eq("pic", pic);
    if (stage) q = q.eq("stage", stage as never);
    if (health) q = q.eq("health", health);
    if (search) q = q.or(`client.ilike.%${search.replace(/[,()%]/g, "")}%,project.ilike.%${search.replace(/[,()%]/g, "")}%`);
    const { data, error } = await q;
    if (error) fail(error.message);
    const rows = (data ?? []).map((p) => ({ id: p.id, client: p.client, use_case: p.project, pic: p.pic, stage: p.stage, health: p.health, ball: p.ball_in_court, next_action: plain(p.next_action), due: p.next_action_due, last_updated: p.last_updated }));
    return { content: [{ type: "text", text: rows.length ? rows.map((r) => `${r.id} | ${r.client} | ${r.use_case} | ${r.pic} | ${r.stage} | ${r.health ?? "-"} | next: ${r.next_action || "-"} (due ${r.due ?? "-"})`).join("\n") : "No projects found." }], structuredContent: { projects: rows } };
  },
});

export default make(supabaseForUser);
