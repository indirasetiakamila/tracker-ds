import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { WIB_TODAY, fail, toHtml } from "../util";
import { emptyChecklist } from "@/lib/rules";

export const make = (dbFor: DbFor) => defineTool({
  name: "create_project",
  title: "Create project",
  description: "Create a new project in the register. Starts at health Yellow with the ball at Sarana. Requires PIC role.",
  inputSchema: {
    client: z.string().min(1).describe("Client name."),
    use_case: z.string().min(1).describe("Use case, e.g. 'Customer support chatbot'."),
    pic: z.string().min(1).describe("PIC name from list_people."),
    next_action: z.string().min(1).describe("Next action. Supports '- ' bullets, '## ' headings, **bold**, ==highlight==."),
    next_action_due: z.string().describe("Due date YYYY-MM-DD, today or later (WIB)."),
    stage: z.enum(["Pipeline", "POC"]).optional().describe("Starting stage, default Pipeline."),
    product: z.string().optional().describe("Product name."),
    am: z.string().optional().describe("AM name."),
    pm: z.string().optional().describe("PM name."),
    potential_arr_idr_million: z.number().optional().describe("Potential ARR in IDR million."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async (a, ctx) => {
    const today = WIB_TODAY();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(a.next_action_due) || a.next_action_due < today) fail("next_action_due must use YYYY-MM-DD and be today or later.");
    const { data, error } = await dbFor(ctx).db.from("projects").insert({
      client: a.client.trim(), project: a.use_case.trim(), pic: a.pic, next_action: toHtml(a.next_action), next_action_due: a.next_action_due,
      stage: a.stage ?? "Pipeline", product: a.product ?? "", am: a.am ?? "", pm: a.pm ?? "", potential_arr_idr_million: a.potential_arr_idr_million ?? null,
      checklist: emptyChecklist(), health: "Yellow", ball_in_court: "Sarana", last_updated: today, last_updated_by: dbFor(ctx).uid,
    } as never).select("id").single();
    if (error) fail(error.message);
    return { content: [{ type: "text", text: `Project ${data.id} created.` }], structuredContent: { id: data.id } };
  },
});

export default make(supabaseForUser);
