import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { WIB_TODAY, fail, toHtml } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "create_task",
  title: "Create task",
  description: "Create an engineering task on a project.",
  inputSchema: {
    project_id: z.string().describe("Project ID like DS-012."),
    title: z.string().min(1).describe("Short task title."),
    description: z.string().optional().describe("Description. Supports '## ' headings, '- ' bullets, **bold**, ==highlight==."),
    type: z.enum(["Feature", "Bug", "Improvement", "Chore"]).optional().describe("Default Feature."),
    prio: z.enum(["P1", "P2", "P3", "P4"]).optional().describe("Default P3."),
    engineer_person_id: z.string().optional().describe("Person id from list_people (title engineer)."),
    estimate_hours: z.number().optional().describe("Estimate in hours."),
    due: z.string().optional().describe("Due date YYYY-MM-DD, today or later."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async (a, ctx) => {
    if (a.due && (!/^\d{4}-\d{2}-\d{2}$/.test(a.due) || a.due < WIB_TODAY())) fail("due must use YYYY-MM-DD and be today or later.");
    const { db } = dbFor(ctx);
    let assignee: string | null = null;
    if (a.engineer_person_id) {
      const { data: person } = await db.from("people").select("user_id").eq("id", a.engineer_person_id).maybeSingle();
      if (!person) fail("Unknown engineer_person_id. Use list_people.");
      assignee = person.user_id;
    }
    const { data, error } = await db.from("tasks").insert({
      project_id: a.project_id.toUpperCase(), title: a.title.trim(), description: a.description ? toHtml(a.description) : "",
      type: a.type ?? "Feature", prio: a.prio ?? "P3", status: "To do", assignee_person: a.engineer_person_id ?? null, assignee,
      estimate_hours: a.estimate_hours ?? null, due: a.due ?? null,
    }).select("key").single();
    if (error) fail(error.message);
    return { content: [{ type: "text", text: `Task ${data.key} created.` }], structuredContent: { key: data.key } };
  },
});

export default make(supabaseForUser);
