import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail, plain } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "get_project",
  title: "Get project",
  description: "Get full details of one project by its ID (e.g. DS-012).",
  inputSchema: { id: z.string().describe("Project ID like DS-012.") },
  annotations: { readOnlyHint: true, openWorldHint: false },
  handler: async ({ id }, ctx) => {
    const { data: p, error } = await dbFor(ctx).db.from("projects").select("*").eq("id", id.toUpperCase()).maybeSingle();
    if (error) fail(error.message);
    if (!p) fail(`Project ${id} not found.`);
    const project = { id: p.id, client: p.client, use_case: p.project, product: p.product, pic: p.pic, am: p.am, pm: p.pm, stage: p.stage, health: p.health, ball_in_court: p.ball_in_court, blocker: p.blocker, next_action: plain(p.next_action), next_action_owner: p.next_action_owner, next_action_due: p.next_action_due, target_date: p.target_date, potential_arr_idr_million: p.potential_arr_idr_million, last_updated: p.last_updated };
    return { content: [{ type: "text", text: Object.entries(project).map(([k, v]) => `${k}: ${v ?? "-"}`).join("\n") }], structuredContent: { project } };
  },
});

export default make(supabaseForUser);
