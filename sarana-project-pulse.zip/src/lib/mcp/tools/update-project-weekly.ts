import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { WIB_TODAY, fail, toHtml } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "update_project_weekly",
  title: "Weekly project update",
  description: "Submit this week's update for a project: health, ball in court, next action, owner, due, blocker. Only fields given are changed. Stage changes stay in the app (they need checklist gates).",
  inputSchema: {
    id: z.string().describe("Project ID like DS-012."),
    health: z.enum(["Green", "Yellow", "Red"]).optional().describe("Health this week."),
    ball_in_court: z.enum(["Sarana", "Client"]).optional().describe("Who holds the ball."),
    next_action: z.string().optional().describe("Next action. Supports '- ' bullets, '## ' headings, **bold**, ==highlight==."),
    next_action_owner: z.string().optional().describe("Owner name from list_people."),
    next_action_due: z.string().optional().describe("Due date YYYY-MM-DD, today or later."),
    blocker: z.string().optional().describe("Blocker text; required when health is Red."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
  handler: async (a, ctx) => {
    const today = WIB_TODAY();
    const { db, uid } = dbFor(ctx);
    const id = a.id.toUpperCase();
    const { data: cur, error: e1 } = await db.from("projects").select("blocker, next_action, next_action_due").eq("id", id).maybeSingle();
    if (e1) fail(e1.message);
    if (!cur) fail(`Project ${id} not found.`);
    if (a.next_action_due && (!/^\d{4}-\d{2}-\d{2}$/.test(a.next_action_due) || a.next_action_due < today)) fail("next_action_due must use YYYY-MM-DD and be today or later.");
    if (a.health === "Red" && !(a.blocker ?? cur.blocker)?.trim()) fail("Red health requires a blocker.");
    const patch: Record<string, unknown> = { last_updated: today, last_updated_by: uid };
    if (a.health) patch["health"] = a.health;
    if (a.ball_in_court) patch["ball_in_court"] = a.ball_in_court;
    if (a.next_action !== undefined) patch["next_action"] = toHtml(a.next_action);
    if (a.next_action_owner !== undefined) patch["next_action_owner"] = a.next_action_owner;
    if (a.next_action_due) patch["next_action_due"] = a.next_action_due;
    if (a.blocker !== undefined) patch["blocker"] = a.blocker;
    const { data, error } = await db.from("projects").update(patch as never).eq("id", id).select("id");
    if (error) fail(error.message);
    if (!data?.length) fail("You do not have permission to update this project.");
    return { content: [{ type: "text", text: `Weekly update for ${id} saved.` }] };
  },
});

export default make(supabaseForUser);
