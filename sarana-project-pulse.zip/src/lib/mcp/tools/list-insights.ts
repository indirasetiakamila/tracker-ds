import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "list_insights",
  title: "List insights",
  description: "List inbox items from the last 4 weeks with their review status, so you avoid repeating dismissed or already handled items.",
  inputSchema: { status: z.enum(["new", "accepted", "dismissed", "applied", "snoozed"]).optional() },
  annotations: { readOnlyHint: true, openWorldHint: false },
  handler: async ({ status }, ctx) => {
    let q = dbFor(ctx).db.from("assistant_insights").select("id, created_at, kind, title, project_id, status")
      .gte("created_at", new Date(Date.now() - 28 * 86400000).toISOString()).order("created_at", { ascending: false }).limit(200);
    if (status) q = q.eq("status", status);
    const { data, error } = await q;
    if (error) fail(error.message);
    const items = (data ?? []).map((i) => ({ id: i.id, created_at: i.created_at, kind: i.kind, title: i.title, project_id: i.project_id, status: i.status }));
    return { content: [{ type: "text", text: items.map((i) => `[${i.status}] ${i.kind}: ${i.title}${i.project_id ? ` (${i.project_id})` : ""} ${i.created_at.slice(0, 10)}`).join("\n") || "Inbox is empty." }], structuredContent: { items } };
  },
});

export default make(supabaseForUser);
