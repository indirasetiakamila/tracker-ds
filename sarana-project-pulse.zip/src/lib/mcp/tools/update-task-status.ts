import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "update_task_status",
  title: "Update task status",
  description: "Set the status of an engineering task by its key.",
  inputSchema: {
    key: z.string().describe("Task key like DS-012-3."),
    status: z.enum(["To do", "In progress", "In review", "Blocked", "Done"]).describe("New status."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
  handler: async ({ key, status }, ctx) => {
    const { data, error } = await dbFor(ctx).db.from("tasks").update({ status }).eq("key", key).select("key");
    if (error) fail(error.message);
    if (!data?.length) fail(`Task ${key} was not found or cannot be updated.`);
    return { content: [{ type: "text", text: `${key} is now ${status}.` }] };
  },
});

export default make(supabaseForUser);
