import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail, toHtml } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "send_insight",
  title: "Send insight",
  description: "Send one insight or suggested action (e.g. from WhatsApp updates) to the Sarana AI Assistants inbox for human review. Nothing in the register changes until a person applies it.",
  inputSchema: {
    kind: z.enum(["insight", "action"]).describe("'insight' = something worth knowing; 'action' = something someone should do."),
    title: z.string().min(3).max(200).describe("One-line summary."),
    detail: z.string().max(5000).optional().describe("Details. Supports '- ' bullets, '## ' headings, **bold**, ==highlight==."),
    project: z.string().optional().describe("Project id (DS-xx) or client name. Use list_projects to find it."),
    suggested_owner: z.string().optional().describe("Suggested owner name from list_people."),
    suggested_due: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().describe("Suggested due date YYYY-MM-DD (WIB)."),
    source: z.string().max(200).optional().describe("Where it came from, e.g. 'WA group BPR KS, 30 Oct'."),
    confidence: z.enum(["low", "medium", "high"]).optional(),
  },
  annotations: { readOnlyHint: false, openWorldHint: false },
  handler: async (a, ctx) => {
    const { db, uid } = dbFor(ctx);
    if (!uid) fail("Not signed in");
    let projectId: string | null = null;
    if (a.project) {
      const p = a.project.trim();
      const { data: byId } = await db.from("projects").select("id").eq("id", p).maybeSingle();
      if (byId) projectId = byId.id;
      else {
        const { data: byClient } = await db.from("projects").select("id").ilike("client", `%${p}%`).limit(2);
        if (byClient?.length === 1) projectId = byClient[0]!.id;
        else if ((byClient?.length ?? 0) > 1) fail(`More than one project matches "${p}". Pass the project id.`);
      }
    }
    const since = new Date(Date.now() - 86400000).toISOString();
    let dq = db.from("assistant_insights").select("id").eq("title", a.title).gte("created_at", since);
    dq = projectId ? dq.eq("project_id", projectId) : dq.is("project_id", null);
    const { data: dup } = await dq.limit(1);
    if (dup?.length) return { content: [{ type: "text", text: `Already in the inbox (id=${dup[0]!.id}). Skipped.` }] };
    const { data, error } = await db.from("assistant_insights").insert({
      created_by: uid, kind: a.kind, title: a.title, body_html: a.detail ? toHtml(a.detail) : "",
      project_id: projectId, suggested_owner: a.suggested_owner ?? null, suggested_due: a.suggested_due ?? null,
      source: a.source ?? null, confidence: a.confidence ?? null, key_name: "assistant",
    }).select("id").single();
    if (error) fail(error.message);
    return { content: [{ type: "text", text: `Sent to inbox (id=${data.id})${projectId ? ` for ${projectId}` : a.project ? `; no project matched "${a.project}"` : ""}.` }] };
  },
});

export default make(supabaseForUser);
