import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, type DbFor } from "../supabase";
import { fail } from "../util";

export const make = (dbFor: DbFor) => defineTool({
  name: "list_people",
  title: "List people",
  description: "List the team directory (valid names for PIC, AM, PM, owner and engineer fields).",
  inputSchema: { title: z.enum(["engineer", "pm", "am", "pic", "lead"]).optional().describe("Filter by job title.") },
  annotations: { readOnlyHint: true, openWorldHint: false },
  handler: async ({ title }, ctx) => {
    let q = dbFor(ctx).db.from("people").select("id, name, title").eq("active", true).order("name");
    if (title) q = q.eq("title", title);
    const { data, error } = await q;
    if (error) fail(error.message);
    const people = (data ?? []).map((p) => ({ id: p.id, name: p.name, title: p.title }));
    return { content: [{ type: "text", text: people.map((p) => `${p.name} (${p.title}) id=${p.id}`).join("\n") || "No people found." }], structuredContent: { people } };
  },
});

export default make(supabaseForUser);
