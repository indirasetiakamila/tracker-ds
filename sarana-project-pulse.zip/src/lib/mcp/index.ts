import { auth, defineMcp } from "@lovable.dev/mcp-js";
import type { Db } from "./supabase";
import listProjects, { make as mListProjects } from "./tools/list-projects";
import getProject, { make as mGetProject } from "./tools/get-project";
import listPeople, { make as mListPeople } from "./tools/list-people";
import createProject, { make as mCreateProject } from "./tools/create-project";
import updateProjectWeekly, { make as mUpdateProjectWeekly } from "./tools/update-project-weekly";
import listTasks, { make as mListTasks } from "./tools/list-tasks";
import createTask, { make as mCreateTask } from "./tools/create-task";
import sendInsight, { make as mSendInsight } from "./tools/send-insight";
import listInsights, { make as mListInsights } from "./tools/list-insights";
import updateTaskStatus, { make as mUpdateTaskStatus } from "./tools/update-task-status";

// Vite inlines the stable ref; the published SUPABASE_URL may be a proxy.
const projectRef = import.meta.env["VITE_SUPABASE_PROJECT_ID"] ?? "project-ref-unset";

const INFO = {
  name: "pixel-perfect-replica-64",
  title: "Pixel Perfect Replica (64)",
  version: "0.1.0",
  instructions: "Tools for the Sarana DS Project Register. Read projects, people and tasks; create projects and tasks; submit weekly project updates; send insights or suggested actions to the review inbox. Use list_people for valid names. Dates are YYYY-MM-DD in WIB.",
};

/** Same tools, bound to one key holder's session (used by the per-assistant key endpoint). */
export function mcpForKeySession(db: Db, uid: string) {
  const f = () => ({ db, uid });
  return defineMcp({ ...INFO, tools: [mListProjects(f), mGetProject(f), mListPeople(f), mCreateProject(f), mUpdateProjectWeekly(f), mListTasks(f), mCreateTask(f), mUpdateTaskStatus(f), mSendInsight(f), mListInsights(f)] });
}

export default defineMcp({
  name: "pixel-perfect-replica-64",
  title: "Pixel Perfect Replica (64)",
  version: "0.1.0",
  instructions: "Tools for the Sarana DS Project Register. Read projects, people and tasks; create projects and tasks; submit weekly project updates; send insights or suggested actions to the review inbox. Use list_people for valid names. Dates are YYYY-MM-DD in WIB.",
  auth: auth.oauth.issuer({ issuer: `https://${projectRef}.supabase.co/auth/v1`, acceptedAudiences: "authenticated" }),
  tools: [listProjects, getProject, listPeople, createProject, updateProjectWeekly, listTasks, createTask, updateTaskStatus, sendInsight, listInsights],
});
