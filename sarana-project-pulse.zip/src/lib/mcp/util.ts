import { ToolError } from "@lovable.dev/mcp-js";

export const WIB_TODAY = () => new Date(Date.now() + 7 * 3600_000).toISOString().slice(0, 10);
export const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
/** Turn plain/markdown-ish text from an assistant into the editor's HTML (paragraphs, bullets, headings). */
export function toHtml(text: string): string {
  const out: string[] = [];
  let list: string[] = [];
  const flush = () => { if (list.length) { out.push(`<ul>${list.join("")}</ul>`); list = []; } };
  const inline = (s: string) => esc(s).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/==(.+?)==/g, "<mark>$1</mark>");
  for (const raw of text.split("\n")) {
    const l = raw.trimEnd();
    const b = l.match(/^\s*[-*]\s+(.*)$/);
    if (b) { list.push(`<li><p>${inline(b[1] ?? "")}</p></li>`); continue; }
    flush();
    const h = l.match(/^(#{2,3})\s+(.*)$/);
    if (h) { const n = (h[1] ?? "##").length; out.push(`<h${n}>${inline(h[2] ?? "")}</h${n}>`); }
    else if (l) out.push(`<p>${inline(l)}</p>`);
  }
  flush();
  return out.join("");
}
export function plain(v: string | null): string {
  return (v ?? "").replace(/<\/(p|h\d|li)>/g, " ").replace(/<[^>]+>/g, "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
}
export function fail(msg: string): never { throw new ToolError(msg); }
