import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { todayWIB } from "@/lib/rules";

export type Insight = {
  id: string; created_at: string; kind: string; title: string; body_html: string; project_id: string | null;
  suggested_owner: string | null; suggested_due: string | null; source: string | null; confidence: string | null;
  status: string; snoozed_until: string | null; reviewed_by: string | null; reviewed_at: string | null;
};

/** An item needs review when new, or snoozed until a date that has arrived. */
export const isOpen = (i: Pick<Insight, "status" | "snoozed_until">, today = todayWIB()) =>
  i.status === "new" || (i.status === "snoozed" && !!i.snoozed_until && i.snoozed_until <= today);

export function useInsights() {
  return useQuery({
    queryKey: ["insights"],
    queryFn: async () => {
      const since = new Date(Date.now() - 28 * 86400000).toISOString();
      const { data, error } = await supabase.from("assistant_insights").select("*").gte("created_at", since).order("created_at", { ascending: false });
      if (error) throw error;
      return data as Insight[];
    },
  });
}

export function useInboxCount() {
  const q = useInsights();
  return (q.data ?? []).filter((i) => isOpen(i)).length;
}
