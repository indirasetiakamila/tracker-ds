import { describe, expect, it } from "vitest";
import { generateKey, hashKey, isKeyFormat, keyIsUsable } from "./mcp-keys";

describe("mcp keys", () => {
  it("generates srn_ keys that pass the format check and are unique", () => {
    const a = generateKey();
    const b = generateKey();
    expect(isKeyFormat(a)).toBe(true);
    expect(a).not.toBe(b);
  });
  it("rejects malformed keys", () => {
    expect(isKeyFormat("srn_short")).toBe(false);
    expect(isKeyFormat("kbr_" + "a".repeat(43))).toBe(false);
  });
  it("hashes to 64 hex chars, same input same hash", async () => {
    const k = generateKey();
    const h = await hashKey(k);
    expect(h).toMatch(/^[0-9a-f]{64}$/);
    expect(await hashKey(k)).toBe(h);
    expect(h).not.toContain(k.slice(4, 12));
  });
  it("revoked or missing keys are not usable", () => {
    expect(keyIsUsable({ revoked_at: null })).toBe(true);
    expect(keyIsUsable({ revoked_at: "2026-10-30T00:00:00Z" })).toBe(false);
    expect(keyIsUsable(null)).toBe(false);
  });
});
