import { describe, it, expect } from "vitest";
import { stageSummary, healthMix, needsAttention, emptyChecklist, type ProjectLike } from "./rules";

const p = (o: Partial<ProjectLike> & { potential_arr_idr_million?: number | null } = {}) => ({
  id: "DS-1", stage: "POC" as const, checklist: emptyChecklist(), target_date: null, health: "Green" as const, ball_in_court: null,
  blocker: null, next_action: "x", next_action_due: "2026-11-06", last_updated: "2026-10-28", ...o,
});

describe("dashboard aggregates", () => {
  it("sums ARR and Red per stage", () => {
    const s = stageSummary([p({ potential_arr_idr_million: 100 }), p({ health: "Red", potential_arr_idr_million: 50 }), p({ stage: "Pipeline" })]);
    expect(s.find((x) => x.stage === "POC")).toEqual({ stage: "POC", count: 2, red: 1, arr: 150 });
    expect(s.find((x) => x.stage === "Pipeline")?.count).toBe(1);
  });
  it("counts health mix including not set", () => {
    expect(healthMix([p(), p({ health: null }), p({ health: "Red" })])).toEqual({ Green: 1, Yellow: 0, Red: 1, "Not set": 1 });
  });
  it("flags Red, overdue and 14+ days without update", () => {
    expect(needsAttention(p({ health: "Red" }), "2026-10-30")).toBe("Red");
    expect(needsAttention(p({ target_date: "2026-10-27" }), "2026-10-30")).toBe("3 days overdue");
    expect(needsAttention(p({ last_updated: "2026-10-10" }), "2026-10-30")).toBe("No update in 14+ days");
    expect(needsAttention(p(), "2026-10-30")).toBeNull();
  });
});

import { weekBucket } from "./rules";
describe("weekBucket", () => {
  it("groups by Monday-start weeks, keeps 4 weeks", () => {
    expect(weekBucket("2026-10-26", "2026-10-30")).toBe(0); // Mon same week
    expect(weekBucket("2026-10-25", "2026-10-30")).toBe(1); // previous Sunday
    expect(weekBucket("2026-10-05", "2026-10-30")).toBe(3);
    expect(weekBucket("2026-10-04", "2026-10-30")).toBeNull();
  });
});
