export type Phase = "focus" | "short" | "long";
export type FocusSettings = { focus: number; short: number; long: number; rounds: number; pauseOnBreak: boolean };
export const DEFAULT_SETTINGS: FocusSettings = { focus: 25, short: 5, long: 15, rounds: 4, pauseOnBreak: true };

/** Extract a YouTube video id and/or playlist id from a pasted link. Null for non-YouTube links. */
export function parseYouTubeUrl(input: string): { video?: string; list?: string } | null {
  const s = input.trim();
  if (/^[\w-]{11}$/.test(s)) return { video: s };
  let u: URL;
  try { u = new URL(s); } catch { return null; }
  const host = u.hostname.replace(/^(www\.|m\.|music\.)/, "");
  const ok = (v: string | null | undefined) => (v && /^[\w-]{11}$/.test(v) ? v : undefined);
  const list = u.searchParams.get("list") ?? undefined;
  let video: string | undefined;
  if (host === "youtu.be") video = ok(u.pathname.slice(1));
  else if (host === "youtube.com" || host === "youtube-nocookie.com") {
    video = ok(u.searchParams.get("v")) ?? ok(u.pathname.match(/^\/(?:embed|live|shorts)\/([\w-]{11})/)?.[1]);
  } else return null;
  if (!video && !list) return null;
  return { ...(video ? { video } : {}), ...(list ? { list } : {}) };
}

/** After a phase ends: every `rounds`-th completed focus is followed by a long break. */
export function nextPhase(phase: Phase, completedFocus: number, rounds: number): { phase: Phase; completedFocus: number } {
  if (phase !== "focus") return { phase: "focus", completedFocus };
  const done = completedFocus + 1;
  return { phase: done % rounds === 0 ? "long" : "short", completedFocus: done };
}

export function embedUrl(src: { video?: string; list?: string }): string {
  const p = new URLSearchParams({ enablejsapi: "1", autoplay: "1", rel: "0", playsinline: "1" });
  if (src.list) p.set("list", src.list);
  return `https://www.youtube-nocookie.com/embed/${src.video ?? "videoseries"}?${p}`;
}

export const mmss = (ms: number) => { const t = Math.max(0, Math.ceil(ms / 1000)); return `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`; };
