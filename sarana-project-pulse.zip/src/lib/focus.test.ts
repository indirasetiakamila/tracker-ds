import { describe, it, expect } from "vitest";
import { parseYouTubeUrl, nextPhase } from "./focus";

describe("parseYouTubeUrl", () => {
  it("reads watch, short, live and playlist links", () => {
    expect(parseYouTubeUrl("https://www.youtube.com/watch?v=jfKfPfyJRdk")).toEqual({ video: "jfKfPfyJRdk" });
    expect(parseYouTubeUrl("https://youtu.be/jfKfPfyJRdk")).toEqual({ video: "jfKfPfyJRdk" });
    expect(parseYouTubeUrl("https://www.youtube.com/live/jfKfPfyJRdk")).toEqual({ video: "jfKfPfyJRdk" });
    expect(parseYouTubeUrl("https://www.youtube.com/playlist?list=PL123")).toEqual({ list: "PL123" });
  });
  it("rejects other sites", () => {
    expect(parseYouTubeUrl("https://vimeo.com/123")).toBeNull();
    expect(parseYouTubeUrl("not a link")).toBeNull();
  });
});

describe("nextPhase", () => {
  it("4th focus round leads to a long break, others to short", () => {
    expect(nextPhase("focus", 0, 4)).toEqual({ phase: "short", completedFocus: 1 });
    expect(nextPhase("focus", 3, 4)).toEqual({ phase: "long", completedFocus: 4 });
    expect(nextPhase("long", 4, 4)).toEqual({ phase: "focus", completedFocus: 4 });
  });
});
