import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateKey, hashKey } from "./mcp-keys";

/** Creates a key for the signed-in user. The plain key is returned once and never stored. */
export const createMcpKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ name: z.string().trim().min(1).max(60) }).parse(d))
  .handler(async ({ data, context }) => {
    const key = generateKey();
    const { error } = await context.supabase.rpc("create_mcp_key", { _name: data.name, _hash: await hashKey(key) });
    if (error) throw new Error(error.message);
    return { key };
  });
