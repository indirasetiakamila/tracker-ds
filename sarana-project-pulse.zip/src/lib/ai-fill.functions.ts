import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const Input = z.object({
  kind: z.enum(["project", "task", "update"]),
  text: z.string().min(3).max(20000),
  today: z.string(),
  people: z.array(z.object({ id: z.string(), name: z.string(), title: z.string() })).max(500),
  projects: z.array(z.object({ id: z.string(), client: z.string(), project: z.string() })).max(1000),
});

const n = <T extends z.ZodTypeAny>(t: T) => t.nullable();
const schemas = {
  project: z.object({
    client: n(z.string()), project: n(z.string()), product: n(z.string()),
    pic: n(z.string()), am: n(z.string()), pm: n(z.string()),
    stage: n(z.enum(["Pipeline", "POC"])), next_action_html: n(z.string()), next_action_due: n(z.string()),
    target_date: n(z.string()), arr_idr_million: n(z.number()), notes: z.array(z.string()),
  }),
  task: z.object({
    title: n(z.string()), project_id: n(z.string()), engineer_id: n(z.string()),
    type: n(z.enum(["Feature", "Bug", "Improvement", "Chore"])), prio: n(z.enum(["P1", "P2", "P3", "P4"])),
    estimate_hours: n(z.number()), due: n(z.string()), description_html: n(z.string()), notes: z.array(z.string()),
  }),
  update: z.object({
    health: n(z.enum(["Green", "Yellow", "Red"])), ball_in_court: n(z.enum(["Sarana", "Client"])),
    next_action_html: n(z.string()), next_action_due: n(z.string()), next_action_owner: n(z.string()),
    blocker: n(z.string()), notes: z.array(z.string()),
  }),
};

const GUIDE = {
  project: "Fill a NEW PROJECT form. client = the customer company. project = the use case being built (e.g. WhatsApp CS chatbot), always fill it when described. product = only a named Sarana product, else null. pic/am/pm must be an exact person name from PEOPLE (pic from titles pic/lead, am from am, pm from pm) or null. next_action_html: the single next step as simple HTML (<p>, <ul><li>, <strong>, <mark>). arr_idr_million: potential annual revenue in IDR millions.",
  task: "Fill a NEW ENGINEERING TASK form. project_id must be an id from PROJECTS or null. engineer_id must be a person id from PEOPLE (title engineer/lead) or null. description_html uses <h3>Context</h3><p>..</p><h3>Work required</h3><ul data-type=\"taskList\"><li data-type=\"taskItem\" data-checked=\"false\"><p>..</p></li></ul><h3>Acceptance criteria</h3><p>..</p>.",
  update: "Fill a WEEKLY PROJECT UPDATE. next_action_owner must be an exact name from PEOPLE or null. blocker is plain text or null.",
};

export const aiFill = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return { ok: false as const, values: {} as Record<string, string | number | string[] | null>, error: "AI is not configured." };
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText, Output } = await import("ai");
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1", apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });
    const instructions = [
      "You extract structured form values from a messy pasted text (English or Bahasa Indonesia). Never invent facts: use null when the text does not say it.",
      GUIDE[data.kind],
      `Dates are YYYY-MM-DD in Asia/Jakarta. Today is ${data.today}. Resolve relative dates (e.g. 'next Friday', 'akhir bulan'). Due dates must not be in the past.`,
      "Keep the client's own wording for names. 'notes' lists short English remarks about anything ambiguous, unmatched names, or missing required info (max 4).",
      `PEOPLE: ${JSON.stringify(data.people)}`,
      data.kind === "task" ? `PROJECTS: ${JSON.stringify(data.projects)}` : "",
    ].join("\n");
    try {
      const result = streamText({
        model: provider.responses("openai/gpt-6-astra"),
        instructions,
        messages: [{ role: "user", content: data.text }],
        output: Output.object({ schema: schemas[data.kind] as z.ZodType<Record<string, unknown>> }),
        maxRetries: 0,
        providerOptions: { openai: { store: false, forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", include: ["reasoning.encrypted_content"] } },
      });
      const out = await result.output;
      const values: Record<string, string | number | string[] | null> = {};
      for (const [k, v] of Object.entries(out as Record<string, unknown>)) values[k] = (v ?? null) as string | number | string[] | null;
      return { ok: true as const, values, error: "" };
    } catch (e) {
      const status = (e as { statusCode?: number }).statusCode;
      console.error("aiFill failed", status, e);
      if (status === 429) return { ok: false as const, values: {} as Record<string, string | number | string[] | null>, error: "AI is busy right now. Try again in a moment." };
      if (status === 402) return { ok: false as const, values: {} as Record<string, string | number | string[] | null>, error: "AI credits are used up. Add credits in workspace settings." };
      if (status === 403) return { ok: false as const, values: {} as Record<string, string | number | string[] | null>, error: "AI access is blocked for this workspace." };
      return { ok: false as const, values: {} as Record<string, string | number | string[] | null>, error: "Could not read that text. Try again." };
    }
  });
