import { useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { useEffect, useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { todayWIB, addDays, type Checklist } from "./rules";

export type Project = Omit<Tables<"projects">, "checklist" | "handover_pp" | "hold_checklist"> & {
  checklist: Checklist; handover_pp: boolean[]; hold_checklist: boolean[];
};
export type Activity = Tables<"activity">;
export type Profile = Tables<"profiles"> & { role: string };
export type Todo = Tables<"todos">;
export type Task = Tables<"tasks">;
export type TaskComment = Tables<"task_comments">;

export const qk = {
  projects: ["projects"], activity: ["activity"], profiles: ["profiles"], todos: ["todos"], tasks: ["tasks"], people: ["people"], logos: ["client_logos"],
  comments: (id: string) => ["task_comments", id],
};

export function useProjects() {
  return useQuery({
    queryKey: qk.projects,
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").order("id");
      if (error) throw error;
      return data as unknown as Project[];
    },
  });
}

export function useActivity() {
  return useQuery({
    queryKey: qk.activity,
    queryFn: async () => {
      const { data, error } = await supabase.from("activity").select("*").order("at", { ascending: false }).limit(1000);
      if (error) throw error;
      return data;
    },
  });
}

export function useProfiles() {
  return useQuery({
    queryKey: qk.profiles,
    queryFn: async () => {
      const [{ data: p, error }, { data: r }] = await Promise.all([
        supabase.from("profiles").select("*").order("name"),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      if (error) throw error;
      const rank = ["admin", "lead", "pic", "engineer"];
      return (p ?? []).map((x) => {
        const roles = (r ?? []).filter((y) => y.user_id === x.id).map((y) => y.role as string);
        return { ...x, role: rank.find((k) => roles.includes(k)) ?? "engineer" } as Profile;
      });
    },
  });
}

export function useTodos() {
  return useQuery({
    queryKey: qk.todos,
    queryFn: async () => {
      const from = addDays(todayWIB(), -35);
      const { data, error } = await supabase.from("todos").select("*").gte("date", from).order("sort_order").order("created_at");
      if (error) throw error;
      return data;
    },
  });
}

export function useTasks() {
  return useQuery({
    queryKey: qk.tasks,
    queryFn: async () => {
      const { data, error } = await supabase.from("tasks").select("*").order("sort_order");
      if (error) throw error;
      return data;
    },
  });
}

export function useTaskComments(taskId: string | undefined) {
  return useQuery({
    queryKey: qk.comments(taskId ?? ""),
    enabled: !!taskId,
    queryFn: async () => {
      const { data, error } = await supabase.from("task_comments").select("*").eq("task_id", taskId!).order("at");
      if (error) throw error;
      return data;
    },
  });
}

// ---------- session / me ----------
export function useUserId() {
  const { data } = useQuery({
    queryKey: ["session-uid"],
    queryFn: async () => (await supabase.auth.getSession()).data.session?.user.id ?? null,
    staleTime: Infinity,
  });
  return data ?? null;
}

export function useMe() {
  const uid = useUserId();
  const { data: profiles } = useProfiles();
  const me = profiles?.find((p) => p.id === uid) ?? null;
  const role = me?.role ?? "engineer";
  return {
    uid, me, role,
    canEditProjects: ["pic", "lead", "admin"].includes(role),
    isLead: ["lead", "admin"].includes(role),
    isAdmin: role === "admin",
  };
}

// ---------- realtime ----------
let syncStatus = "connecting";
const listeners = new Set<() => void>();
function setSync(s: string) { syncStatus = s; listeners.forEach((l) => l()); }
export function useSyncStatus() {
  return useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, () => syncStatus, () => "connecting");
}

export function useRealtime() {
  const qc = useQueryClient();
  sharedQC = qc;
  useEffect(() => {
    const map: Record<string, readonly unknown[]> = {
      projects: qk.projects, activity: qk.activity, todos: qk.todos, tasks: qk.tasks, profiles: qk.profiles, task_comments: ["task_comments"], people: qk.people, client_logos: qk.logos, assistant_insights: ["insights"],
    };
    let ch = supabase.channel(`app-${Math.random().toString(36).slice(2)}`);
    for (const t of Object.keys(map)) {
      ch = ch.on("postgres_changes", { event: "*", schema: "public", table: t }, (payload) => {
        const id = (payload.new as { id?: string } | null)?.id ?? (payload.old as { id?: string } | null)?.id;
        if (id && recentLocal.has(id) && Date.now() - (recentLocal.get(id) ?? 0) < 4000) return;
        qc.invalidateQueries({ queryKey: map[t] ?? [] });
      });
    }
    ch.subscribe((s) => setSync(s === "SUBSCRIBED" ? "live" : s === "CLOSED" || s === "CHANNEL_ERROR" ? "offline" : "connecting"));
    return () => { supabase.removeChannel(ch); };
  }, [qc]);
}

// ---------- optimistic writes ----------
let sharedQC: QueryClient | null = null;
const recentLocal = new Map<string, number>();
type Row = { id: string };
/** Patch rows in the cache immediately, run the save, roll back on error, then quietly resync. */
export async function optimistic<T extends Row>(key: readonly unknown[], change: (rows: T[]) => T[], save: () => PromiseLike<{ error: { message: string } | null }>, ids: string[] = []) {
  const qc = sharedQC;
  const prev = qc?.getQueryData<T[]>(key);
  if (qc && prev) qc.setQueryData<T[]>(key, change(prev));
  ids.forEach((i) => recentLocal.set(i, Date.now()));
  const { error } = await save();
  if (error) { if (qc && prev) qc.setQueryData(key, prev); throw new Error(error.message); }
  qc?.invalidateQueries({ queryKey: key });
}
export const patchRows = <T extends Row>(ids: string[], patch: Partial<T> | ((r: T) => Partial<T>)) => (rows: T[]) =>
  rows.map((r) => (ids.includes(r.id) ? { ...r, ...(typeof patch === "function" ? patch(r) : patch) } : r));

export async function updateProject(id: string, patch: Record<string, unknown>) {
  await optimistic<Project>(qk.projects, patchRows([id], patch as Partial<Project>), () => supabase.from("projects").update(patch as never).eq("id", id), [id]);
}

// ---------- people directory ----------
export type Person = Tables<"people">;
export type PersonTitle = Person["title"];
export const TITLE_LABEL: Record<PersonTitle, string> = { engineer: "Engineer", pm: "PM", am: "AM", pic: "PIC", lead: "Lead" };

export function usePeople() {
  return useQuery({
    queryKey: qk.people,
    queryFn: async () => {
      const { data, error } = await supabase.from("people").select("*").order("name");
      if (error) throw error;
      return data;
    },
  });
}

/** Active PIC names (PIC + Lead), for filters and per-PIC tables. */
export function usePicNames() {
  const { data = [] } = usePeople();
  return data.filter((p) => p.active && (p.title === "pic" || p.title === "lead")).map((p) => p.name);
}

/** The engineer on a task: the directory person, falling back to the linked login account. */
export function taskPerson(t: Pick<Task, "assignee" | "assignee_person">, people: Person[]) {
  return people.find((p) => p.id === t.assignee_person) ?? (t.assignee ? people.find((p) => p.user_id === t.assignee) : undefined) ?? null;
}

// ---------- client logos (keyed by client name, stored as small data URLs) ----------
export function useClientLogos() {
  return useQuery({
    queryKey: qk.logos,
    queryFn: async () => {
      const { data, error } = await supabase.from("client_logos").select("client,url");
      if (error) throw error;
      return Object.fromEntries((data ?? []).map((r) => [r.client.trim().toLowerCase(), r.url])) as Record<string, string>;
    },
    staleTime: 60_000,
  });
}

export async function fileToLogoDataUrl(file: File, size = 160): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const c = document.createElement("canvas"); c.width = size; c.height = size;
    const ctx = c.getContext("2d")!;
    const s = Math.min(size / img.width, size / img.height);
    const w = img.width * s, h = img.height * s;
    ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
    return c.toDataURL("image/png");
  } finally { URL.revokeObjectURL(url); }
}

export async function saveClientLogo(client: string, dataUrl: string | null) {
  const key = client.trim();
  const { error } = dataUrl
    ? await supabase.from("client_logos").upsert({ client: key, url: dataUrl, updated_at: new Date().toISOString() })
    : await supabase.from("client_logos").delete().eq("client", key);
  if (error) throw error;
}
