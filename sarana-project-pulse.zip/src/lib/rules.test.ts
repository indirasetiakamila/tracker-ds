import { describe, it, expect } from "vitest";
import { progress, itemsBehind, daysOverdue, staleness, needsStandup, masihSamaBlock, validateUpdate, mondayOf, emptyChecklist, hoursUntilDeadline, canAdvance, type ProjectLike } from "./rules";

const base = (o: Partial<ProjectLike> = {}): ProjectLike => ({
  id: "DS-001", stage: "POC", checklist: emptyChecklist(), target_date: "2026-12-01", health: "Green",
  ball_in_court: "Client", blocker: "", next_action: "Kirim data", next_action_due: "2026-11-05", last_updated: "2026-10-27", ...o,
});
const today = "2026-10-30"; // Friday

describe("rules", () => {
  it("progress interpolates within stage", () => {
    const c = emptyChecklist(); c["POC"] = [true, true, true, true, false, false, false, false];
    expect(progress(base({ checklist: c }))).toBe(28); // 20 + 15*0.5 = 27.5
    expect(progress(base({ stage: "On Hold" }))).toBeNull();
    const h = emptyChecklist(); h["Hypercare"] = h["Hypercare"]!.map(() => true);
    expect(progress(base({ stage: "Hypercare", checklist: h }))).toBe(100);
  });
  it("items behind counts earlier stages", () => {
    expect(itemsBehind(base({ stage: "Go/No-Go" }))).toBe(15);
  });
  it("week starts Monday", () => { expect(mondayOf(today)).toBe("2026-10-26"); });
  it("overdue only for pipeline..go-live", () => {
    expect(daysOverdue(base({ target_date: "2026-10-20" }), today)).toBe(10);
    expect(daysOverdue(base({ stage: "Hypercare", target_date: "2026-10-20" }), today)).toBe(0);
  });
  it("stale after 7 days", () => {
    expect(staleness(base({ last_updated: "2026-10-23" }), today)).toBeNull();
    expect(staleness(base({ last_updated: "2026-10-22" }), today)?.label).toBe("STALE");
    expect(staleness(base({ last_updated: null }), today)?.label).toBe("NO DATE");
  });
  it("needs standup when Red or ball due passed", () => {
    expect(needsStandup(base(), today)).toBe(false);
    expect(needsStandup(base({ health: "Red" }), today)).toBe(true);
    expect(needsStandup(base({ ball_in_court: "Sarana", next_action_due: "2026-10-29" }), today)).toBe(true);
  });
  it("masih sama blocked cases", () => {
    expect(masihSamaBlock(base(), today)).toBeNull();
    expect(masihSamaBlock(base({ next_action: "" }), today)).not.toBeNull();
    expect(masihSamaBlock(base({ health: "Red" }), today)).not.toBeNull();
    expect(masihSamaBlock(base({ stage: "Hypercare", target_date: null }), today)).not.toBeNull();
  });
  it("validate update", () => {
    const f = { client: "A", next_action: "x", next_action_due: "2026-10-29", ball_in_court: "Sarana" as const, health: "Red" as const, blocker: "", target_date: null };
    const e = validateUpdate(f, "POC", today, null);
    expect(e).toContain("Next action due date must be today or later");
    expect(e).toContain("Red health requires a blocker");
  });
  it("advance needs all items", () => {
    expect(canAdvance(base())).toBe(false);
    const c = emptyChecklist(); c["POC"] = c["POC"]!.map(() => true);
    expect(canAdvance(base({ checklist: c }))).toBe(true);
  });
  it("deadline is Friday 17:00 WIB", () => {
    expect(hoursUntilDeadline(new Date("2026-10-30T08:00:00Z"))).toBe(2);
  });
});
