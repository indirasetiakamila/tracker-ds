/** Per-assistant MCP keys. Only the SHA-256 hex hash is ever stored. */
export const KEY_PREFIX = "srn_";
const KEY_RE = /^srn_[A-Za-z0-9_-]{43}$/;

export function isKeyFormat(key: unknown): key is string {
  return typeof key === "string" && KEY_RE.test(key);
}

export function generateKey(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return KEY_PREFIX + btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export async function hashKey(key: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(key));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** A key works only when it exists and has not been revoked. */
export function keyIsUsable(row: { revoked_at: string | null } | null | undefined): boolean {
  return !!row && row.revoked_at === null;
}
