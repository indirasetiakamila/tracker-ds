// Single source of truth for stages, checklists and derived rules (pure functions).

export type Stage =
  | "Pipeline" | "POC" | "Go/No-Go" | "Development" | "UAT" | "Go-Live" | "Hypercare" | "On Hold" | "Closed-No Go";
export type Health = "Green" | "Yellow" | "Red";
export type Ball = "Sarana" | "Client";

export const FLOW: Stage[] = ["Pipeline", "POC", "Go/No-Go", "Development", "UAT", "Go-Live", "Hypercare"];
export const ALL_STAGES: Stage[] = [...FLOW, "On Hold", "Closed-No Go"];
export const BOARD_STAGES: Stage[] = [...FLOW, "On Hold"];
export const PICS = ["Faiz", "Dhania", "Keysa", "Tira", "Indira"];

export const BASE: Record<Stage, number | null> = {
  Pipeline: 0, POC: 20, "Go/No-Go": 35, Development: 50, UAT: 75, "Go-Live": 90, Hypercare: 95,
  "On Hold": null, "Closed-No Go": null,
};

export const TARGET_LABEL: Record<Stage, string> = {
  Pipeline: "Planned POC kickoff",
  POC: "Target Go/No-Go",
  "Go/No-Go": "Decision target",
  Development: "Target go-live",
  UAT: "Target go-live",
  "Go-Live": "Go-live confirmation target",
  Hypercare: "Hypercare end date",
  "On Hold": "Review date",
  "Closed-No Go": "Target",
};

export interface CheckItem { t: string; gate?: boolean; owner: string }

export const CHECKLIST: Record<string, CheckItem[]> = {
  Pipeline: [
    { t: "Lead qualified by AM (use case, sponsor, rough value)", owner: "AM" },
    { t: "PIC (DS) assigned", owner: "Lead" },
    { t: "Use-case brief written", owner: "PIC" },
    { t: "Potential ARR estimate filled in", owner: "AM" },
    { t: "POC proposal / deck with timeline sent", owner: "PIC" },
    { t: "POC scope + success criteria agreed with client", gate: true, owner: "PIC" },
    { t: "Kickoff date set", gate: true, owner: "PIC" },
  ],
  POC: [
    { t: "Kickoff held, notes stored", owner: "PIC" },
    { t: "Data request sent to client", owner: "PIC" },
    { t: "Client data / access received", owner: "Client" },
    { t: "Success criteria written and signed off", owner: "PIC" },
    { t: "Funding requested (cash / credit)", owner: "AM" },
    { t: "Weekly POC status shared", owner: "PIC" },
    { t: "POC delivered against success criteria", gate: true, owner: "Engineer" },
    { t: "Go/No-Go meeting scheduled", gate: true, owner: "PIC" },
  ],
  "Go/No-Go": [
    { t: "POC demo / checkpoint completed", owner: "PIC" },
    { t: "Go/No-Go meeting notes stored", owner: "PIC" },
    { t: "Commercial proposal sent", owner: "AM" },
    { t: "SIGNED PoC sign-off / handoff doc received, verbal Go does not count", gate: true, owner: "Client" },
  ],
  Development: [
    { t: "Signed PoC sign-off linked", gate: true, owner: "PIC" },
    { t: "Production scope / PRD agreed", owner: "PIC" },
    { t: "Quotation / PKS sent with owner and expected signing date", owner: "AM" },
    { t: "Infra decision, environments, access requested", owner: "Engineer" },
    { t: "Data / integrations list with client owners", owner: "PIC" },
    { t: "Dev plan with milestones, UAT date, target go-live", owner: "PIC" },
    { t: "Client stakeholder map + channel", owner: "PIC" },
    { t: "POC code / prompts / configs in shared repo", owner: "Engineer" },
    { t: "Feature-complete build deployed to UAT environment", gate: true, owner: "Engineer" },
    { t: "UAT plan agreed with client", gate: true, owner: "PIC" },
  ],
  UAT: [
    { t: "UAT scenarios shared", owner: "PIC" },
    { t: "UAT feedback log running", owner: "PIC" },
    { t: "Client UAT sign-off", gate: true, owner: "Client" },
    { t: "Go-live date confirmed in writing by client", gate: true, owner: "Client" },
    { t: "Prod deployment plan ready", owner: "Engineer" },
  ],
  "Go-Live": [
    { t: "Production deployment done", owner: "Engineer" },
    { t: "Written go-live confirmation linked", gate: true, owner: "PIC" },
    { t: "Hypercare end date agreed and entered", gate: true, owner: "PIC" },
    { t: "Support channel, SLA, escalation contacts agreed", owner: "PIC" },
    { t: "Known issues / issue log set up", owner: "Engineer" },
    { t: "User training / guide delivered", owner: "PIC" },
    { t: "Prod release notes shared", owner: "Engineer" },
    { t: "Monitoring + billing start confirmed", owner: "AM" },
  ],
  Hypercare: [
    { t: "Issue log maintained", owner: "Engineer" },
    { t: "End date reached, no open P1/P2", gate: true, owner: "PIC" },
    { t: "Closure note sent to client", owner: "PIC" },
    { t: "Handover to CS / BAU with runbook", gate: true, owner: "PIC" },
    { t: "Enhancements logged as CR / upsell", owner: "AM" },
    { t: "Billing active and renewal date recorded", gate: true, owner: "AM" },
    { t: "Removed from DS active load", owner: "Lead" },
  ],
};

export const HANDOVER: CheckItem[] = [
  { t: "Register updated with new PIC", owner: "New PIC" },
  { t: "Handover call held, Indira informed", owner: "Previous PIC" },
  { t: "New PIC introduced to client", owner: "Previous PIC" },
  { t: "All docs shared", owner: "Previous PIC" },
  { t: "Access transferred via vault", owner: "Previous PIC" },
  { t: "Open commitments listed", owner: "Previous PIC" },
  { t: "New PIC confirms handover complete", owner: "New PIC" },
];

export const HOLD: CheckItem[] = [
  { t: "Hold reason in Blocker", owner: "PIC" },
  { t: "Who decided is recorded", owner: "PIC" },
  { t: "Review date set", owner: "PIC" },
];

export type Checklist = Record<string, boolean[]>;

export interface ProjectLike {
  id: string;
  stage: Stage;
  prev_stage?: Stage | null;
  checklist: Checklist | unknown;
  target_date: string | null;
  health: Health | null;
  ball_in_court: Ball | null;
  blocker: string | null;
  next_action: string | null;
  next_action_due: string | null;
  last_updated: string | null;
}

export function emptyChecklist(): Checklist {
  const c: Checklist = {};
  for (const s of FLOW) c[s] = (CHECKLIST[s] ?? []).map(() => false);
  return c;
}

export function getChecks(p: ProjectLike, stage: string): boolean[] {
  const c = (p.checklist ?? {}) as Checklist;
  const items = CHECKLIST[stage] ?? [];
  const arr = c[stage] ?? [];
  return items.map((_, i) => !!arr[i]);
}

// ---------- Dates (all WIB) ----------
export function todayWIB(now: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}
function toUTC(d: string) { const [y = 1970, m = 1, dd = 1] = d.split("-").map(Number); return Date.UTC(y, m - 1, dd); }
export function diffDays(a: string, b: string): number { return Math.round((toUTC(a) - toUTC(b)) / 86400000); }
export function addDays(d: string, n: number): string { return new Date(toUTC(d) + n * 86400000).toISOString().slice(0, 10); }
export function mondayOf(d: string): string {
  const dow = new Date(toUTC(d)).getUTCDay(); // 0 Sun
  return addDays(d, -((dow + 6) % 7));
}
/** Hours left until Friday 17:00 WIB of the current week (negative if passed). */
export function hoursUntilDeadline(now: Date = new Date()): number {
  const today = todayWIB(now);
  const fri = addDays(mondayOf(today), 4);
  const deadlineUtcMs = toUTC(fri) + (17 - 7) * 3600000; // 17:00 WIB = 10:00 UTC
  return Math.floor((deadlineUtcMs - now.getTime()) / 3600000);
}

// ---------- Derived ----------
export function isActive(p: { stage: Stage }) { return p.stage !== "Closed-No Go"; }

export function progress(p: ProjectLike): number | null {
  const base = BASE[p.stage];
  if (base === null) return null;
  const idx = FLOW.indexOf(p.stage);
  const checks = getChecks(p, p.stage);
  const ratio = checks.length ? checks.filter(Boolean).length / checks.length : 0;
  const next = p.stage === "Hypercare" ? 100 : (BASE[FLOW[idx + 1] ?? "Hypercare"] as number);
  return Math.round(base + (next - base) * ratio);
}

export function itemsBehind(p: ProjectLike): number {
  const s = p.stage === "On Hold" && p.prev_stage ? p.prev_stage : p.stage;
  const idx = FLOW.indexOf(s);
  if (idx <= 0) return 0;
  let n = 0;
  for (let i = 0; i < idx; i++) n += getChecks(p, FLOW[i] ?? "").filter((x) => !x).length;
  return n;
}

export function stageBehind(p: ProjectLike, stage: string): number {
  return getChecks(p, stage).filter((x) => !x).length;
}

export function checkedThisWeek(p: ProjectLike, today: string): boolean {
  return !!p.last_updated && p.last_updated >= mondayOf(today);
}

const OVERDUE_STAGES: Stage[] = ["Pipeline", "POC", "Go/No-Go", "Development", "UAT", "Go-Live"];
export function daysOverdue(p: ProjectLike, today: string): number {
  if (!OVERDUE_STAGES.includes(p.stage) || !p.target_date) return 0;
  const d = diffDays(today, p.target_date);
  return d > 0 ? d : 0;
}

export function staleness(p: ProjectLike, today: string): { label: "NO DATE" | "STALE"; days: number | null } | null {
  if (!isActive(p)) return null;
  if (!p.last_updated) return { label: "NO DATE", days: null };
  const d = diffDays(today, p.last_updated);
  return d > 7 ? { label: "STALE", days: d } : null;
}

export interface Reason { key: string; label: string; sev: number }

export function reasons(p: ProjectLike, today: string): Reason[] {
  if (!isActive(p)) return [];
  const r: Reason[] = [];
  if (p.health === "Red") r.push({ key: "red", label: "Red", sev: 100 });
  const od = daysOverdue(p, today);
  if (od > 0) r.push({ key: "overdue", label: `${od} days overdue`, sev: 50 + Math.min(od, 40) });
  const st = staleness(p, today);
  if (st) r.push({ key: "stale", label: st.days === null ? "Never updated" : `No update for ${st.days} days`, sev: 30 });
  if (p.stage === "Hypercare" && !p.target_date) r.push({ key: "hyper", label: "Hypercare end date missing", sev: 40 });
  if (p.ball_in_court === "Sarana" && p.next_action_due && p.next_action_due < today)
    r.push({ key: "ball", label: "Sarana action overdue", sev: 35 });
  return r;
}

export function needsStandup(p: ProjectLike, today: string) { return reasons(p, today).length > 0; }
export function severity(p: ProjectLike, today: string) { return reasons(p, today).reduce((a, b) => a + b.sev, 0); }

/** Reason why one-click "Masih sama" is disabled, or null if allowed. */
export function masihSamaBlock(p: ProjectLike, today: string): string | null {
  if (p.target_date && p.target_date < today && OVERDUE_STAGES.includes(p.stage)) return "Target date has passed. Set a new date first.";
  if (p.stage === "Hypercare" && !p.target_date) return "Set a Hypercare end date.";
  if (p.stage === "On Hold" && (!p.target_date || p.target_date <= today)) return "On Hold requires a future review date.";
  if (!p.next_action?.trim()) return "Enter a next action.";
  if (!p.next_action_due || p.next_action_due < today) return "Set a next action due date of today or later.";
  if (p.health === "Red" && !p.blocker?.trim()) return "Red health requires a blocker.";
  return null;
}

export interface StatusForm {
  client: string;
  next_action: string;
  next_action_due: string | null;
  ball_in_court: Ball | null;
  health: Health | null;
  blocker: string;
  target_date: string | null;
}

export function validateUpdate(f: StatusForm, stage: Stage, today: string, prevTarget: string | null): string[] {
  const e: string[] = [];
  if (!f.client.trim()) e.push("Client is required");
  if (!f.next_action.trim()) e.push("Next action is required");
  if (!f.next_action_due) e.push("Next action due date is required");
  else if (f.next_action_due < today) e.push("Next action due date must be today or later");
  if (!f.ball_in_court) e.push("Select who owns the next action");
  if (f.health === "Red" && !f.blocker.trim()) e.push("Red health requires a blocker");
  if ((stage === "Hypercare" || stage === "On Hold") && !f.target_date) e.push(`${TARGET_LABEL[stage]} is required`);
  if (f.target_date && f.target_date < today && f.target_date === prevTarget && stage !== "Closed-No Go")
    e.push("Target date has passed. Choose a new date.");
  return e;
}

export function canAdvance(p: ProjectLike): boolean {
  const idx = FLOW.indexOf(p.stage);
  if (idx < 0 || idx === FLOW.length - 1) return false;
  return getChecks(p, p.stage).every(Boolean);
}
export function nextStage(s: Stage): Stage | null {
  const i = FLOW.indexOf(s);
  return i >= 0 && i < FLOW.length - 1 ? (FLOW[i + 1] ?? null) : null;
}
export const CAN_CLOSE_NO_GO: Stage[] = ["Pipeline", "POC", "Go/No-Go"];

export function fmtDate(d: string | null | undefined): string {
  if (!d) return "";
  const [y = 0, m = 1, dd = 1] = d.split("-").map(Number);
  const mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][m - 1];
  return `${dd} ${mon} ${String(y).slice(2)}`;
}
export function relTime(iso: string, now: Date = new Date()): string {
  const s = Math.floor((now.getTime() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} hr ago`;
  return `${Math.floor(s / 86400)} days ago`;
}

// ---------- dashboard aggregates ----------
export type StageSummary = { stage: Stage; count: number; red: number; arr: number };
export function stageSummary(ps: (ProjectLike & { health?: Health | null; potential_arr_idr_million?: number | null })[]): StageSummary[] {
  return BOARD_STAGES.map((stage) => {
    const col = ps.filter((p) => p.stage === stage);
    return { stage, count: col.length, red: col.filter((p) => p.health === "Red").length, arr: col.reduce((s, p) => s + Number(p.potential_arr_idr_million ?? 0), 0) };
  });
}
export function healthMix(ps: { health?: Health | null }[]): Record<Health | "Not set", number> {
  const m: Record<Health | "Not set", number> = { Green: 0, Yellow: 0, Red: 0, "Not set": 0 };
  for (const p of ps) m[p.health ?? "Not set"]++;
  return m;
}
/** Days since next action due date passed or since last update, whichever flags attention. */
export function needsAttention(p: ProjectLike & { health?: Health | null; last_updated?: string | null }, today: string): string | null {
  if (p.health === "Red") return "Red";
  if (daysOverdue(p, today) > 0) return `${daysOverdue(p, today)} days overdue`;
  if (!p.last_updated || diffDays(today, p.last_updated) > 14) return "No update in 14+ days";
  return null;
}

// ---------- Assistant inbox ----------
/** Week bucket (Mon to Sun, WIB) of a date relative to today: 0 this week, 1 last week, ... null if 4+ weeks ago or future. */
export function weekBucket(date: string, today: string): number | null {
  const n = Math.round(diffDays(mondayOf(today), mondayOf(date)) / 7);
  return n >= 0 && n < 4 ? n : null;
}
