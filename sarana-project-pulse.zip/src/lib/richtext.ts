// Rich text fields (next action, task description) are stored as HTML from the editor.
// Older rows hold plain text; these helpers handle both.
export function isRich(v: string | null | undefined): boolean {
  return !!v && /<(p|h[1-6]|ul|ol|li|strong|em|mark|blockquote|code|br|a|s|u)\b/i.test(v);
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function plainToHtml(v: string | null | undefined): string {
  if (!v) return "";
  return v.split("\n").map((l) => `<p>${esc(l)}</p>`).join("");
}

/** One-line plain text for cards, tables, CSV export. */
export function plainText(v: string | null | undefined): string {
  if (!v) return "";
  if (!isRich(v)) return v;
  return v
    .replace(/<\/(p|h[1-6]|li|blockquote)>/gi, " ")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim();
}
