import { useState } from "react";
import { Check, ChevronsUpDown, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { qk, useMe, usePeople, TITLE_LABEL, type PersonTitle } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "@/components/ui/command";
import { Initials } from "@/components/app/bits";
import { cn } from "@/lib/utils";

/** Searchable dropdown over the people directory. `by` picks what is stored: the person's name (text columns) or id. Admins can add a person inline. */
export function PersonSelect({ value, onChange, titles, by = "name", placeholder = "Select a person", allowEmpty = true, emptyLabel = "None", disabled, className }: {
  value: string | null | undefined; onChange: (v: string | null) => void; titles?: PersonTitle[]; by?: "name" | "id";
  placeholder?: string; allowEmpty?: boolean; emptyLabel?: string; disabled?: boolean; className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const { isAdmin } = useMe();
  const { data: people = [] } = usePeople();
  const list = people.filter((p) => p.active && (!titles || titles.includes(p.title)));
  const current = people.find((p) => (by === "id" ? p.id : p.name) === value);
  const label = current?.name ?? (by === "name" && value ? value : null);
  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button type="button" variant="outline" disabled={disabled} className={cn("w-full justify-between bg-card font-normal", className)}>
            <span className="flex min-w-0 items-center gap-2">
              {label && <Initials name={label} className="h-5 w-5 text-[9px]" />}
              <span className={cn("truncate", !label && "text-muted-foreground")}>{label ?? placeholder}</span>
            </span>
            <ChevronsUpDown className="h-3.5 w-3.5 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 p-0" align="start">
          <Command>
            <CommandInput placeholder="Search names..." />
            <CommandList>
              <CommandEmpty>No matches found.</CommandEmpty>
              <CommandGroup>
                {allowEmpty && <CommandItem value="__empty" onSelect={() => { onChange(null); setOpen(false); }}><span className="text-muted-foreground">{emptyLabel}</span></CommandItem>}
                {list.map((p) => {
                  const v = by === "id" ? p.id : p.name;
                  return (
                    <CommandItem key={p.id} value={`${p.name} ${p.email ?? ""}`} onSelect={() => { onChange(v); setOpen(false); }}>
                      <Initials name={p.name} className="h-6 w-6" />
                      <span className="flex-1 truncate">{p.name}</span>
                      <span className="rounded-full bg-secondary px-1.5 text-[10px] font-semibold text-secondary-foreground">{TITLE_LABEL[p.title]}</span>
                      <Check className={cn("h-3.5 w-3.5", v === value ? "opacity-100" : "opacity-0")} />
                    </CommandItem>
                  );
                })}
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup>
                {isAdmin ? (
                  <CommandItem value="__add" onSelect={() => { setOpen(false); setAdding(true); }} className="font-semibold text-primary">
                    <UserPlus className="h-4 w-4" />Add a person
                  </CommandItem>
                ) : (
                  <div className="px-2 py-1.5 text-xs text-muted-foreground">Someone missing? Ask an admin to add them under Admin, Team tab.</div>
                )}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {adding && <AddPersonDialog defaultTitle={titles?.[0] ?? "engineer"} onClose={() => setAdding(false)} onCreated={(p) => onChange(by === "id" ? p.id : p.name)} />}
    </>
  );
}

function AddPersonDialog({ defaultTitle, onClose, onCreated }: { defaultTitle: PersonTitle; onClose: () => void; onCreated: (p: { id: string; name: string }) => void }) {
  const qc = useQueryClient();
  const [f, setF] = useState({ name: "", email: "", title: defaultTitle });
  const [busy, setBusy] = useState(false);
  async function save() {
    const name = f.name.trim(); const email = f.email.trim().toLowerCase();
    if (!name) { toast.error("Name is required"); return; }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast.error("Enter a valid email"); return; }
    setBusy(true);
    const { data, error } = await supabase.from("people").insert({ name, email: email || null, title: f.title }).select("id,name").single();
    setBusy(false);
    if (error) { toast.error(error.message.includes("duplicate") ? "Email is already registered" : error.message); return; }
    toast.success(`${name} ditambahkan`);
    await qc.invalidateQueries({ queryKey: qk.people });
    onCreated(data); onClose();
  }
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle className="flex items-center gap-2"><UserPlus className="h-5 w-5 text-primary" />Add a person</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Name *</Label><Input autoFocus value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div><Label>Email (optional)</Label><Input placeholder="name@company.com" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
          <div><Label>Jabatan</Label>
            <Select value={f.title} onValueChange={(v) => setF({ ...f, title: v as PersonTitle })}><SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{(Object.keys(TITLE_LABEL) as PersonTitle[]).map((t) => <SelectItem key={t} value={t}>{TITLE_LABEL[t]}</SelectItem>)}</SelectContent></Select>
          </div>
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={save} disabled={busy}>Save</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
