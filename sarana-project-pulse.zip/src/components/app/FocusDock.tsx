import { useEffect, useRef, useState } from "react";
import { Headphones, Pause, Play, RotateCcw, SkipForward, Settings2, Volume2, VolumeX, Eye, EyeOff, X, Music } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DEFAULT_SETTINGS, embedUrl, mmss, nextPhase, parseYouTubeUrl, type FocusSettings, type Phase } from "@/lib/focus";

const PRESETS = [
  { label: "Lofi Girl", url: "https://www.youtube.com/watch?v=X4VbdwhkE10" },
  { label: "Jazz", url: "https://www.youtube.com/watch?v=Dx5qFachd3A" },
  { label: "Rain", url: "https://www.youtube.com/watch?v=mPZkdNFkNps" },
  { label: "Classical", url: "https://www.youtube.com/watch?v=jgpJVI3tDT0" },
];
const LABEL: Record<Phase, string> = { focus: "Focus", short: "Short break", long: "Long break" };
const KEY = "sarana-focus";

type Timer = { phase: Phase; completed: number; endsAt: number | null; remaining: number };

function chime() {
  try {
    const ctx = new AudioContext();
    [660, 880].forEach((f, i) => {
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.frequency.value = f; o.connect(g); g.connect(ctx.destination);
      const t = ctx.currentTime + i * 0.25;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.2, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
      o.start(t); o.stop(t + 0.65);
    });
  } catch { /* audio unavailable */ }
}

export function FocusDock() {
  const [open, setOpen] = useState(false);
  const [settings, setSettings] = useState<FocusSettings>(DEFAULT_SETTINGS);
  const [timer, setTimer] = useState<Timer>({ phase: "focus", completed: 0, endsAt: null, remaining: DEFAULT_SETTINGS.focus * 60000 });
  const [now, setNow] = useState(0);
  const [link, setLink] = useState("");
  const [src, setSrc] = useState<{ video?: string; list?: string } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [showVideo, setShowVideo] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const frame = useRef<HTMLIFrameElement>(null);
  const loaded = useRef(false);

  // Restore after hydration
  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem(KEY) ?? "{}");
      if (s.settings) setSettings({ ...DEFAULT_SETTINGS, ...s.settings });
      if (s.timer) setTimer(s.timer);
      if (s.link) { setLink(s.link); }
    } catch { /* ignore */ }
    loaded.current = true;
  }, []);
  useEffect(() => {
    if (loaded.current) localStorage.setItem(KEY, JSON.stringify({ settings, timer, link: src ? link : "" }));
  }, [settings, timer, link, src]);

  const running = timer.endsAt !== null;
  const left = running ? (timer.endsAt ?? 0) - now : timer.remaining;
  const total = (timer.phase === "focus" ? settings.focus : timer.phase === "short" ? settings.short : settings.long) * 60000;

  const cmd = (func: string, args: unknown[] = []) =>
    frame.current?.contentWindow?.postMessage(JSON.stringify({ event: "command", func, args }), "*");

  // Tick
  useEffect(() => {
    if (!running) return;
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, [running]);

  // Phase end
  useEffect(() => {
    if (!running || now === 0 || left > 0) return;
    const n = nextPhase(timer.phase, timer.completed, settings.rounds);
    const mins = n.phase === "focus" ? settings.focus : n.phase === "short" ? settings.short : settings.long;
    chime();
    const msg = n.phase === "focus" ? "Break over. Back to focus." : `Nice work. Time for a ${LABEL[n.phase].toLowerCase()}.`;
    toast(msg);
    if ("Notification" in window && Notification.permission === "granted") new Notification("Sarana Focus", { body: msg });
    if (src && settings.pauseOnBreak) { if (n.phase === "focus") { cmd("playVideo"); setPlaying(true); } else { cmd("pauseVideo"); setPlaying(false); } }
    setTimer({ phase: n.phase, completed: n.completedFocus, endsAt: Date.now() + mins * 60000, remaining: mins * 60000 });
  }, [now]); // eslint-disable-line react-hooks/exhaustive-deps

  // Tab title
  useEffect(() => {
    if (!running) return;
    const base = document.title.replace(/^\d\d:\d\d [^|]*\| /, "");
    document.title = `${mmss(left)} ${LABEL[timer.phase]} | ${base}`;
    return () => { document.title = base; };
  }, [running, Math.ceil(left / 1000), timer.phase]); // eslint-disable-line react-hooks/exhaustive-deps

  function start() {
    if ("Notification" in window && Notification.permission === "default") void Notification.requestPermission();
    setTimer((t) => ({ ...t, endsAt: Date.now() + t.remaining }));
  }
  const pause = () => setTimer((t) => ({ ...t, remaining: Math.max(0, (t.endsAt ?? 0) - Date.now()), endsAt: null }));
  const reset = () => setTimer({ phase: "focus", completed: 0, endsAt: null, remaining: settings.focus * 60000 });
  function skip() {
    const n = nextPhase(timer.phase, timer.completed, settings.rounds);
    const mins = n.phase === "focus" ? settings.focus : n.phase === "short" ? settings.short : settings.long;
    setTimer({ phase: n.phase, completed: n.completedFocus, endsAt: null, remaining: mins * 60000 });
  }

  function load(u: string) {
    const p = parseYouTubeUrl(u);
    if (!p) { toast.error("Paste a YouTube video or playlist link"); return; }
    setLink(u); setSrc(p); setPlaying(true); setMuted(false);
  }
  // Restore last link (paused until user presses play: browsers block autoplay anyway)
  useEffect(() => { if (link && !src && open) { const p = parseYouTubeUrl(link); if (p) setSrc(p); } }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const R = 52, C = 2 * Math.PI * R, frac = total ? Math.min(1, Math.max(0, left / total)) : 0;
  const inRound = (timer.completed % settings.rounds) + (timer.phase === "focus" ? 1 : 0);

  return (
    <>
      {/* Panel stays mounted when hidden so music keeps playing */}
      <div className={`fixed bottom-20 right-4 z-50 w-[22rem] max-w-[calc(100vw-2rem)] origin-bottom-right rounded-xl border bg-card shadow-2xl transition-all duration-200 ${open ? "scale-100 opacity-100" : "pointer-events-none scale-95 opacity-0"}`} aria-hidden={!open}>
        <div className="flex items-center justify-between border-b px-4 py-3">
          <p className="flex items-center gap-2 font-bold text-heading"><Headphones className="h-4 w-4 text-primary" /> Focus <span className="text-primary">corner</span></p>
          <div className="flex gap-1">
            <Button size="icon" variant="ghost" className="h-8 w-8" aria-label="Timer settings" onClick={() => setShowSettings((v) => !v)}><Settings2 className="h-4 w-4" /></Button>
            <Button size="icon" variant="ghost" className="h-8 w-8" aria-label="Hide" onClick={() => setOpen(false)}><X className="h-4 w-4" /></Button>
          </div>
        </div>

        {showSettings && (
          <div className="grid grid-cols-3 gap-2 border-b bg-muted/40 px-4 py-3 text-xs">
            {(["focus", "short", "long"] as const).map((k) => (
              <label key={k} className="space-y-1"><span className="font-semibold text-muted-foreground">{LABEL[k]} (min)</span>
                <Input type="number" min={1} max={120} value={settings[k]} className="h-8"
                  onChange={(e) => { const v = Math.min(120, Math.max(1, Number(e.target.value) || 1)); setSettings((s) => ({ ...s, [k]: v })); if (!running && timer.phase === k) setTimer((t) => ({ ...t, remaining: v * 60000 })); }} />
              </label>
            ))}
            <label className="col-span-3 flex items-center gap-2"><input type="checkbox" checked={settings.pauseOnBreak} onChange={(e) => setSettings((s) => ({ ...s, pauseOnBreak: e.target.checked }))} className="accent-[var(--color-primary)]" /> Pause music during breaks</label>
          </div>
        )}

        {/* Pomodoro */}
        <div className="flex items-center gap-4 px-4 py-4">
          <div className="relative h-32 w-32 shrink-0">
            <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
              <circle cx="60" cy="60" r={R} className="fill-none stroke-muted" strokeWidth="8" />
              <circle cx="60" cy="60" r={R} className={`fill-none transition-[stroke-dashoffset] duration-500 ${timer.phase === "focus" ? "stroke-primary" : "stroke-success"}`} strokeWidth="8" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - frac)} />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-mono text-2xl font-bold tabular-nums text-heading">{mmss(left)}</span>
              <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{LABEL[timer.phase]}</span>
            </div>
          </div>
          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-1.5" aria-label={`Round ${inRound} of ${settings.rounds}`}>
              {Array.from({ length: settings.rounds }).map((_, i) => (
                <span key={i} className={`h-2 w-2 rounded-full ${i < timer.completed % settings.rounds || (timer.phase === "long" && timer.completed > 0) ? "bg-primary" : "bg-muted"}`} />
              ))}
              <span className="ml-1 text-xs text-muted-foreground">Round {Math.max(1, inRound)} of {settings.rounds}</span>
            </div>
            <Button className="w-full" onClick={running ? pause : start}>{running ? <><Pause className="h-4 w-4" /> Pause</> : <><Play className="h-4 w-4" /> Start</>}</Button>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1" onClick={reset}><RotateCcw className="h-3.5 w-3.5" /> Reset</Button>
              <Button variant="outline" size="sm" className="flex-1" onClick={skip}><SkipForward className="h-3.5 w-3.5" /> Skip</Button>
            </div>
          </div>
        </div>

        {/* Music */}
        <div className="space-y-3 border-t px-4 py-4">
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); load(link); }}>
            <Input value={link} onChange={(e) => setLink(e.target.value)} placeholder="Paste a YouTube link" className="h-9 text-sm" />
            <Button type="submit" size="sm" className="h-9" disabled={!link.trim()}><Music className="h-4 w-4" /></Button>
          </form>
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button key={p.label} onClick={() => load(p.url)} className="rounded-full border bg-muted/50 px-3 py-1 text-xs font-semibold transition hover:border-primary hover:text-primary">{p.label}</button>
            ))}
          </div>
          {src && (
            <>
              <div className={showVideo ? "overflow-hidden rounded-lg border" : "h-0 overflow-hidden"}>
                <iframe ref={frame} key={`${src.video}-${src.list}`} src={embedUrl(src)} title="YouTube music player" className="aspect-video w-full"
                  allow="autoplay; encrypted-media; picture-in-picture" referrerPolicy="strict-origin-when-cross-origin" />
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => { cmd(playing ? "pauseVideo" : "playVideo"); setPlaying(!playing); }}>
                  {playing ? <><Pause className="h-3.5 w-3.5" /> Pause</> : <><Play className="h-3.5 w-3.5" /> Play</>}
                </Button>
                <Button size="sm" variant="outline" aria-label={muted ? "Unmute" : "Mute"} onClick={() => { cmd(muted ? "unMute" : "mute"); setMuted(!muted); }}>{muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}</Button>
                <Button size="sm" variant="outline" aria-label={showVideo ? "Hide video" : "Show video"} onClick={() => setShowVideo(!showVideo)}>{showVideo ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}</Button>
              </div>
            </>
          )}
        </div>
      </div>

      <button onClick={() => setOpen((o) => !o)} aria-label="Focus corner"
        className="fixed bottom-4 right-4 z-50 flex h-12 items-center gap-2 rounded-full bg-primary px-4 font-semibold text-primary-foreground shadow-lg transition hover:-translate-y-0.5 active:scale-95">
        <Headphones className="h-5 w-5" />
        {running ? <span className="font-mono tabular-nums">{mmss(left)}</span> : <span className="hidden sm:inline">Focus</span>}
        {playing && src && <span className="flex h-3 items-end gap-0.5">{[0, 1, 2].map((i) => <span key={i} className="w-0.5 animate-pulse rounded bg-primary-foreground" style={{ height: `${6 + i * 3}px`, animationDelay: `${i * 0.15}s` }} />)}</span>}
      </button>
    </>
  );
}
