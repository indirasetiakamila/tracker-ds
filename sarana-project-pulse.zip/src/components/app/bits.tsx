import { SaranaDots } from "./brand";
import { useLocation } from "@tanstack/react-router";
import { AlertTriangle, BarChart3, Bug, CalendarCheck, CheckCircle2, Columns3, Flag, Inbox, ListTodo, Shield, Sparkles, Table2, TrendingUp, Users, Wrench, XCircle, FolderPlus, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { CountUp, Illustration, avatarStyle, type ArtName } from "./fun";

const PATH_ICON: [string, LucideIcon][] = [["/minggu-ini", CalendarCheck], ["/board", Columns3], ["/register", Table2], ["/prioritas", ListTodo], ["/standup", Users], ["/tasks", Wrench], ["/report", BarChart3], ["/admin", Shield], ["/proyek", FolderPlus]];
import type { Health, Stage, Reason } from "@/lib/rules";
import { useClientLogos } from "@/lib/data";

export function HealthPill({ h, className }: { h: Health | null | undefined; className?: string }) {
  if (!h) return <span className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs text-muted-foreground", className)}>Not set</span>;
  const cls = h === "Green" ? "bg-success-soft text-success" : h === "Yellow" ? "bg-warning-soft text-warning-foreground" : "bg-danger-soft text-destructive";
  const dot = h === "Green" ? "bg-success" : h === "Yellow" ? "bg-warning" : "bg-destructive";
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-semibold whitespace-nowrap", cls, h === "Red" && "animate-pulse-soft", className)}>
      {h === "Green" ? <CheckCircle2 className="h-3.5 w-3.5" /> : h === "Yellow" ? <AlertTriangle className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}{h}
    </span>
  );
}

export function HealthDot({ h }: { h: Health | null | undefined }) {
  const dot = h === "Green" ? "bg-success" : h === "Yellow" ? "bg-warning" : h === "Red" ? "bg-destructive" : "bg-muted-foreground/40";
  return <span className={cn("inline-block h-2.5 w-2.5 shrink-0 rounded-full", dot)} />;
}

export function StagePill({ s }: { s: Stage }) {
  const cls = s === "Closed-No Go" ? "bg-muted text-muted-foreground" : s === "On Hold" ? "bg-warning-soft text-warning-foreground" : s === "Hypercare" || s === "Go-Live" ? "bg-success-soft text-success" : "bg-primary-soft text-primary";
  return <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap", cls)}>{s}</span>;
}

export function ProgressBar({ value, className }: { value: number | null; className?: string }) {
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full bg-muted", className)}>
      <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${value ?? 0}%` }} transition={{ duration: 0.8, ease: "easeOut" }} />
    </div>
  );
}

export function ReasonChips({ reasons }: { reasons: Reason[] }) {
  if (!reasons.length) return null;
  return (
    <div className="flex flex-wrap gap-1">
      {reasons.map((r) => (
        <span key={r.key} className={cn("rounded-full px-2 py-0.5 text-[11px] font-semibold", r.key === "red" || r.key === "overdue" ? "bg-danger-soft text-destructive" : "bg-warning-soft text-warning-foreground")}>{r.label}</span>
      ))}
    </div>
  );
}

export function PicBadge({ name }: { name: string }) {
  return <span className="inline-flex rounded-md bg-secondary px-1.5 py-0.5 text-[11px] font-semibold text-secondary-foreground">{name}</span>;
}

export function Initials({ name, className }: { name?: string | null; className?: string }) {
  const n = (name ?? "?").split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase();
  return <span title={name ?? ""} className={cn("inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ring-2 ring-card", className)} style={avatarStyle(name)}>{n || "?"}</span>;
}

export function ClientLogo({ client, className }: { client: string; className?: string }) {
  const { data: logos } = useClientLogos();
  const url = logos?.[client.trim().toLowerCase()];
  const n = client.replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter(Boolean).map((x) => x[0]).slice(0, 2).join("").toUpperCase();
  return url
    ? <img src={url} alt={`${client} logo`} className={cn("h-9 w-9 shrink-0 rounded-lg border bg-card object-contain p-0.5", className)} />
    : <span aria-hidden className={cn("inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-xs font-bold", className)} style={avatarStyle(client)}>{n || "?"}</span>;
}

export function Empty({ title, children, icon: Icon = Inbox, art = "empty" }: { title: string; children?: React.ReactNode; icon?: LucideIcon; art?: ArtName | null }) {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="relative overflow-hidden rounded-xl border border-dashed bg-card px-6 py-8 text-center">
      {art ? <Illustration name={art} float className="mx-auto mb-2 h-40 w-40" /> : <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-soft text-primary"><Icon className="h-6 w-6" /></div>}
      <p className="font-serif text-xl font-extrabold tracking-tight text-heading">{title}</p>
      {children && <div className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">{children}</div>}
    </motion.div>
  );
}

export function PageHeader({ title, sub, children, art }: { title: React.ReactNode; sub?: React.ReactNode; children?: React.ReactNode; icon?: LucideIcon; art?: ArtName }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b pb-5">
      <div className="flex min-w-0 items-end gap-4">
        {art && <Illustration name={art} className="-mb-5 hidden h-24 w-24 shrink-0 md:block" />}
      <div className="min-w-0">
        <h1 className="text-4xl leading-[1] md:text-6xl">{typeof title === "string" ? <BlueTail text={title} /> : title}</h1>
        {sub && <p className="mt-2 text-sm text-muted-foreground">{sub}</p>}
      </div>
      </div>
      {children && <div className="flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

export function Chip({ active, onClick, children }: { active?: boolean; onClick?: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={cn("rounded-md border px-3 py-1 text-xs font-semibold transition-colors whitespace-nowrap", active ? "border-primary bg-primary text-primary-foreground" : "bg-card text-foreground hover:bg-accent")}>
      {children}
    </button>
  );
}

export function TypeBadge({ type }: { type: string }) {
  const cls = type === "Bug" ? "bg-danger-soft text-destructive" : type === "Feature" ? "bg-success-soft text-success" : type === "Improvement" ? "bg-primary-soft text-primary" : "bg-muted text-muted-foreground";
  const I = type === "Bug" ? Bug : type === "Feature" ? Sparkles : type === "Improvement" ? TrendingUp : Wrench;
  return <span className={cn("inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-bold uppercase", cls)}><I className="h-3 w-3" />{type}</span>;
}
export function PrioBadge({ prio }: { prio: string }) {
  const cls = prio === "P1" ? "bg-destructive text-destructive-foreground" : prio === "P2" ? "bg-warning text-warning-foreground" : "bg-muted text-muted-foreground";
  return <span className={cn("inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-bold", cls)}><Flag className="h-3 w-3" />{prio}</span>;
}

export function StatCard({ icon: Icon, label, value, tone = "primary" }: { icon: LucideIcon; label: string; value: React.ReactNode; tone?: "primary" | "danger" | "warning" | "success" }) {
  const t = tone === "danger" ? "bg-danger-soft text-destructive" : tone === "warning" ? "bg-warning-soft text-warning-foreground" : tone === "success" ? "bg-success-soft text-success" : "bg-primary-soft text-primary";
  return (
    <div className={cn("flex flex-col justify-between gap-4 rounded-xl border bg-card p-5", tone === "primary" && "x-corner border-primary/40")}>
      <div className="flex items-center justify-between"><span className="eyebrow text-muted-foreground">{label}</span><span className={cn("flex h-7 w-7 items-center justify-center rounded-md", t)}><Icon className="h-4 w-4" /></span></div>
      <div className="stat-num text-5xl leading-none text-heading">{value}</div>
    </div>
  );
}

export function BlueTail({ text }: { text: string }) {
  const i = text.lastIndexOf(" ");
  if (i < 0) return <em>{text}</em>;
  return <>{text.slice(0, i + 1)}<em>{text.slice(i + 1)}</em></>;
}
