import { Link } from "@tanstack/react-router";
import { plainText } from "@/lib/richtext";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { updateProject, useUserId, type Project, qk } from "@/lib/data";
import { fmtDate, masihSamaBlock, progress, reasons, todayWIB } from "@/lib/rules";
import { ClientLogo, HealthPill, ProgressBar, ReasonChips, StagePill } from "./bits";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { Check } from "lucide-react";
import { Sticker } from "./fun";

export async function markMasihSama(p: Project, uid: string | null) {
  await updateProject(p.id, { last_updated: todayWIB(), last_updated_by: uid });
}

export function MasihSamaButton({ p, size = "sm", className }: { p: Project; size?: "sm" | "default"; className?: string }) {
  const uid = useUserId();
  const qc = useQueryClient();
  const block = masihSamaBlock(p, todayWIB());
  const [ok, setOk] = useState(false);
  const btn = (
    <Button size={size} variant="outline" disabled={!!block} className={className}
      onClick={async (e) => {
        e.preventDefault();
        try { await markMasihSama(p, uid); setOk(true); toast.success(`${p.client}: dicek, masih sama`); qc.invalidateQueries({ queryKey: qk.projects }); }
        catch (err) { toast.error((err as Error).message); }
      }}><AnimatePresence>{ok && <motion.span initial={{ scale: 0, rotate: -45 }} animate={{ scale: 1, rotate: 0 }}><Check className="h-4 w-4 text-success" /></motion.span>}</AnimatePresence>Masih sama</Button>
  );
  if (!block) return btn;
  return (
    <Tooltip><TooltipTrigger asChild><span tabIndex={0}>{btn}</span></TooltipTrigger><TooltipContent>{block}</TooltipContent></Tooltip>
  );
}

export function ProjectCard({ p, faded }: { p: Project; faded?: boolean }) {
  const today = todayWIB();
  const r = reasons(p, today);
  const block = masihSamaBlock(p, today);
  const pr = progress(p);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  return (
    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0, rotateX: tilt.x, rotateY: tilt.y }} transition={{ type: "spring", stiffness: 260, damping: 26 }}
      style={{ transformPerspective: 900 }}
      onMouseMove={(e) => { if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return; const b = e.currentTarget.getBoundingClientRect(); setTilt({ x: ((e.clientY - b.top) / b.height - 0.5) * -4, y: ((e.clientX - b.left) / b.width - 0.5) * 4 }); }}
      onMouseLeave={() => setTilt({ x: 0, y: 0 })}
      className={cn("card-soft relative h-full p-5", r.length && "card-ribbon-danger", faded && "opacity-60")}>
      {(p.stage === "Go-Live" || p.stage === "Hypercare") && <Sticker tone="success" className="absolute -top-2 right-6">{p.stage === "Go-Live" ? "Go-Live!" : "Hypercare"}</Sticker>}
      {r.some((x) => x.key === "overdue") && <Sticker tone="danger" className="absolute -top-2 right-6 rotate-3">Overdue</Sticker>}
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-3">
          <ClientLogo client={p.client} className="h-11 w-11" />
          <div className="min-w-0">
          <Link to="/proyek/$id" params={{ id: p.id }} className="font-serif text-xl font-bold leading-tight text-heading hover:text-primary">{p.client}</Link>
          <div className="truncate text-sm text-muted-foreground">{p.project}</div>
          </div>
        </div>
        <HealthPill h={p.health} />
      </div>
      <div className="mt-3 flex items-center gap-2">
        <StagePill s={p.stage} />
        <ProgressBar value={pr} className="flex-1" />
        <span className="text-xs font-semibold">{pr === null ? "n/a" : `${pr}%`}</span>
      </div>
      {r.length > 0 && <div className="mt-2"><ReasonChips reasons={r} /></div>}
      <div className="mt-4 space-y-2 text-sm">
        <div><span className="mr-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Next</span>{plainText(p.next_action) || <i className="text-muted-foreground">Not provided</i>}
          {p.next_action_due && <span className={cn("ml-1 text-xs", p.next_action_due < today ? "font-semibold text-destructive" : "text-muted-foreground")}>· {fmtDate(p.next_action_due)}</span>}</div>
        <div className="flex flex-wrap gap-x-4 text-xs text-muted-foreground">
          <span>Target: {fmtDate(p.target_date) || "Not set"}</span>
          <span>Action with: {p.ball_in_court === "Client" ? "Client" : p.ball_in_court ?? "Not set"}</span>
        </div>
      </div>
      {!faded && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {!block && <MasihSamaButton p={p} />}
          <Button size="sm" asChild variant={block ? "default" : "secondary"}>
            <Link to="/proyek/$id" params={{ id: p.id }}>{block ? "Update now" : "Update status"}</Link>
          </Button>
          {block && <span className="text-xs text-warning-foreground dark:text-warning">{block}</span>}
        </div>
      )}
    </motion.div>
  );
}
