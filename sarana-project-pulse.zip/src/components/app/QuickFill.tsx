import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Wand2, ChevronDown, Info } from "lucide-react";
import { toast } from "sonner";
import { aiFill } from "@/lib/ai-fill.functions";
import { usePeople, useProjects } from "@/lib/data";
import { todayWIB } from "@/lib/rules";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SaranaDots } from "./brand";
import { cn } from "@/lib/utils";

type Kind = "project" | "task" | "update";

export function QuickFill({ kind, onFill, defaultOpen = true }: { kind: Kind; onFill: (v: Record<string, unknown>) => string[]; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ filled: string[]; notes: string[] } | null>(null);
  const run = useServerFn(aiFill);
  const { data: people = [] } = usePeople();
  const { data: projects = [] } = useProjects();

  async function go() {
    if (text.trim().length < 3) { toast.error("Paste some text first"); return; }
    setBusy(true);
    try {
      const r = await run({ data: {
        kind, text, today: todayWIB(),
        people: people.filter((p) => p.active !== false).map((p) => ({ id: p.id, name: p.name, title: p.title })),
        projects: projects.map((p) => ({ id: p.id, client: p.client, project: p.project })),
      } });
      if (!r.ok) { toast.error(r.error); return; }
      const filled = onFill(r.values);
      const notes = Array.isArray(r.values["notes"]) ? (r.values["notes"] as string[]) : [];
      setResult({ filled, notes });
      toast.success(filled.length ? `Filled ${filled.length} fields. Review before saving.` : "Nothing to fill from that text");
    } catch {
      toast.error("Could not reach AI. Try again.");
    } finally { setBusy(false); }
  }

  return (
    <div className="relative overflow-hidden rounded-xl border border-primary/30 bg-card">
      <button type="button" onClick={() => setOpen((o) => !o)} className="flex w-full items-center gap-3 px-5 py-4 text-left">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground"><Sparkles className="h-4 w-4" /></span>
        <span className="flex-1">
          <span className="block font-bold text-heading">Quick fill with AI</span>
          <span className="block text-xs text-muted-foreground">Paste notes, a chat, or a Claude summary. AI fills the form for you to review.</span>
        </span>
        <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="space-y-3 px-5 pb-5">
          <div className="relative">
            <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={5} placeholder="Example: Meeting with Bank Nusantara today. They want a WhatsApp CS chatbot, POC kickoff next Monday, Faiz as PIC, AM Dhania. Next: send proposal by Friday." className="min-h-28" disabled={busy} />
            {busy && (
              <div className="absolute inset-0 flex items-center justify-center gap-3 rounded-[10px] bg-card/85 text-sm font-medium text-primary backdrop-blur-[1px]">
                <SaranaDots className="dot-pulse h-10 w-10" /> Reading your text...
              </div>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button type="button" onClick={go} disabled={busy}><Wand2 className="mr-1 h-4 w-4" />{busy ? "Filling..." : "Fill form"}</Button>
            {text && !busy && <Button type="button" variant="ghost" onClick={() => { setText(""); setResult(null); }}>Clear</Button>}
            <span className="text-xs text-muted-foreground">Nothing is saved until you press Create.</span>
          </div>
          {result && (
            <div className="rounded-lg bg-accent/60 p-3 text-sm">
              <div className="font-semibold text-heading">Filled: {result.filled.length ? result.filled.join(", ") : "none"}</div>
              {result.notes.map((n) => <div key={n} className="mt-1 flex gap-1.5 text-muted-foreground"><Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />{n}</div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** Wraps a field to show a soft blue ring when AI filled it. */
export function AiMark({ on, children }: { on: boolean; children: React.ReactNode }) {
  return <div className={cn("relative rounded-[12px] transition-shadow", on && "ring-2 ring-primary/35 ring-offset-2 ring-offset-card")}>{on && <span className="absolute -top-2.5 right-2 z-10 rounded bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">AI</span>}{children}</div>;
}
