import { useRouterState } from "@tanstack/react-router";
import dotsUrl from "@/assets/sarana-dots.svg";
import logo from "@/assets/sarana-logo.png.asset.json";
import { cn } from "@/lib/utils";

/** Halftone Sarana logo made of dots. */
export function SaranaDots({ className, style }: { className?: string; style?: React.CSSProperties }) {
  return <img aria-hidden src={dotsUrl} alt="" draggable={false} style={style} className={cn("sarana-dots pointer-events-none select-none object-contain", className)} />;
}

export function SaranaLogo({ className }: { className?: string }) {
  return <img src={logo.url} alt="Sarana" className={cn("h-6 w-6 object-contain", className)} />;
}

/** Thin blue bar at the top while a page is loading. */
export function NavProgress() {
  const loading = useRouterState({ select: (s) => s.status === "pending" || s.isLoading });
  return (
    <div aria-hidden className={cn("pointer-events-none fixed inset-x-0 top-0 z-[100] h-0.5 overflow-hidden transition-opacity", loading ? "opacity-100" : "opacity-0")}>
      <div className="nav-progress h-full w-1/3 bg-primary" />
    </div>
  );
}

/** Small pulsing dot loader. */
export function DotLoader({ label = "Loading" }: { label?: string }) {
  return (
    <div role="status" className="flex flex-col items-center justify-center gap-3 py-16 text-sm text-muted-foreground">
      <SaranaDots className="dot-pulse h-16 w-16" />
      <span>{label}</span>
    </div>
  );
}

export function PageSkeleton() {
  return (
    <div className="space-y-4">
      <div className="h-28 animate-pulse rounded-xl bg-muted" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }, (_, i) => <div key={i} className="h-36 animate-pulse rounded-xl bg-muted" style={{ animationDelay: `${i * 80}ms` }} />)}
      </div>
    </div>
  );
}
