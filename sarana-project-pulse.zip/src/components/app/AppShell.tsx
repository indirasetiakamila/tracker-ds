import { FocusDock } from "@/components/app/FocusDock";
import { useInboxCount } from "@/lib/insights";
import { SaranaDots, SaranaLogo, NavProgress } from "./brand";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { CalendarCheck, Columns3, Table2, ListTodo, Users, Wrench, BarChart3, Shield, LogOut, Bot } from "lucide-react";
import type { ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useProjects, useRealtime, useSyncStatus, useTasks, useTodos } from "@/lib/data";
import { checkedThisWeek, isActive, needsStandup, todayWIB } from "@/lib/rules";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  useRealtime();
  const { me, uid, isAdmin } = useMe();
  const { data: projects = [] } = useProjects();
  const { data: todos = [] } = useTodos();
  const { data: tasks = [] } = useTasks();
  const sync = useSyncStatus();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const today = todayWIB();
  const path = useLocation({ select: (l) => l.pathname });
  const isOn = (to: string) => path === to || path.startsWith(to + "/");

  const active = projects.filter(isActive);
  const mine = active.filter((p) => me?.pic_name && p.pic === me.pic_name);
  const badges = {
    minggu: mine.filter((p) => !checkedThisWeek(p, today)).length,
    standup: active.filter((p) => needsStandup(p, today)).length,
    prio: todos.filter((t) => t.owner === uid && t.date === today && !t.done).length,
    tasks: tasks.filter((t) => t.status === "Blocked").length,
  };

  const inboxNew = useInboxCount();
  const nav = [
    { to: "/minggu-ini", label: "This Week", icon: CalendarCheck, badge: badges.minggu },
    { to: "/board", label: "Board", icon: Columns3 },
    { to: "/register", label: "Register", icon: Table2 },
    { to: "/prioritas", label: "Priorities", icon: ListTodo, badge: badges.prio },
    { to: "/standup", label: "Standup", icon: Users, badge: badges.standup },
    { to: "/tasks", label: "Engineering tasks", icon: Wrench, badge: badges.tasks },
    { to: "/report", label: "Report", icon: BarChart3 },
    { to: "/asisten", label: "AI Assistants", icon: Bot, badge: inboxNew },
    ...(isAdmin ? [{ to: "/admin", label: "Admin", icon: Shield }] : []),
  ] as const;

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const dot = sync === "live" ? "bg-success" : sync === "offline" ? "bg-destructive" : "bg-warning";

  return (
    <div className="min-h-screen md:flex">
      {/* Desktop sidebar */}
      <aside className="hidden w-[15.5rem] shrink-0 md:block">
        <div className="fixed inset-y-3 left-3 flex w-56 flex-col overflow-hidden rounded-xl border bg-sidebar text-sidebar-foreground">
          <div className="px-5 py-5">
            <div className="flex items-center gap-2 font-serif text-2xl font-extrabold leading-none tracking-tight text-sidebar-accent-foreground"><SaranaLogo />Sarana</div>
            <div className="mt-1 text-[11px] font-semibold uppercase tracking-[0.18em] opacity-70">DS Project Register</div>
          </div>
          <nav className="flex-1 space-y-0.5 px-2">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} className={cn("group relative flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors", isOn(n.to) ? "font-semibold text-sidebar-primary-foreground" : "hover:bg-sidebar-accent")}>
                {isOn(n.to) && <motion.span layoutId="side-pill" className="absolute inset-0 rounded-md bg-sidebar-primary" transition={{ type: "spring", stiffness: 380, damping: 32 }} />}
                <n.icon className="relative h-4 w-4 transition-transform group-hover:[animation:wiggle_.5s_ease-in-out]" />
                <span className="relative flex-1">{n.label}</span>
                {"badge" in n && n.badge ? <span className="relative rounded-full bg-warning px-1.5 text-[11px] font-bold text-warning-foreground">{n.badge}</span> : null}
              </Link>
            ))}
          </nav>
          <div className="relative mx-3 mb-3 overflow-hidden rounded-lg border bg-ink p-3 text-xs leading-snug text-ink-foreground">
            <SaranaDots className="absolute -right-6 -top-4 h-24 w-24 opacity-30" />
            <div className="relative eyebrow mb-1 opacity-60">Principle</div>
            <span className="relative text-sm font-medium">Progress is best measured through consistency, not volume.</span>
          </div>
          <div className="border-t border-sidebar-border p-4 text-sm">
            <div className="truncate font-semibold text-sidebar-accent-foreground">{me?.name ?? "..."}</div>
            <div className="mt-1 flex items-center justify-between text-xs opacity-80">
              <span className="flex items-center gap-1.5"><span className={cn("h-2 w-2 rounded-full", dot)} />{sync === "live" ? "Live" : sync === "offline" ? "Offline" : "Connecting"}</span>
              <button onClick={signOut} className="flex items-center gap-1 hover:opacity-100" aria-label="Sign out"><LogOut className="h-3.5 w-3.5" />Sign out</button>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 border-b bg-sidebar text-sidebar-foreground md:hidden">
        <div className="flex items-center justify-between px-4 py-2.5">
          <div className="flex items-center gap-2 font-serif text-xl font-extrabold tracking-tight text-sidebar-accent-foreground"><SaranaLogo />Sarana</div>
          <div className="flex items-center gap-3 text-xs">
            <span className={cn("h-2 w-2 rounded-full", dot)} />
            <button onClick={signOut} aria-label="Sign out"><LogOut className="h-4 w-4" /></button>
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-2 pb-2">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className={cn("flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-xs", isOn(n.to) && "bg-sidebar-primary font-semibold text-sidebar-primary-foreground")}>
              <n.icon className="h-3.5 w-3.5" />{n.label}
              {"badge" in n && n.badge ? <span className="rounded-full bg-warning px-1 text-[10px] font-bold text-warning-foreground">{n.badge}</span> : null}
            </Link>
          ))}
        </nav>
      </header>

      <NavProgress />
      <main className="min-w-0 flex-1 px-4 py-5 md:px-8 md:py-7">
        <motion.div key={path} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.15, ease: "easeOut" }}>{children}</motion.div>
      </main>
      <FocusDock />
    </div>
  );
}

