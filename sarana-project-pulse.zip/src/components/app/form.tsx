import { motion } from "framer-motion";
import { Minus, Plus, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function FormSection({ icon: Icon, title, hint, children, i = 0 }: { icon: LucideIcon; title: string; hint?: string; children: React.ReactNode; i?: number }) {
  return (
    <motion.section initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07, duration: 0.35 }}
      className="rounded-[1.75rem] border border-border/50 bg-card p-5 shadow-card sm:p-6">
      <header className="mb-4 flex items-center gap-3">
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-primary-soft text-primary"><Icon className="h-4.5 w-4.5" /></span>
        <div>
          <h2 className="font-serif text-xl font-bold leading-tight">{title}</h2>
          {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
        </div>
      </header>
      <div className="space-y-4">{children}</div>
    </motion.section>
  );
}

export function Field({ label, req, hint, children, className }: { label: string; req?: boolean; hint?: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={cn("block space-y-1.5", className)}>
      <span className="flex items-baseline gap-1 text-[11px] font-bold uppercase tracking-[0.12em] text-muted-foreground">
        {label}{req && <span className="text-primary">*</span>}
        {hint && <span className="ml-auto font-normal normal-case tracking-normal">{hint}</span>}
      </span>
      {children}
    </label>
  );
}

export function IconInput({ icon: Icon, prefix, suffix, className, ...props }: React.ComponentProps<"input"> & { icon?: LucideIcon; prefix?: string; suffix?: string }) {
  return (
    <div className="group flex h-11 items-center gap-2 rounded-[10px] border border-transparent bg-muted/70 px-3 transition focus-within:border-primary focus-within:bg-card focus-within:ring-4 focus-within:ring-primary/15">
      {Icon && <Icon className="h-4 w-4 shrink-0 text-muted-foreground transition group-focus-within:text-primary" />}
      {prefix && <span className="text-sm font-semibold text-muted-foreground">{prefix}</span>}
      <input {...props} className={cn("h-full w-full min-w-0 bg-transparent text-sm outline-none placeholder:text-muted-foreground/70", className)} />
      {suffix && <span className="shrink-0 text-xs text-muted-foreground">{suffix}</span>}
    </div>
  );
}

export type ChipOpt = { v: string; l: string; icon?: LucideIcon; tone?: string };

export function ChipSelect({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: ChipOpt[] }) {
  return (
    <div className="flex flex-wrap gap-2" role="radiogroup">
      {options.map((o) => {
        const on = o.v === value;
        const Icon = o.icon;
        return (
          <button key={o.v} type="button" role="radio" aria-checked={on} onClick={() => onChange(o.v)}
            className={cn("relative inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition active:scale-95",
              on ? cn("border-transparent shadow-sm", o.tone ?? "bg-primary text-primary-foreground") : "border-input bg-card/60 text-muted-foreground hover:border-primary/30 hover:bg-powder/30 hover:text-heading")}>
            {Icon && <Icon className="h-3.5 w-3.5" />}{o.l}
          </button>
        );
      })}
    </div>
  );
}

export function Stepper({ value, onChange, step = 1 }: { value: string; onChange: (v: string) => void; step?: number }) {
  const n = Number(value) || 0;
  const btn = "inline-flex h-8 w-8 items-center justify-center rounded-full bg-muted text-heading transition hover:bg-powder active:scale-90";
  return (
    <div className="flex h-11 items-center justify-between gap-2 rounded-[10px] bg-muted/70 px-1.5">
      <button type="button" className={btn} onClick={() => onChange(n - step <= 0 ? "" : String(n - step))} aria-label="Kurangi"><Minus className="h-3.5 w-3.5" /></button>
      <input inputMode="decimal" value={value} onChange={(e) => onChange(e.target.value.replace(/[^0-9.]/g, ""))} placeholder="0"
        className="w-12 bg-transparent text-center text-sm font-semibold outline-none" />
      <button type="button" className={btn} onClick={() => onChange(String(n + step))} aria-label="Increase"><Plus className="h-3.5 w-3.5" /></button>
    </div>
  );
}

/** Sticky bottom action bar for long forms. */
export function FormActions({ children }: { children: React.ReactNode }) {
  return (
    <div className="sticky bottom-3 z-10 flex items-center justify-end gap-2 rounded-full border border-border/50 bg-card/90 p-2 shadow-lift backdrop-blur">
      {children}
    </div>
  );
}
