import { useEffect, useState } from "react";
import { EditorContent, useEditor, type Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Highlight from "@tiptap/extension-highlight";
import TaskList from "@tiptap/extension-task-list";
import TaskItem from "@tiptap/extension-task-item";
import Placeholder from "@tiptap/extension-placeholder";
import { Bold, Code, Heading1, Heading2, Highlighter, Italic, Link2, List, ListChecks, ListOrdered, Quote, Strikethrough, Underline as UnderlineIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { isRich, plainToHtml } from "@/lib/richtext";

function Tool({ on, active, label, children }: { on: () => void; active?: boolean; label: string; children: React.ReactNode }) {
  return (
    <button type="button" title={label} aria-label={label} onMouseDown={(e) => e.preventDefault()} onClick={on}
      className={cn("inline-flex h-7 w-7 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-powder/50 hover:text-heading", active && "bg-primary-soft text-primary")}>
      {children}
    </button>
  );
}

function Toolbar({ editor }: { editor: Editor }) {
  const c = () => editor.chain().focus();
  const link = () => {
    const prev = editor.getAttributes("link")["href"] as string | undefined;
    const url = window.prompt("Link URL", prev ?? "https://");
    if (url === null) return;
    if (!url) c().unsetLink().run(); else c().extendMarkRange("link").setLink({ href: url }).run();
  };
  const sep = <span className="mx-0.5 h-4 w-px bg-border" />;
  return (
    <div className="flex flex-wrap items-center gap-0.5 border-b border-border/70 px-2 py-1.5">
      <Tool label="Bold (Ctrl+B)" active={editor.isActive("bold")} on={() => c().toggleBold().run()}><Bold className="h-3.5 w-3.5" /></Tool>
      <Tool label="Italic (Ctrl+I)" active={editor.isActive("italic")} on={() => c().toggleItalic().run()}><Italic className="h-3.5 w-3.5" /></Tool>
      <Tool label="Underline (Ctrl+U)" active={editor.isActive("underline")} on={() => c().toggleUnderline().run()}><UnderlineIcon className="h-3.5 w-3.5" /></Tool>
      <Tool label="Strikethrough" active={editor.isActive("strike")} on={() => c().toggleStrike().run()}><Strikethrough className="h-3.5 w-3.5" /></Tool>
      <Tool label="Highlight" active={editor.isActive("highlight")} on={() => c().toggleHighlight().run()}><Highlighter className="h-3.5 w-3.5" /></Tool>
      {sep}
      <Tool label="Large heading" active={editor.isActive("heading", { level: 2 })} on={() => c().toggleHeading({ level: 2 }).run()}><Heading1 className="h-3.5 w-3.5" /></Tool>
      <Tool label="Small heading" active={editor.isActive("heading", { level: 3 })} on={() => c().toggleHeading({ level: 3 }).run()}><Heading2 className="h-3.5 w-3.5" /></Tool>
      {sep}
      <Tool label="Bullet list" active={editor.isActive("bulletList")} on={() => c().toggleBulletList().run()}><List className="h-3.5 w-3.5" /></Tool>
      <Tool label="Numbered list" active={editor.isActive("orderedList")} on={() => c().toggleOrderedList().run()}><ListOrdered className="h-3.5 w-3.5" /></Tool>
      <Tool label="Checklist" active={editor.isActive("taskList")} on={() => c().toggleTaskList().run()}><ListChecks className="h-3.5 w-3.5" /></Tool>
      <Tool label="Quote" active={editor.isActive("blockquote")} on={() => c().toggleBlockquote().run()}><Quote className="h-3.5 w-3.5" /></Tool>
      <Tool label="Code" active={editor.isActive("code")} on={() => c().toggleCode().run()}><Code className="h-3.5 w-3.5" /></Tool>
      <Tool label="Link" active={editor.isActive("link")} on={link}><Link2 className="h-3.5 w-3.5" /></Tool>
    </div>
  );
}

export function RichTextEditor({ value, onChange, placeholder, minHeight = 120, className, disabled }: {
  value: string; onChange: (html: string) => void; placeholder?: string; minHeight?: number; className?: string; disabled?: boolean;
}) {
  const editor = useEditor({
    immediatelyRender: false,
    editable: !disabled,
    extensions: [
      StarterKit.configure({ heading: { levels: [2, 3] }, link: { openOnClick: false, autolink: true } }),
      Highlight, TaskList, TaskItem.configure({ nested: true }),
      Placeholder.configure({ placeholder: placeholder ?? "Write here..." }),
    ],
    content: isRich(value) ? value : plainToHtml(value),
    editorProps: { attributes: { class: "rt-content focus:outline-none px-3 py-2", style: `min-height:${minHeight}px` } },
    onUpdate: ({ editor }) => onChange(editor.isEmpty ? "" : editor.getHTML()),
  });
  // Sync external resets (e.g. after save or realtime refresh) without clobbering typing.
  useEffect(() => {
    if (!editor) return;
    const cur = editor.isEmpty ? "" : editor.getHTML();
    const next = isRich(value) ? value : plainToHtml(value);
    if (value !== cur && next !== cur && !editor.isFocused) editor.commands.setContent(next, { emitUpdate: false });
  }, [value, editor]);
  useEffect(() => { editor?.setEditable(!disabled); }, [disabled, editor]);

  return (
    <div className={cn("overflow-hidden rounded-[10px] border border-transparent bg-muted/70 transition focus-within:border-primary focus-within:bg-card focus-within:ring-4 focus-within:ring-primary/15", disabled && "opacity-60", className)}>
      {editor ? <Toolbar editor={editor} /> : <div className="h-[41px] border-b border-border/70" />}
      <EditorContent editor={editor} />
    </div>
  );
}

/** Read-only render of stored rich text (sanitized in the browser; plain text on the server). */
export function RichText({ value, className, empty }: { value: string | null | undefined; className?: string; empty?: React.ReactNode }) {
  const [html, setHtml] = useState<string | null>(null);
  useEffect(() => {
    if (!value) { setHtml(null); return; }
    const src = isRich(value) ? value : plainToHtml(value);
    import("dompurify").then(({ default: DOMPurify }) => setHtml(DOMPurify.sanitize(src, { ADD_ATTR: ["data-type", "data-checked", "target"] })));
  }, [value]);
  if (!value) return <>{empty ?? null}</>;
  if (html === null) return <div className={cn("rt-content whitespace-pre-wrap", className)}>{value.replace(/<[^>]+>/g, " ")}</div>;
  return <div className={cn("rt-content", className)} dangerouslySetInnerHTML={{ __html: html }} />;
}
