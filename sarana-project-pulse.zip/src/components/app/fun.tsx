import { motion } from "framer-motion";
import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import teamArt from "@/assets/illustrations/team.png";
import doneArt from "@/assets/illustrations/done.png";
import emptyArt from "@/assets/illustrations/empty.png";
import busyArt from "@/assets/illustrations/busy.png";
import lostArt from "@/assets/illustrations/lost.png";
import reportArt from "@/assets/illustrations/report.png";
import inboxArt from "@/assets/illustrations/inbox.png";

export const ART = { team: teamArt, done: doneArt, empty: emptyArt, busy: busyArt, lost: lostArt, report: reportArt, inbox: inboxArt } as const;
export type ArtName = keyof typeof ART;

export function Illustration({ name, className, float }: { name: ArtName; className?: string; float?: boolean }) {
  return (
    <motion.img src={ART[name]} alt="" aria-hidden width={640} height={640} loading="lazy"
      className={cn("pointer-events-none select-none object-contain", className)}
      initial={{ opacity: 0, scale: 0.92, rotate: -2 }} animate={float ? { opacity: 1, scale: 1, rotate: 0, y: [0, -6, 0] } : { opacity: 1, scale: 1, rotate: 0 }}
      transition={float ? { y: { duration: 5, repeat: Infinity, ease: "easeInOut" }, default: { type: "spring", stiffness: 120, damping: 14 } } : { type: "spring", stiffness: 120, damping: 14 }} />
  );
}

export function CountUp({ to, className }: { to: number; className?: string }) {
  return <span className={className}>{to}</span>;
}

/** Italic emphasis (formerly a scribble underline). */
export function Scribble({ children }: { children: React.ReactNode }) {
  return <em>{children}</em>;
}

export const stagger = {
  container: { hidden: {}, show: { transition: { staggerChildren: 0.06 } } },
  item: { hidden: { opacity: 0, y: 14 }, show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 260, damping: 24 } } },
};

export function Stagger({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={className}>{children}</div>;
}
export function StaggerItem({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={className}>{children}</div>;
}

export function Sticker({ children, tone = "primary", className }: { children: React.ReactNode; tone?: "primary" | "danger" | "success"; className?: string }) {
  const t = tone === "danger" ? "bg-destructive text-destructive-foreground" : tone === "success" ? "bg-success text-success-foreground" : "bg-primary text-primary-foreground";
  return <span className={cn("inline-block rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide", t, className)}>{children}</span>;
}

export function Skeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="shimmer h-24 rounded-2xl bg-muted" style={{ opacity: 1 - i * 0.2 }} />)}
    </div>
  );
}

export async function celebrate() {
  if (typeof window === "undefined" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const confetti = (await import("canvas-confetti")).default;
  confetti({ particleCount: 90, spread: 75, origin: { y: 0.3 }, colors: ["#1414F0", "#0A0A0A", "#FFFFFF", "#6B6BFF"] });
}

const AVATAR_HUES = [2, 245, 160, 75, 300, 30, 200];
export function avatarStyle(name?: string | null): React.CSSProperties {
  let h = 0; for (const ch of name ?? "") h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const hue = AVATAR_HUES[h % AVATAR_HUES.length];
  return { backgroundColor: `oklch(0.88 0.06 ${hue})`, color: `oklch(0.32 0.09 ${hue})` };
}

export function greeting(name?: string | null, now = new Date()) {
  const wib = new Date(now.getTime() + 7 * 3600_000);
  const h = wib.getUTCHours(), day = wib.getUTCDay();
  const part = h < 11 ? "Good morning" : h < 15 ? "Good afternoon" : h < 18 ? "Good afternoon" : "Good evening";
  const first = (name ?? "").split(" ")[0];
  const lines: Record<number, string[]> = {
    1: ["Ease into the week.", "A fresh week, a fresh start."],
    5: ["Friday is here. Finish your updates before 17:00.", "One last push before the weekend."],
  };
  const pool = lines[day] ?? ["A quick check, then back to work.", "A minute to update, more time to code.", "Wishing you a smooth day."];
  return { hello: `${part}${first ? `, ${first}` : ""}`, line: pool[wib.getUTCDate() % pool.length], isFriday: day === 5 };
}
