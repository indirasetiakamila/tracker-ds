import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const migration = readFileSync("drizzle/migrations/0009_registered_email_login.sql", "utf8");
const trigger = migration.split("CREATE OR REPLACE FUNCTION public.is_registered")[0] ?? "";
const adminList = trigger.match(/in \(([^)]+)\);/i)?.[1] ?? "";
const adminEmails = [...adminList.matchAll(/'([^']+)'/g)].map((m) => m[1]);

describe("sign-in eligibility", () => {
  it("keeps admin@sarana.ai and indira@sarana.ai as admins", () => {
    expect(adminEmails).toEqual(["admin@sarana.ai", "indira@sarana.ai"]);
  });
  it("no longer requires an @sarana.ai address", () => {
    expect(migration).not.toMatch(/not like '%@sarana\.ai'/);
  });
  it("refuses emails not on the active Team list", () => {
    expect(trigger).toMatch(/lower\(email\) = lower\(new\.email\) and active/);
    expect(trigger).toMatch(/if not found and not v_admin then\s+raise exception/);
  });
});
