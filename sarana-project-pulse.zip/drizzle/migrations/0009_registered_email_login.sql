CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_name text := coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1));
  v_pic text := null;
  v_role public.app_role := 'engineer';
  v_person public.people%rowtype;
  v_admin boolean := lower(coalesce(new.email,'')) in ('admin@sarana.ai', 'indira@sarana.ai');
begin
  select * into v_person from public.people where lower(email) = lower(new.email) and active limit 1;
  if not found and not v_admin then
    raise exception 'This email is not registered. Ask an admin to add you.';
  end if;
  if v_person.id is not null then
    if v_person.title in ('pic','lead') then v_pic := v_person.name; v_role := 'pic'; end if;
    if v_person.title = 'lead' then v_role := 'lead'; end if;
  end if;
  if v_admin then v_role := 'admin'; end if;
  insert into public.profiles (id, name, email, pic_name) values (new.id, v_name, new.email, v_pic);
  insert into public.user_roles (user_id, role) values (new.id, v_role);
  if v_person.id is not null then
    update public.people set user_id = new.id where id = v_person.id;
  else
    insert into public.people (name, email, title, user_id) values (v_name, new.email, 'engineer', new.id) on conflict (email) do nothing;
  end if;
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.is_registered()
 RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  select lower(coalesce(auth.jwt()->>'email','')) in ('admin@sarana.ai','indira@sarana.ai')
    or exists (select 1 from public.people where lower(email) = lower(auth.jwt()->>'email') and active)
$$;
GRANT EXECUTE ON FUNCTION public.is_registered() TO authenticated;