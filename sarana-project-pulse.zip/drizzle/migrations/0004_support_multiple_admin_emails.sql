CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_name text := coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1));
  v_first text := initcap(lower(split_part(v_name,' ',1)));
  v_pic text := null;
  v_role public.app_role := 'engineer';
  v_person public.people%rowtype;
begin
  if lower(coalesce(new.email,'')) not like '%@sarana.ai' then
    raise exception 'Hanya email @sarana.ai yang boleh masuk';
  end if;
  select * into v_person from public.people where lower(email) = lower(new.email) limit 1;
  if found then
    if v_person.title in ('pic','lead') then v_pic := v_person.name; v_role := 'pic'; end if;
    if v_person.title = 'lead' then v_role := 'lead'; end if;
  else
    if v_first in ('Faiz','Dhania','Keysa','Tira','Indira') then v_pic := v_first; v_role := 'pic'; end if;
    if v_first = 'Indira' then v_role := 'lead'; end if;
  end if;
  if lower(new.email) in ('admin@sarana.ai', 'indira@sarana.ai') then v_role := 'admin'; end if;
  insert into public.profiles (id, name, email, pic_name) values (new.id, v_name, new.email, v_pic);
  insert into public.user_roles (user_id, role) values (new.id, v_role);
  if v_person.id is not null then
    update public.people set user_id = new.id where id = v_person.id;
  else
    insert into public.people (name, email, title, user_id) values (v_name, new.email, case when v_pic is not null then 'pic'::public.person_title else 'engineer' end, new.id) on conflict (email) do nothing;
  end if;
  return new;
end $function$;