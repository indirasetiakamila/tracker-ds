CREATE TABLE public.assistant_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL DEFAULT auth.uid(),
  key_name text,
  kind text NOT NULL DEFAULT 'insight' CHECK (kind IN ('insight','action')),
  title text NOT NULL,
  body_html text NOT NULL DEFAULT '',
  project_id text REFERENCES public.projects(id) ON DELETE SET NULL,
  suggested_owner text,
  suggested_due date,
  source text,
  confidence text CHECK (confidence IS NULL OR confidence IN ('low','medium','high')),
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','accepted','dismissed','applied','snoozed')),
  snoozed_until date,
  reviewed_by uuid,
  reviewed_at timestamptz
);
GRANT SELECT, INSERT, UPDATE ON public.assistant_insights TO authenticated;
GRANT ALL ON public.assistant_insights TO service_role;
ALTER TABLE public.assistant_insights ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team reads insights" ON public.assistant_insights FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert own insights" ON public.assistant_insights FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "reviewers update insights" ON public.assistant_insights FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));
CREATE INDEX assistant_insights_created_idx ON public.assistant_insights (created_at DESC);
CREATE INDEX assistant_insights_status_idx ON public.assistant_insights (status);
ALTER PUBLICATION supabase_realtime ADD TABLE public.assistant_insights;