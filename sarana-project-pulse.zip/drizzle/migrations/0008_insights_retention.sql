CREATE OR REPLACE FUNCTION public.purge_old_insights() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  DELETE FROM public.assistant_insights WHERE created_at < now() - interval '28 days';
  RETURN NULL;
END $$;
CREATE TRIGGER assistant_insights_purge AFTER INSERT ON public.assistant_insights FOR EACH STATEMENT EXECUTE FUNCTION public.purge_old_insights();