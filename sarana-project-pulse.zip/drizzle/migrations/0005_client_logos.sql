CREATE TABLE public.client_logos (
  client text PRIMARY KEY,
  url text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid DEFAULT auth.uid()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.client_logos TO authenticated;
GRANT ALL ON public.client_logos TO service_role;
ALTER TABLE public.client_logos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read logos" ON public.client_logos FOR SELECT TO authenticated USING (true);
CREATE POLICY "editors insert logos" ON public.client_logos FOR INSERT TO authenticated WITH CHECK (public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));
CREATE POLICY "editors update logos" ON public.client_logos FOR UPDATE TO authenticated USING (public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));
CREATE POLICY "editors delete logos" ON public.client_logos FOR DELETE TO authenticated USING (public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));
ALTER PUBLICATION supabase_realtime ADD TABLE public.client_logos;
CREATE POLICY "logo files read" ON storage.objects FOR SELECT USING (bucket_id = 'client-logos');
CREATE POLICY "logo files insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'client-logos' AND public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));
CREATE POLICY "logo files update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'client-logos' AND public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));
CREATE POLICY "logo files delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'client-logos' AND public.has_any_role(auth.uid(), ARRAY['pic','lead','admin']::app_role[]));