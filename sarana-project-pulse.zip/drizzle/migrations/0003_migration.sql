CREATE TABLE public.mcp_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL,
  key_hash text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz,
  revoked_at timestamptz
);
GRANT SELECT, UPDATE ON public.mcp_keys TO authenticated;
GRANT ALL ON public.mcp_keys TO service_role;
ALTER TABLE public.mcp_keys ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own keys read" ON public.mcp_keys FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "own keys revoke" ON public.mcp_keys FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.create_mcp_key(_name text, _hash text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not signed in'; END IF;
  IF coalesce(trim(_name),'') = '' OR length(_name) > 60 THEN RAISE EXCEPTION 'invalid name'; END IF;
  IF _hash !~ '^[0-9a-f]{64}$' THEN RAISE EXCEPTION 'invalid hash'; END IF;
  INSERT INTO mcp_keys(user_id, name, key_hash) VALUES (auth.uid(), trim(_name), _hash) RETURNING id INTO _id;
  RETURN _id;
END $$;
REVOKE ALL ON FUNCTION public.create_mcp_key(text,text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.create_mcp_key(text,text) TO authenticated;