CREATE TYPE public.person_title AS ENUM ('engineer','pm','am','pic','lead');
CREATE TABLE public.people (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE,
  title public.person_title NOT NULL DEFAULT 'engineer',
  active boolean NOT NULL DEFAULT true,
  user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.people TO authenticated;
GRANT ALL ON public.people TO service_role;
ALTER TABLE public.people ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read people" ON public.people FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin insert people" ON public.people FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin update people" ON public.people FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete people" ON public.people FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));
ALTER PUBLICATION supabase_realtime ADD TABLE public.people;

INSERT INTO public.people (name, email, title) VALUES
 ('Faiz','faiz@sarana.ai','pic'),('Dhania','dhania@sarana.ai','pic'),('Keysa','keysa@sarana.ai','pic'),
 ('Tira','tira@sarana.ai','pic'),('Indira','indira@sarana.ai','lead'),
 ('Contoh Engineer 1','engineer1@sarana.ai','engineer'),('Contoh Engineer 2','engineer2@sarana.ai','engineer'),
 ('Contoh PM','pm@sarana.ai','pm'),('Contoh AM','am@sarana.ai','am');

UPDATE public.people pe SET user_id = pr.id FROM public.profiles pr WHERE lower(pr.email) = lower(pe.email);

ALTER TABLE public.projects ADD COLUMN pm text DEFAULT '';
ALTER TABLE public.tasks ADD COLUMN assignee_person uuid REFERENCES public.people(id) ON DELETE SET NULL;

CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_name text := coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1));
  v_first text := initcap(lower(split_part(v_name,' ',1)));
  v_pic text := null;
  v_role public.app_role := 'engineer';
  v_person public.people%rowtype;
begin
  if lower(coalesce(new.email,'')) not like '%@sarana.ai' then
    raise exception 'Hanya email @sarana.ai yang boleh masuk';
  end if;
  select * into v_person from public.people where lower(email) = lower(new.email) limit 1;
  if found then
    if v_person.title in ('pic','lead') then v_pic := v_person.name; v_role := 'pic'; end if;
    if v_person.title = 'lead' then v_role := 'lead'; end if;
  else
    if v_first in ('Faiz','Dhania','Keysa','Tira','Indira') then v_pic := v_first; v_role := 'pic'; end if;
    if v_first = 'Indira' then v_role := 'lead'; end if;
  end if;
  if v_first = 'Tsa' then v_role := 'admin'; end if;
  insert into public.profiles (id, name, email, pic_name) values (new.id, v_name, new.email, v_pic);
  insert into public.user_roles (user_id, role) values (new.id, v_role);
  if v_person.id is not null then
    update public.people set user_id = new.id where id = v_person.id;
  else
    insert into public.people (name, email, title, user_id) values (v_name, new.email, case when v_pic is not null then 'pic'::public.person_title else 'engineer' end, new.id) on conflict (email) do nothing;
  end if;
  return new;
end $function$;