
-- ENUMS
create type public.app_role as enum ('pic','engineer','lead','admin');
create type public.stage as enum ('Pipeline','POC','Go/No-Go','Development','UAT','Go-Live','Hypercare','On Hold','Closed-No Go');
create type public.health as enum ('Green','Yellow','Red');
create type public.ball as enum ('Sarana','Client');
create type public.task_type as enum ('Feature','Bug','Improvement','Chore');
create type public.task_prio as enum ('P1','P2','P3','P4');
create type public.task_status as enum ('To do','In progress','In review','Blocked','Done');

-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  email text not null default '',
  pic_name text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
grant select, insert, update, delete on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
create or replace function public.has_any_role(_user_id uuid, _roles public.app_role[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = any(_roles))
$$;

create policy "read profiles" on public.profiles for select to authenticated using (true);
create policy "update own or admin" on public.profiles for update to authenticated
  using (id = auth.uid() or public.has_role(auth.uid(),'admin'))
  with check (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "read roles" on public.user_roles for select to authenticated using (true);
create policy "admin insert roles" on public.user_roles for insert to authenticated with check (public.has_role(auth.uid(),'admin'));
create policy "admin update roles" on public.user_roles for update to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin delete roles" on public.user_roles for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_name text := coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1));
  v_first text := initcap(lower(split_part(v_name,' ',1)));
  v_pic text := null;
  v_role public.app_role := 'engineer';
begin
  if lower(coalesce(new.email,'')) not like '%@sarana.ai' then
    raise exception 'Hanya email @sarana.ai yang boleh masuk';
  end if;
  if v_first in ('Faiz','Dhania','Keysa','Tira','Indira') then v_pic := v_first; v_role := 'pic'; end if;
  if v_first = 'Indira' then v_role := 'lead'; end if;
  if v_first = 'Tsa' then v_role := 'admin'; end if;
  insert into public.profiles (id, name, email, pic_name) values (new.id, v_name, new.email, v_pic);
  insert into public.user_roles (user_id, role) values (new.id, v_role);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- CHECKLIST DEFINITIONS (server side copy for logs)
create or replace function public.checklist_items(_stage text)
returns text[] language sql immutable as $$
  select case _stage
    when 'Pipeline' then array['Lead qualified by AM (use case, sponsor, rough value)','PIC (DS) assigned','Use-case brief written','Potential ARR estimate filled in','POC proposal / deck with timeline sent','POC scope + success criteria agreed with client','Kickoff date set']
    when 'POC' then array['Kickoff held, notes stored','Data request sent to client','Client data / access received','Success criteria written and signed off','Funding requested (cash / credit)','Weekly POC status shared','POC delivered against success criteria','Go/No-Go meeting scheduled']
    when 'Go/No-Go' then array['POC demo / checkpoint completed','Go/No-Go meeting notes stored','Commercial proposal sent','SIGNED PoC sign-off / handoff doc received, verbal Go does not count']
    when 'Development' then array['Signed PoC sign-off linked','Production scope / PRD agreed','Quotation / PKS sent with owner and expected signing date','Infra decision, environments, access requested','Data / integrations list with client owners','Dev plan with milestones, UAT date, target go-live','Client stakeholder map + channel','POC code / prompts / configs in shared repo','Feature-complete build deployed to UAT environment','UAT plan agreed with client']
    when 'UAT' then array['UAT scenarios shared','UAT feedback log running','Client UAT sign-off','Go-live date confirmed in writing by client','Prod deployment plan ready']
    when 'Go-Live' then array['Production deployment done','Written go-live confirmation linked','Hypercare end date agreed and entered','Support channel, SLA, escalation contacts agreed','Known issues / issue log set up','User training / guide delivered','Prod release notes shared','Monitoring + billing start confirmed']
    when 'Hypercare' then array['Issue log maintained','End date reached, no open P1/P2','Closure note sent to client','Handover to CS / BAU with runbook','Enhancements logged as CR / upsell','Billing active and renewal date recorded','Removed from DS active load']
    when 'Handover' then array['Register updated with new PIC','Handover call held, Indira informed','New PIC introduced to client','All docs shared','Access transferred via vault','Open commitments listed','New PIC confirms handover complete']
    when 'On Hold' then array['Hold reason in Blocker','Who decided is recorded','Review date set']
    else array[]::text[] end
$$;

create or replace function public.empty_checklist()
returns jsonb language sql immutable as $$
  select jsonb_build_object(
    'Pipeline', to_jsonb(array_fill(false, array[7])),
    'POC', to_jsonb(array_fill(false, array[8])),
    'Go/No-Go', to_jsonb(array_fill(false, array[4])),
    'Development', to_jsonb(array_fill(false, array[10])),
    'UAT', to_jsonb(array_fill(false, array[5])),
    'Go-Live', to_jsonb(array_fill(false, array[8])),
    'Hypercare', to_jsonb(array_fill(false, array[7])))
$$;

-- PROJECTS
create or replace function public.next_project_id()
returns text language plpgsql volatile security definer set search_path = public as $$
declare n int;
begin
  perform pg_advisory_xact_lock(424242);
  select coalesce(max(nullif(regexp_replace(id,'\D','','g'),'')::int),0)+1 into n from public.projects;
  return 'DS-' || lpad(n::text, 3, '0');
end $$;

create table public.projects (
  id text primary key,
  client text not null,
  project text not null default '',
  product text default '',
  pic text not null,
  am text default '',
  stage public.stage not null default 'Pipeline',
  prev_stage public.stage,
  target_date date,
  health public.health,
  ball_in_court public.ball,
  blocker text default '',
  next_action text default '',
  next_action_owner text default '',
  next_action_due date,
  signoff_status text default '',
  potential_arr_idr_million numeric,
  source_gid text,
  checklist jsonb not null default public.empty_checklist(),
  handover_pp jsonb default '[false,false,false,false,false,false,false]',
  handover_active boolean default false,
  hold_checklist jsonb default '[false,false,false]',
  last_updated date,
  last_updated_by uuid,
  created_at timestamptz default now()
);
alter table public.projects alter column id set default public.next_project_id();
grant select, insert, update on public.projects to authenticated;
grant all on public.projects to service_role;
alter table public.projects enable row level security;
create policy "read projects" on public.projects for select to authenticated using (true);
create policy "pic insert projects" on public.projects for insert to authenticated with check (public.has_any_role(auth.uid(), array['pic','lead','admin']::public.app_role[]));
create policy "pic update projects" on public.projects for update to authenticated using (public.has_any_role(auth.uid(), array['pic','lead','admin']::public.app_role[]));

create or replace function public.peek_project_id()
returns text language plpgsql stable security definer set search_path = public as $$
declare n int;
begin
  select coalesce(max(nullif(regexp_replace(id,'\D','','g'),'')::int),0)+1 into n from public.projects;
  return 'DS-' || lpad(n::text, 3, '0');
end $$;

-- ACTIVITY
create table public.activity (
  id uuid primary key default gen_random_uuid(),
  project_id text not null references public.projects(id) on delete cascade,
  at timestamptz not null default now(),
  by uuid,
  kind text not null default 'update',
  text text not null default ''
);
create index on public.activity (project_id, at desc);
create index on public.activity (at desc);
grant select, insert on public.activity to authenticated;
grant all on public.activity to service_role;
alter table public.activity enable row level security;
create policy "read activity" on public.activity for select to authenticated using (true);
create policy "insert own notes" on public.activity for insert to authenticated with check (by = auth.uid());

-- project trigger: guards + diff log
create or replace function public.projects_log()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  parts text[] := '{}';
  kind text := 'update';
  st text; items text[]; i int; o jsonb; n jsonb;
  fmt_d text;
begin
  if tg_op = 'INSERT' then
    insert into public.activity(project_id, by, kind, text) values (new.id, auth.uid(), 'update', 'Proyek dibuat');
    return new;
  end if;

  if new.stage = 'Closed-No Go' and old.stage <> 'Closed-No Go'
     and auth.uid() is not null and not public.has_any_role(auth.uid(), array['lead','admin']::public.app_role[]) then
    raise exception 'Cuma lead yang bisa tutup No Go';
  end if;

  if new.stage is distinct from old.stage then
    parts := parts || format('Stage: %s → %s', old.stage, new.stage); kind := 'stage';
  end if;
  if new.pic is distinct from old.pic then parts := parts || format('PIC: %s → %s', old.pic, new.pic); end if;
  if new.health is distinct from old.health then parts := parts || format('Health: %s → %s', coalesce(old.health::text,'kosong'), coalesce(new.health::text,'kosong')); end if;
  if new.ball_in_court is distinct from old.ball_in_court then parts := parts || format('Bola: %s → %s', coalesce(old.ball_in_court::text,'kosong'), coalesce(new.ball_in_court::text,'kosong')); end if;
  if new.target_date is distinct from old.target_date then parts := parts || format('Target: %s → %s', coalesce(to_char(old.target_date,'DD Mon YYYY'),'kosong'), coalesce(to_char(new.target_date,'DD Mon YYYY'),'kosong')); end if;
  if new.next_action is distinct from old.next_action then parts := parts || 'Next action diubah'::text; end if;
  if new.next_action_owner is distinct from old.next_action_owner then parts := parts || format('Owner: %s → %s', coalesce(nullif(old.next_action_owner,''),'kosong'), coalesce(nullif(new.next_action_owner,''),'kosong')); end if;
  if new.next_action_due is distinct from old.next_action_due then parts := parts || format('Due: %s → %s', coalesce(to_char(old.next_action_due,'DD Mon'),'kosong'), coalesce(to_char(new.next_action_due,'DD Mon'),'kosong')); end if;
  if new.blocker is distinct from old.blocker then parts := parts || (case when coalesce(new.blocker,'')='' then 'Blocker dihapus' else 'Blocker diubah' end); end if;
  if new.signoff_status is distinct from old.signoff_status then parts := parts || 'Sign-off diubah'::text; end if;
  if new.potential_arr_idr_million is distinct from old.potential_arr_idr_million then parts := parts || format('ARR: %s → %s', coalesce(old.potential_arr_idr_million::text,'kosong'), coalesce(new.potential_arr_idr_million::text,'kosong')); end if;
  if new.client is distinct from old.client then parts := parts || format('Client: %s → %s', old.client, new.client); end if;
  if new.project is distinct from old.project then parts := parts || 'Use case diubah'::text; end if;
  if new.product is distinct from old.product then parts := parts || 'Produk diubah'::text; end if;
  if new.am is distinct from old.am then parts := parts || format('AM: %s → %s', coalesce(nullif(old.am,''),'kosong'), coalesce(nullif(new.am,''),'kosong')); end if;

  if new.checklist is distinct from old.checklist then
    foreach st in array array['Pipeline','POC','Go/No-Go','Development','UAT','Go-Live','Hypercare'] loop
      items := public.checklist_items(st);
      for i in 1..coalesce(array_length(items,1),0) loop
        o := old.checklist->st->(i-1); n := new.checklist->st->(i-1);
        if coalesce(o,'false'::jsonb) is distinct from coalesce(n,'false'::jsonb) then
          parts := parts || (case when n = 'true'::jsonb then '✓ ' else '✗ ' end || st || ': ' || items[i]);
          if kind = 'update' then kind := 'check'; end if;
        end if;
      end loop;
    end loop;
  end if;
  if new.handover_pp is distinct from old.handover_pp and new.pic is not distinct from old.pic then
    items := public.checklist_items('Handover');
    for i in 1..7 loop
      if coalesce(old.handover_pp->(i-1),'false') is distinct from coalesce(new.handover_pp->(i-1),'false') then
        parts := parts || (case when new.handover_pp->(i-1) = 'true'::jsonb then '✓ ' else '✗ ' end || 'Handover: ' || items[i]);
        if kind = 'update' then kind := 'check'; end if;
      end if;
    end loop;
  end if;
  if new.hold_checklist is distinct from old.hold_checklist then
    items := public.checklist_items('On Hold');
    for i in 1..3 loop
      if coalesce(old.hold_checklist->(i-1),'false') is distinct from coalesce(new.hold_checklist->(i-1),'false') then
        parts := parts || (case when new.hold_checklist->(i-1) = 'true'::jsonb then '✓ ' else '✗ ' end || 'On Hold: ' || items[i]);
        if kind = 'update' then kind := 'check'; end if;
      end if;
    end loop;
  end if;

  if array_length(parts,1) is null then
    if new.last_updated is distinct from old.last_updated then
      parts := array['Dicek, tidak ada perubahan'];
    else
      return new;
    end if;
  end if;
  insert into public.activity(project_id, by, kind, text) values (new.id, auth.uid(), kind, array_to_string(parts, '; '));
  return new;
end $$;
create trigger projects_log_ins after insert on public.projects for each row execute function public.projects_log();
create trigger projects_log_upd before update on public.projects for each row execute function public.projects_log();

-- TODOS
create table public.todos (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null default auth.uid(),
  date date not null default (now() at time zone 'Asia/Jakarta')::date,
  text text not null,
  project_id text references public.projects(id) on delete set null,
  done boolean not null default false,
  done_at timestamptz,
  sort_order int not null default 0,
  carried_count int not null default 0,
  created_at timestamptz not null default now()
);
create index on public.todos (owner, date);
grant select, insert, update, delete on public.todos to authenticated;
grant all on public.todos to service_role;
alter table public.todos enable row level security;
create policy "read todos" on public.todos for select to authenticated using (true);
create policy "own insert todos" on public.todos for insert to authenticated with check (owner = auth.uid());
create policy "own update todos" on public.todos for update to authenticated using (owner = auth.uid());
create policy "own delete todos" on public.todos for delete to authenticated using (owner = auth.uid());

create or replace function public.todos_log()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.done and not old.done then
    new.done_at := now();
    if new.project_id is not null then
      insert into public.activity(project_id, by, kind, text) values (new.project_id, auth.uid(), 'update', 'Prioritas selesai: ' || new.text);
    end if;
  elsif not new.done and old.done then
    new.done_at := null;
  end if;
  return new;
end $$;
create trigger todos_log before update on public.todos for each row execute function public.todos_log();

-- TASKS
create sequence public.task_key_seq start 101;
grant usage on sequence public.task_key_seq to authenticated, service_role;
create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  key text unique not null default ('T-' || nextval('public.task_key_seq')),
  project_id text not null references public.projects(id) on delete cascade,
  title text not null,
  description text not null default '',
  type public.task_type not null default 'Feature',
  prio public.task_prio not null default 'P3',
  status public.task_status not null default 'To do',
  assignee uuid references public.profiles(id) on delete set null,
  reporter uuid references public.profiles(id) on delete set null default auth.uid(),
  estimate_hours numeric,
  due date,
  sort_order double precision not null default extract(epoch from now()),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  done_at timestamptz
);
grant select, insert, update, delete on public.tasks to authenticated;
grant all on public.tasks to service_role;
alter table public.tasks enable row level security;
create policy "read tasks" on public.tasks for select to authenticated using (true);
create policy "insert tasks" on public.tasks for insert to authenticated with check (auth.uid() is not null);
create policy "update tasks" on public.tasks for update to authenticated using (auth.uid() is not null);
create policy "delete tasks" on public.tasks for delete to authenticated using (auth.uid() is not null);

create table public.task_comments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  at timestamptz not null default now(),
  by uuid,
  kind text not null default 'comment',
  text text not null
);
create index on public.task_comments (task_id, at);
grant select, insert on public.task_comments to authenticated;
grant all on public.task_comments to service_role;
alter table public.task_comments enable row level security;
create policy "read comments" on public.task_comments for select to authenticated using (true);
create policy "insert own comments" on public.task_comments for insert to authenticated with check (by = auth.uid() and kind = 'comment');

create or replace function public.pname(_id uuid) returns text language sql stable security definer set search_path = public as $$
  select coalesce((select name from public.profiles where id = _id), 'Belum di-assign')
$$;

create or replace function public.tasks_log()
returns trigger language plpgsql security definer set search_path = public as $$
declare parts text[] := '{}'; p text;
begin
  if tg_op = 'INSERT' then
    insert into public.task_comments(task_id, by, kind, text) values (new.id, auth.uid(), 'log', 'Task dibuat');
    insert into public.activity(project_id, by, kind, text) values (new.project_id, auth.uid(), 'update', format('Task %s dibuat: %s', new.key, new.title));
    if new.status = 'Done' then update public.tasks set done_at = now() where id = new.id; end if;
    return new;
  end if;
  if new.title is distinct from old.title then parts := parts || format('Judul: %s → %s', old.title, new.title); end if;
  if new.description is distinct from old.description then parts := parts || 'Deskripsi diubah'::text; end if;
  if new.type is distinct from old.type then parts := parts || format('Type: %s → %s', old.type, new.type); end if;
  if new.prio is distinct from old.prio then parts := parts || format('Prioritas: %s → %s', old.prio, new.prio); end if;
  if new.status is distinct from old.status then parts := parts || format('Status: %s → %s', old.status, new.status); end if;
  if new.assignee is distinct from old.assignee then parts := parts || format('Engineer: %s → %s', public.pname(old.assignee), public.pname(new.assignee)); end if;
  if new.project_id is distinct from old.project_id then parts := parts || format('Proyek: %s → %s', old.project_id, new.project_id); end if;
  if new.estimate_hours is distinct from old.estimate_hours then parts := parts || format('Estimasi: %s → %s', coalesce(old.estimate_hours::text,'kosong'), coalesce(new.estimate_hours::text,'kosong')); end if;
  if new.due is distinct from old.due then parts := parts || format('Due: %s → %s', coalesce(to_char(old.due,'DD Mon'),'kosong'), coalesce(to_char(new.due,'DD Mon'),'kosong')); end if;
  if array_length(parts,1) is null then return new; end if;
  new.updated_at := now();
  foreach p in array parts loop
    insert into public.task_comments(task_id, by, kind, text) values (new.id, auth.uid(), 'log', p);
  end loop;
  if new.status = 'Done' and old.status <> 'Done' then
    new.done_at := now();
    insert into public.activity(project_id, by, kind, text) values (new.project_id, auth.uid(), 'update', format('Task %s selesai: %s', new.key, new.title));
  elsif new.status <> 'Done' then
    new.done_at := null;
  end if;
  return new;
end $$;
create trigger tasks_log_ins after insert on public.tasks for each row execute function public.tasks_log();
create trigger tasks_log_upd before update on public.tasks for each row execute function public.tasks_log();

-- REALTIME
alter publication supabase_realtime add table public.projects, public.activity, public.todos, public.tasks, public.task_comments, public.profiles;
