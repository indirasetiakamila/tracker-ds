CREATE INDEX IF NOT EXISTS projects_stage_idx ON public.projects (stage);
CREATE INDEX IF NOT EXISTS projects_health_idx ON public.projects (health);
CREATE INDEX IF NOT EXISTS projects_pic_idx ON public.projects (pic);
CREATE INDEX IF NOT EXISTS projects_client_idx ON public.projects (client);
CREATE INDEX IF NOT EXISTS tasks_project_status_idx ON public.tasks (project_id, status);
CREATE INDEX IF NOT EXISTS tasks_assignee_person_idx ON public.tasks (assignee_person);
CREATE INDEX IF NOT EXISTS tasks_updated_idx ON public.tasks (updated_at DESC);