# UI lebih cantik + tambah orang langsung dari dropdown

## Jawaban: tambah orang di mana?
Sekarang sudah bisa di **Admin > tab Tim** (khusus admin). Supaya lebih gampang, kita tambah juga:
- Tombol **"+ Tambah orang"** di bawah setiap dropdown orang (PIC, AM, PM, engineer, owner). Klik, isi nama, email (opsional) dan jabatan, langsung tersimpan dan langsung terpilih. Hanya muncul untuk admin; yang lain lihat tulisan "Minta admin tambahkan".
- Link **Tim** di menu samping/atas untuk admin, langsung ke tab Tim.

## UI lebih aesthetic + ikon
- Ikon di semua menu navigasi (Minggu ini, Board, Register, Standup, Prioritas, Tasks, Report, Admin).
- Judul halaman dapat ikon dalam lingkaran wine lembut + subjudul.
- Kartu statistik/ringkasan dengan ikon (proyek aktif, merah, overdue, task terbuka).
- Pill status, stage, prioritas dan tipe task dapat ikon kecil (centang, segitiga peringatan, bug, sparkles, dll).
- Dropdown orang tampil dengan avatar inisial berwarna + badge jabatan.
- Empty state dengan ikon besar dan ajakan aksi.
- Kartu proyek: ikon untuk PIC, AM, deadline, progres; hover lebih halus.
- Tombol utama dengan ikon (Proyek baru, Task baru, Simpan).
- Tabel lebih lega: header lembut, baris berselang, hover highlight.
- Palet IK, font, dan warna status tetap sama.

## Technical details
- lucide-react icons; extend `PageHeader` with `icon` prop, add `StatCard`, icons in `HealthPill/StagePill/TypeBadge/PrioBadge`, `Empty` with icon + action.
- `PersonSelect`: footer `CommandItem` "Tambah orang" opening a Dialog (name, email @sarana.ai validation, title defaulted from `titles[0]`); insert into `people`, invalidate `qk.people`, call `onChange` with new value. Gated by `useMe().isAdmin` (RLS already admin-only writes).
- AppShell nav items get icons; admin link to `/admin`.
- No database changes.
