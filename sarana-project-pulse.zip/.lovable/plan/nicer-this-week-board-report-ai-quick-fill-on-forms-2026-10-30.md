# Nicer This Week / Board / Report + AI Quick fill on forms

## 1. AI Quick fill (New project, New task, weekly update)
- A "Quick fill with AI" panel at the top of each form: a big box where you paste anything (notes from Claude, a chat, meeting notes, an email) in English or Bahasa.
- Click **Fill form**: the AI reads it and fills the fields (client, use case, PIC, AM, PM, stage, next action, due date, ARR; for tasks: title, project, engineer, type, priority, estimate, due, description with Context / Work required / Acceptance criteria).
- People and projects are matched to the existing Team list and register; unknown names are left blank and flagged instead of invented.
- Filled fields get a soft blue "AI" highlight until you touch them, plus a short note of what was filled and what's missing. Nothing saves until you press Create.
- Dates understood relative to WIB ("next Friday", "end of month").
- Loading state: dot-logo shimmer over the form while it works; clear error message if it fails.
- Also on the project page weekly update (health, next action, blocker) so a pasted status dump becomes the update.

## 2. This Week refresh
- Hero banner: greeting + big progress ring + "X of Y updated" with a short line like "3 left before Friday 17:00", countdown chip to deadline.
- Summary strip: Need update, At risk (Red), Due this week, Updated, as compact stat tiles with icons and click-to-filter.
- Project cards grouped "Needs your update" first, then "Done this week", with collapsible sections, clearer health stripe, last-updated time, next action preview and one-click "Update" button.

## 3. Board refresh
- Column headers with stage icon, count, colored progress bar and total ARR per stage.
- Cards: client logo, health dot, PIC avatar, next action due chip (red if overdue), days in stage.
- Drag cards between stages (asks to confirm the checklist when needed), sticky column headers, horizontal scroll with fade edges, empty columns show a small illustration.
- Quick filters: PIC (existing), plus Health and "Only mine".

## 4. Report refresh
- Top KPI tiles: active projects, total pipeline ARR, % updated this week, Red count, open tasks.
- Charts: projects by stage (bar), health mix (donut), weekly update rate trend (last 8 weeks line), ARR by PIC.
- "Needs attention" list (Red / overdue next actions / stale > 14 days).
- Export CSV stays; add a period selector (this week / last 4 weeks / quarter).

## Technical details
- New `src/lib/ai-fill.functions.ts`: `createServerFn` with `requireSupabaseAuth`, input `{ kind: "project" | "task" | "update", text, context }`; server passes people list, project list, stages, enums, today (WIB) to `openai/gpt-6-astra` via AI SDK Responses (`streamText`, strict JSON schema output, reasoning low, store false), consumed server-side, returns a validated DTO. Gateway errors (402/429/403) mapped to friendly messages.
- Shared `QuickFill` component (textarea, button, result summary) used in `proyek.baru.tsx`, `tasks.baru.tsx`, and the project update form; merges into existing local form state, tracks `aiFilled` keys for highlight. Description/next action returned as simple HTML for the rich text editor.
- Board drag via `@dnd-kit/core`, stage change goes through existing `updateProject` + rules validation in `rules.ts`.
- Report charts with `recharts` (shadcn chart wrapper), all metrics derived through pure functions added to `rules.ts` with tests.
- Verify: run AI fill end to end with a sample dump in the browser, check fields populate; screenshot the three pages.
