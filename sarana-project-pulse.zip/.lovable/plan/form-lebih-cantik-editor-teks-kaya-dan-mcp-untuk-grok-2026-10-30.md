# Form lebih cantik, editor teks kaya, dan MCP untuk Grok

## 1. Form Proyek baru & Task baru dibuat ulang
- Form dibagi jadi beberapa bagian bertema dengan judul kecil + ikon: "Siapa & apa" (Client, Use case, Produk), "Tim" (PIC, AM, PM / Engineer), "Langkah berikutnya" (Next action, Due), "Detail" (Stage, kickoff, ARR / Type, Prioritas, Status, Estimasi).
- Kolom samping (desktop): kartu ringkasan live yang menampilkan preview proyek/task saat diisi, plus ilustrasi kecil dan tips.
- Pilihan Stage, Type, Prioritas, Status jadi chip/pill yang bisa diklik (dengan ikon dan warna status), bukan dropdown biasa.
- Input: ikon di dalam field, placeholder lebih jelas, label lebih halus, field ARR dengan awalan "Rp" dan akhiran "juta", estimasi dengan tombol +/-.
- Tombol simpan menempel di bawah (sticky) dengan tombol Batal, animasi masuk per bagian.
- Pola yang sama dipakai di form edit pada halaman detail proyek dan detail task.

## 2. Next action & Deskripsi pakai editor teks kaya
- Editor ringan dengan toolbar: Bold, Italic, Underline, Highlight, Heading 1/2, bullet & numbered list, checklist, quote, kode, link.
- Shortcut keyboard (Ctrl+B dll) dan markdown cepat (ketik `## `, `- `, `[] `).
- Template deskripsi task (Konteks / Yang harus dikerjakan / Selesai kalau) jadi heading beneran.
- Tampilan teks kaya juga dirender di kartu, detail proyek/task, Standup, dan Report. Teks lama tetap tampil normal.

## 3. MCP server supaya Grok bisa bantu isi data
- Grok (atau asisten lain yang mendukung MCP) disambungkan ke app, login dengan akun Google @sarana.ai, dan bertindak sebagai user tersebut (aturan akses yang sama dengan di app).
- Tools awal:
  - `list_projects`, `get_project` (baca register)
  - `create_project`, `update_project_weekly` (isi update mingguan: health, next action, due, stage)
  - `list_tasks`, `create_task`, `update_task_status`
  - `list_people` (supaya Grok tahu nama PIC/engineer yang valid)
- Tidak ada tool hapus.
- Setelah app di-publish, alamat MCP dimasukkan ke Grok sebagai remote MCP.

## Detail teknis
- Editor: Tiptap (StarterKit + Highlight + Underline + TaskList + Link + Placeholder), simpan sebagai HTML di kolom text yang sudah ada; renderer aman (sanitize) dan fallback plain text untuk data lama. Komponen `RichTextEditor` + `RichText` di `src/components/app/`.
- Form: komponen bersama `FormSection`, `ChipSelect`, `IconInput` di `bits.tsx`; validasi tetap lewat `src/lib/rules.ts`.
- MCP: `@lovable.dev/mcp-js` + `mcpPlugin()` di `vite.config.ts`, tools di `src/lib/mcp/tools/*`, OAuth server diaktifkan, client database per user (RLS tetap berlaku), plus halaman consent. Tools browser (WebMCP) untuk halaman form juga ditambahkan. Manifest di-extract setelah selesai.
- Ditambahkan ke AGENTS.md: aturan rich text disimpan sebagai HTML ter-sanitize.
