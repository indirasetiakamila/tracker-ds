# Restyle to the "Legency" look

Replace the current wine/plum/cream editorial look with the crisp, bold, electric-blue style from the reference. Layout, pages, data and features stay the same.

## New visual direction
- **Colors:** light gray canvas (#F2F2F2), white panels, near-black ink (#0A0A0A), one electric blue accent (#1414F0) for buttons, links, active states and highlighted words. Black panels for featured stats. Status pills keep green/amber/red.
- **Type:** tight, heavy geometric sans for headings (Inter Tight / "Instrument Sans" style, bold, negative letter spacing), clean sans body. Small uppercase spaced labels ("TRACK RECORD" style) for section eyebrows.
- **Shapes:** small radius (8-10px) instead of soft rounded pills, thin 1px light borders, almost no shadows, flat fills.
- **Signature graphic:** blue pixel/dot-halftone pattern (CSS/SVG generated) used in page headers, sign-in screen and empty states, replacing the painted illustrations.
- **Headings:** last words of page titles in blue (e.g. "This **Week**").
- **Buttons:** solid blue rectangle with a separate square arrow tile (like "Get in touch ↘"); secondary buttons white with border.
- **Nav:** white top bar card with logo left and "Menu" right on mobile; desktop sidebar becomes white with blue active indicator.
- **Stat cards:** black card variant with uppercase label and large white number.
- Motion kept but calmer: fade/slide in, pixel pattern subtly animates; tilt, confetti stay (confetti recolored blue/black).

## Technical details
- Rewrite tokens in `src/styles.css` (background, card, primary, accent, radius, shadows, fonts) and swap font links in `__root.tsx`.
- Update shadcn `button`, `card`, inputs to flat variants; add `ArrowButton` and `PixelField` components in `bits.tsx`/`fun.tsx`.
- Update `PageHeader`, `AppShell`, `ProjectCard`, stat cards, auth and 404 pages to the new style; remove the cream gradient and tilt-heavy card styles.
- Update `mem://index.md` Core design rule to the new look (replacing the IK style rule).
