# Sarana DS Project Register: full build (Prompts 1 to 6)

Internal app for the Sarana Delivery team, replacing the Excel register. UI copy is casual Bahasa Indonesia with no em or en dashes. The brand is Sarana throughout.

## Decisions
- Sign-in: Google only, limited to @sarana.ai. New users start as engineer, and Tsa (admin) assigns roles.
- Data: you will upload seed_projects.sql with the 52 projects. The tables will match that file. The app shows helpful empty states until the file is loaded.
- Reminder emails (Friday and Monday): skipped for now.
- Everything is built in one pass.

## Pages
1. **Minggu ini** (home): my weekly check. Shows a progress ring, hours left until Friday 17:00 WIB, and three groups: Perlu update, Cek cepat, Sudah dicek. Each card has a "Masih sama" button.
2. **Board**: stage columns that scroll sideways, PIC filter, red border on cards that need standup.
3. **Register**: full table with search, PIC filter, chips (Aktif, Standup, Red, Belum dicek, Closed), sortable headers, total ARR, link to the Google Sheet source, "Unduh CSV", and "+ Proyek baru".
4. **Proyek detail**: header with PIC change, which triggers the handover checklist. Also:
   - Progress stepper and checklists for each stage, with gate items
   - Naik stage, On Hold and Tutup No Go
   - Weekly status form with validation
   - History timeline and notes
   - Engineering tasks card
5. **Proyek baru**: auto-generated DS-xxx ID and required fields.
6. **Standup**: agenda sorted by severity, a table per PIC, a live activity feed, and a full-screen focus mode with "Simpan & lanjut".
7. **Prioritas**: daily to-dos.
   - Saya: add items, warning above 5 items, carry-over from the last 14 days, suggestions from my projects, 7-day bars
   - Tim: everyone's items for today
8. **Engineering tasks**: Jira-style board with drag and drop, plus a list view, filters and header counts.
   - Task detail with inline editing, comments and an automatic change log
   - New task form with a description template
9. **Report**: three period options with KPIs, stage distribution, stage moves, Red list, a table per PIC, completed priorities, and "Salin ringkasan" for WhatsApp.
10. **Admin** (admin only): change each person's role and PIC name.

Sidebar badges: my unchecked projects, standup count, my open priorities today, and blocked tasks. A live sync indicator and the user name sit at the bottom of the sidebar.

## Design
Helvetica Neue font. Colors: blue #3978EB, navy #14284B for the sidebar and headings, amber #F2A900, red #C93C3C, green #1C8F62, background #F3F5F9, borders #DCE3EF. Dark mode is supported. On mobile at 400px, the sidebar becomes a top bar with nav that scrolls sideways, and the page never scrolls sideways. Statuses always show as pills, dots or borders. A toast confirms every save.

## Technical details
- Lovable Cloud tables: profiles, user_roles (roles kept in a separate table and checked with has_role), projects, activity, todos, tasks, task_comments.
  - Enums: stage, health, ball, task type, prio and status
  - Grants and RLS: everyone signed in can read. Writes follow the roles: pic/lead/admin edit projects; engineers edit tasks; only the owner writes their todos; lead closes No Go; admin manages roles.
- The profiles table has pic_name. The column names will match seed_projects.sql once it arrives.
- DS-xxx IDs come from a sequence-backed function. Task keys use T-101 and up.
- Activity history is written by database triggers on projects and tasks. Triggers produce the readable Indonesian diff and the task_comments log rows, plus project activity when a task is created or finished.
- Realtime is on for projects, activity, todos, tasks and task_comments. Updates merge without wiping text someone is typing.
- `src/lib/rules.ts` holds the shared logic as pure functions, with unit tests:
  - stages, base percentages and checklists
  - progress, itemsBehind, checkedThisWeek, daysOverdue, stale and needsStandup
  - "Masih sama" and save validation
  - date logic in WIB, with weeks starting Monday
- Google sign-in goes through the managed broker, with the domain checked after login. Pages live under the signed-in area, with /auth as the public sign-in page.
- Task board drag and drop uses @dnd-kit with optimistic updates and rollback on error.
- The CSV export includes a UTF-8 BOM so Excel opens it correctly.
- Not included: the Resend scheduled emails.
