# Daftar orang + tampilan ala IK

## 1. Daftar orang (Tim)
Satu daftar orang yang dipakai semua dropdown. Isinya nama, email, jabatan (Engineer, PM, AM, PIC, Lead), dan status aktif.

- Admin bisa nambah orang manual walau dia belum pernah login. Begitu orang itu login pakai email @sarana.ai yang sama, datanya otomatis nyambung ke akunnya.
- Halaman Admin jadi dua tab: **Tim** (tambah, edit, nonaktifkan orang, pilih jabatan) dan **Akses** (role login seperti sekarang).
- Data awal: 5 PIC (Faiz, Dhania, Keysa, Tira, Indira) plus contoh engineer, PM dan AM yang nanti kamu ganti dengan nama asli.

Dropdown baru (bisa diketik untuk cari):
- **PIC proyek**: hanya orang dengan jabatan PIC/Lead (di Proyek baru, ganti PIC di detail, filter Board/Register).
- **AM / PM proyek**: orang dengan jabatan AM atau PM.
- **Engineer di task**: orang dengan jabatan Engineer (task baru, detail task, filter task).
- **Next action owner**: semua orang aktif.

Nilai lama yang berupa teks tetap tampil; begitu diedit, tinggal pilih dari daftar.

## 2. Tampilan ikut penuh gaya IK
- Warna: wine #5D1E33, plum #351E28, powder blue #B7D1EA, latar biru pucat dengan sorotan lembut, kartu krem.
- Font: judul serif Cormorant, teks tetap rapi.
- Kartu sudut bulat besar dengan bayangan lembut, naik sedikit saat disentuh kursor, muncul dengan animasi.
- Navigasi pill dengan sorotan yang bergeser halus ke menu aktif. Header gradasi plum.
- Pill status (Green/Yellow/Red, stage, prio) tetap jelas dibaca di palet baru. Mode gelap ikut disesuaikan.
- Berlaku untuk semua 10 halaman.

## Technical details
- New table `people` (id, name, email unique, title enum `person_title`: engineer/pm/am/pic/lead, active, user_id nullable -> profiles). GRANT authenticated/service_role, RLS: read all signed-in, write admin only via has_role. Trigger in `handle_new_user` links by email. Seed rows in the same migration.
- New columns (additive, nullable): `projects.pic_person`, `am_person`, `pm_person`, `next_action_owner_person` (uuid -> people). Backfill pic_person from `pic` text by name. Keep old text columns; `pic` stays filled from person name for rules/standup compatibility. Tasks keep `assignee` (profiles) plus new `assignee_person` -> people, backfilled where user_id matches.
- `usePeople()` hook in data.ts + realtime map entry; reusable `PersonSelect` (Command + Popover combobox) filtered by title.
- Port IK tokens (styles.css), Cormorant link in __root, `shadow-card/lift`, `bg-ink-gradient`; add framer-motion for cards and nav pill. Update bits.tsx pills, AppShell, ProjectCard.
- Update memory: new palette/fonts replace the old ones. Update rules tests if PIC lists move from constant to data.
