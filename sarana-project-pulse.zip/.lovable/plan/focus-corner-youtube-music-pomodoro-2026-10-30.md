# Focus corner: YouTube music + Pomodoro

## What you get
- A small **Focus** button at the bottom-right of every page. Click it to open a compact floating panel; click again to tuck it away (music keeps playing).
- **Music (YouTube)**
  - Paste any YouTube video or playlist link (e.g. a lofi stream) and it plays inside the panel.
  - A few ready-made picks: Lofi Girl, Jazz, Rain sounds, Classical.
  - Play/pause, mute, and hide the video so only the controls show.
  - Your last link is remembered on this browser.
- **Pomodoro**
  - Big countdown ring in blue: Focus 25 min, Short break 5 min, Long break 15 min after every 4 focus rounds.
  - Start / Pause / Reset / Skip, with round dots (1 of 4).
  - Lengths adjustable in a small settings popover.
  - Soft chime and browser notification when a round ends; the tab title shows the time left (e.g. "18:42 Focus").
  - Optional: music pauses automatically during breaks.
- Keeps running while you move between pages (it lives in the app frame, not a single page).
- Matches the current look: white panel, blue accent, Noto Sans, small "x" corner pattern.

## Technical details
- New `src/components/app/FocusDock.tsx`, mounted once in `AppShell` so navigation never remounts it.
- YouTube via the IFrame Player API on `youtube-nocookie.com`, loaded lazily on first open (client-only, no SSR import). Parse video id / `list=` playlist from pasted URLs; reject other hosts.
- Timer state is driven by an end timestamp (not a ticking counter) so it stays accurate when the tab is in the background; state and settings saved in localStorage, read after hydration.
- Pure helpers `parseYouTubeUrl` and `nextPhase` in `src/lib/focus.ts` with small tests (link parsing, 4th focus round leads to long break).
- No database changes; personal per browser.
