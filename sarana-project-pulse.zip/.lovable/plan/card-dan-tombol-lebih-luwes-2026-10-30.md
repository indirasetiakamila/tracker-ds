# Card dan tombol lebih luwes

## Tombol
- Bentuk pill bulat penuh, huruf sedikit lebih tebal.
- Tombol utama: gradasi wine lembut dengan kilau tipis, bayangan berwarna wine, naik sedikit saat disentuh kursor, "membal" kecil saat diklik.
- Tombol outline: latar krem transparan dengan garis lembut, saat disentuh berubah ke powder blue.
- Tombol sekunder: powder blue lembut, bukan abu-abu.
- Ikon di tombol bergeser/berputar kecil saat disentuh (panah maju, plus berputar).
- Fokus keyboard: cincin lembut warna powder, bukan garis tajam.

## Card
- Sudut lebih membulat dan tidak seragam (satu sudut lebih besar), border hampir hilang, diganti bayangan berlapis yang lembut.
- Latar krem dengan gradasi tipis dari atas, plus tekstur grain halus.
- Saat disentuh kursor: naik, sedikit miring halus mengikuti posisi kursor, bayangan makin dalam.
- Garis aksen warna di tepi kiri sesuai status (hijau/kuning/merah) diganti jadi pita lembut melengkung, bukan garis tegas.
- Isi card lebih lega: jarak antar baris ditambah, label kecil pakai huruf kapital tipis.
- Berlaku untuk card proyek, card task di Board, kartu ringkasan, dan semua panel di halaman detail, Register, Report, Admin.

## Input dan dropdown
- Kolom isian dan dropdown ikut membulat dan lembut supaya serasi dengan tombol.

## Technical details
- Update `buttonVariants` in `src/components/ui/button.tsx`: rounded-full, gradient default variant via new `--gradient-primary` token, `active:scale-[0.97]`, `hover:-translate-y-0.5`, `shadow-soft` token, icon nudge via `group` + `[&_svg]` transitions.
- Update `src/components/ui/card.tsx` base classes; add `@utility card-soft` in styles.css (gradient bg, layered shadow, asymmetric radius, grain) and apply to ProjectCard, StatCard, task cards, and panel wrappers in routes.
- Small `TiltCard` wrapper (framer-motion, mouse-based rotateX/Y up to 3deg, disabled for reduced motion and touch).
- Soften `input`, `select`, `textarea`, `popover` radii and focus rings.
- Frontend only, no data changes.
