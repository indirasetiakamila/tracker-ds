# Fonts check + big dotted Sarana logo on the sign-in page

## Fonts
- Already Noto Sans everywhere: body, headings, buttons, forms (one font file, weights 400 to 900).
- Only exception: task keys (e.g. ENG-12) and code snippets in the text editor use the system monospace font. Switch them to Noto Sans Mono so the whole app is one family.

## Sign-in page logo
- Remove the dotted background block behind the headline (your screenshot shows the older x pattern, so it may also be a stale preview).
- Place the dotted Sarana logo as a large decorative element: roughly 520px, anchored bottom-right of the left side and partly cropped off the edge, so it reads as an ornament, not a full image.
- Headline stays clean on plain background with no overlap; logo at about 70% strength with its soft blur-in on load.
- Page headers keep the small faded logo in the corner, moved a bit further right so it sits clear of the action button.

## Technical details
- `__root.tsx`: add `Noto+Sans+Mono:wght@400;600` to the Google Fonts link; `styles.css`: `--font-mono: "Noto Sans Mono", ui-monospace, monospace`.
- `auth.tsx`: replace the full-height `SaranaDots` with `absolute -bottom-24 -right-28 h-[520px] w-auto` decorative placement.
- `bits.tsx` / `minggu-ini.tsx`: shift header dots to `-right-16`.
- Verify with a screenshot of `/auth` and `/tasks`.
