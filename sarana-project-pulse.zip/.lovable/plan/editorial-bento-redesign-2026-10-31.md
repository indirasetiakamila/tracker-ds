# Editorial bento redesign

Keep the near-white canvas, white panels and electric blue accent. Change the type and the page layouts so the app feels hand-crafted, not template-made.

## 1. Typography
- Headings: **Cormorant Garamond**, large, with italic for emphasis (e.g. "This *week*", "Engineering *tasks*"). The italic word replaces the current blue last word, and stays dark ink, with blue reserved for actions.
- Body, labels, tables, forms: **Karla** (replaces Noto Sans).
- Numbers in stat tiles: Cormorant, big and light, tabular.
- Small uppercase eyebrow labels (Karla, letter-spaced) above section titles.

## 2. Bento layouts
Replace the uniform card grids with varied tile sizes on the main pages:
- **This Week:** large tile (week progress + deadline countdown), tall tile (Needs update list), small tiles (Red, Due this week, Checked), wide tile (project list).
- **Board:** a bento summary row on top (stage distribution, health mix, ARR), columns below.
- **Report:** charts and KPIs arranged as a bento grid with one hero chart.
- **AI Assistants Inbox / Tasks:** summary bento strip above the list.
- On phones every bento collapses into a single tidy column.

## 3. Light clean-up so it feels less generated
- Remove count-up numbers, stagger entrances and the corner "x" pattern on every card (kept on one featured tile per page).
- Remove icons from page titles; tiles use small icons only where useful.

## Not changing
Colors, data, menus, forms' AI quick fill, Focus dock.

## Technical details
- `__root.tsx`: Google Fonts link for Cormorant Garamond (400 to 700 + italic) and Karla; `styles.css`: `--font-serif`/`--font-sans` tokens, heading base styles, `.bento` grid utility (12-column, `grid-auto-rows`, span helpers, single column under `md`).
- `bits.tsx`: `PageHeader` renders italic tail via a `ItalicTail` helper replacing `BlueTail`; new `BentoTile` component; `StatCard` uses serif numbers.
- Rework `minggu-ini.tsx`, `board.tsx`, `report.tsx`, `tasks.tsx`, `asisten.tsx` layouts; trim `fun.tsx` usages.
- Verify in Playwright at 1280 and 375 widths.
