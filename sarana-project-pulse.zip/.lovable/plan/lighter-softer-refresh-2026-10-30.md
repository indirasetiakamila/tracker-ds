# Lighter, softer refresh

Keeps the current layout, blue accent, and green/amber/red status pills.

## Changes
1. **Background almost white**: the gray background becomes a very soft off-white (about #FAFAFA). Panels stay pure white with thin light borders so they still stand out.
2. **Font: Noto Sans** for everything. Headings use Noto Sans in heavy weight with tight letter spacing; body text uses the regular weight. Inter Tight and Instrument Sans are removed.
3. **Black areas become white**: the "This Week" banner, the black stat cards (Open, etc.), the sidebar "Principle" box and the sign-in panel turn white with dark text and blue accents. Any "featured" card gets a thin blue border instead of a black fill.
4. **Small "x" pattern on cards**: every card and panel gets a faint grid of tiny "x" marks (very light gray, a bit stronger in the corner and fading out) so cards look less plain. Header banners use a slightly stronger blue "x" field instead of the current dots.
5. **New illustrations to match the style**: replace the 5 drawings (team, all done, empty, busy, 404) with flat line drawings: thin black lines, blue highlights, white background, a few "x"/pixel accents. Same scenes, new look.
6. **Modern form fields** (inputs, dropdowns, search, the Admin team table):
   - Soft gray filled fields (no heavy outline, no shadow), 10px corners, 40px tall.
   - On focus: white background, blue border and a soft blue glow ring.
   - Dropdowns get a cleaner chevron; search gets a magnifier icon inside.
   - In the Admin team table, the name and job title look like plain text until you hover or click, so the table reads cleanly instead of a wall of boxes.
   - Tabs (Team / Access) become a slim segmented control with a white active pill.

## Technical details
- `src/styles.css`: update `--background`, `--card`, `--muted`, `--input`, `--ink` (now white surface) tokens; set `--font-sans` and `--font-serif` to "Noto Sans"; add `@utility x-field` (SVG data-URI of small x marks, masked fade) and apply via `card-soft` and shadcn `Card`; replace `pixel-field` usage with an x variant.
- `__root.tsx`: swap Google Fonts link to Noto Sans 400 to 900.
- `components/ui/input.tsx`, `select.tsx`, `textarea.tsx`, `tabs.tsx`: filled modern variant; add a `ghost` style for inline table editing used in `admin.tsx`.
- `bits.tsx` (stat cards, PageHeader), `AppShell.tsx` (principle box), `minggu-ini.tsx` (banner), `auth.tsx`: remove ink fills.
- Regenerate `src/assets/illustrations/*.png` in the new line-art style at the same paths.
- Update the Core design rule in memory (canvas off-white, Noto Sans, no black panels, x pattern).
