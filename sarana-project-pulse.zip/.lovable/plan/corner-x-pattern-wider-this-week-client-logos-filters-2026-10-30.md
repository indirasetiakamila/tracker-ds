# Corner x pattern, wider This Week, client logos, filters

## 1. Corner x pattern
- Cards no longer have the "x" marks everywhere. A small triangle of x marks sits in one top-right corner and fades out toward the middle.
- The marks are blue and semi-transparent (around 25%). Page headers get a slightly larger version of the same corner.

## 2. This Week width
- This Week will be as wide as Register and the other pages, so it fills the screen the same way.

## 3. Client logos
- Each project can have a client logo. On the project page, people who can edit the project see an "Upload logo" button (PNG, JPG or SVG, up to 2 MB). They can also replace or remove it.
- If there is no logo, a rounded square with the client's initials in a steady color is shown.
- The logo shows on project cards (This Week, Board), Register rows, Priorities, Standup, task lists, and the project page header.
- Projects for the same client share one logo, so uploading it once covers every project for that client.

## 4. Search and filters on This Week
- A filter bar above the cards: search box (client or use case), Health (Green/Yellow/Red), Stage, and PIC. Each has an "All" option, plus a "Clear" button.
- The counts in the banner stay as they are. Only the list below is filtered. If nothing matches, an empty-state picture with a "Clear filters" link is shown.
- Filters are saved in the page link, so refreshing keeps them.

## Technical details
- `styles.css`: replace the `card-soft` background and `pixel-field` with a corner x image: SVG x tile in `#1414F0` at about 0.25 opacity, masked with a `linear-gradient(225deg, black, transparent 35%)`, size around 140px, placed top right.
- `minggu-ini.tsx`: change `max-w-5xl` to the same container width as `register.tsx`. Add a filter bar using zod `validateSearch` (q, health, stage, pic as plain strings with fallback).
- Database: a new `client_logos` table (client text primary key, url, updated_at, updated_by). Grant select to signed-in users, and insert/update/delete to anyone who can edit projects (PIC, lead or admin, checked with `has_any_role`). Create a public `client-logos` storage bucket, with policies on its files that allow the same roles to write and anyone to read.
- `data.ts`: add a `useClientLogos()` query and realtime invalidation. Add a `ClientLogo` component in `bits.tsx` (logo image or initials). Upload controls go on `proyek.$id.tsx`.
