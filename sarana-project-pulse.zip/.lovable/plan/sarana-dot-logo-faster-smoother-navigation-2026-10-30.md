# Sarana dot logo + faster, smoother navigation

## 1. Dot pattern shaped like the Sarana logo
- Replace the round dot cloud on the sign-in page (and the blue pattern in page headers) with a halftone made of dots that forms the stacked-layers Sarana logo.
- Dots are denser/bigger on the logo lines and fade out around it, in the same electric blue, so it still reads as "dots" but you can see the logo.
- Subtle slow shimmer on load (respects reduced motion).

## 2. Logo in the app
- Use the uploaded Sarana icon next to the "Sarana" name in the top bar / sidebar and on the sign-in page (replacing the current plain mark in the corner).
- Set it as the browser tab icon too.

## 3. Instant page switching + loading animation
- Clicking "New project" (or any menu) switches immediately to the new page; no more staying on Board while waiting.
- While data loads, a thin blue progress bar runs across the top, and the page shows skeleton placeholders shaped like the content (cards, rows), never a frozen screen.
- Small Sarana-dot loader for longer waits (e.g. saving, uploads).
- Hovering a menu item or button preloads that page so most clicks feel instant.

## 4. Data load sturdiness
- Fetch only the columns each page needs, load shared lists (people, logos) once and reuse them.
- Add database indexes on the fields used for filtering/sorting (project stage, health, PIC, task project/status, week).
- Keep the optimistic updates from last round; also make "add priority" appear instantly.

## Technical details
- Generate the dot logo as an inline SVG: sample the uploaded PNG on a grid at build time into a dot map (`src/assets/sarana-dots.ts`), render via `SaranaDots` component; replaces `PixelField` usage in auth and `PageHeader`.
- Logo: upload via lovable-assets for in-app use; `public/favicon.png` (64x64) and update `__root.tsx`, remove `favicon.ico`.
- Router: `defaultPendingMs: 0`, `defaultPendingComponent` with skeleton, a global `NavProgress` bar using `useRouterState` (isLoading); remove awaits in loaders that block navigation for non-critical data (use `ensureQueryData` without blocking where safe, suspense skeletons in components).
- Migration: indexes on projects(stage, health, pic), tasks(project_id, status), priorities(week_start, owner).
- Verify with Playwright timing: Board -> New project click to new page render.
