# Pictures back, editorial Board, invite-only sign-in

## 1. Bring the pictures back
- Restore the line-art illustrations (team, done, empty, busy, lost) in the new editorial look: the This Week hero tile gets the team picture on the right; "All checked" state shows the done picture; empty lists, the Board's empty columns, Register empty results and 404 use empty/lost; AI fill and long loads use busy.
- Add two new matching drawings (same thin black line, blue fill, white ground): one for the Report header tile and one for the AI Assistants Inbox when nothing needs review.
- Pictures sit inside tiles as decoration (soft, partly cropped at an edge), never as full-width banners.

## 2. Board: elegant, not mainstream
Replace the standard kanban columns with an "editorial ledger" board:
- Header band: one row per stage as a slim timeline (Discovery to Live) with a large serif count, italic stage name and ARR underneath; the busiest stage gets the x-corner accent.
- Each stage is a horizontal lane (not a tall column): stage name in serif on the left margin, project cards flow right as compact index cards.
- Index card: client logo, client in serif, use case in small text, a thin health line on the left edge (green/amber/red), PIC initials, due date set in small caps, red only if late. No heavy shadows, hairline borders, generous whitespace.
- Lanes collapse/expand; empty lanes shrink to one line with a small illustration.
- Keep existing filters (Everyone / Only mine / PIC / Health) as quiet text chips above; add a "Compact / Detailed" toggle.
- Phones: lanes stack, cards scroll sideways inside each lane.

## 3. Sign-in: any email, but only if listed by admin
- Google sign-in no longer locked to @sarana.ai; anyone can pick their Google account.
- On sign-in, the account is allowed only if its email is on the admin Team list (active), or is one of the admin emails. Otherwise sign-in is refused with "This email isn't registered. Ask an admin to add you."
- Admin Team list and the "Add person" dialog accept any email (no more @sarana.ai check). Deactivating a person blocks their next sign-in.
- Sign-in page copy changes to "Registered team members only".

## Technical details
- `auth.tsx`: drop `hd: "sarana.ai"` extra param; update error copy.
- Migration: rewrite `handle_new_user` so the domain check becomes `exists (select 1 from public.people where lower(email)=lower(new.email) and active)` or admin email; link the person row to the new user as today. Also add a check for returning users: `_authenticated/route.tsx` calls a security-definer `is_registered()` RPC once per session and signs out + redirects to `/auth?denied=1` if false (covers deactivated people).
- Remove `@sarana.ai` validation in `admin.tsx` and `PersonSelect.tsx`; keep basic email format check.
- Test: `src/test/registered-login.test.ts` for the pure email-allow helper (listed allowed, unlisted refused, inactive refused, admin email allowed, case-insensitive).
- Board rewrite stays in `board.tsx`, using existing `stageSummary` from `rules.ts`; new illustrations via imagegen into `src/assets/illustrations/`.
- Update memory: sign-in rule changes from "@sarana.ai only" to "any Google email registered on the Team list".
