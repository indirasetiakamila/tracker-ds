# Switch the whole app to elegant English

All interface text moves from casual Bahasa Indonesia to refined, concise English. Data people type in (client names, next actions, descriptions, comments) stays as is.

## What changes
- **Navigation and page titles**: Minggu ini → This Week, Register, Board, Standup, Prioritas → Priorities, Engineering Tasks, Report, Asisten AI → AI Assistants, Admin. Page addresses stay the same so bookmarks keep working.
- **Every page**: headings, subtitles, buttons, labels, placeholders, empty states, tooltips, toasts, confirmation dialogs, validation messages, greeting ("Good evening, Indira"), sidebar quote, skeleton/loading text.
- **Forms**: New Project, New Task, project detail and task detail, including field hints, checklist items and stage gate messages.
- **Admin**: Team and Access tabs, titles (Engineer, PM, AM, PIC, Lead), role and PIC pickers.
- **Sign-in, consent and 404 pages**.
- **Dates**: day and month names in English (e.g. "Fri, 30 Oct"), still WIB, week still starts Monday, deadline Friday 17:00 WIB.
- **Rich text editor**: toolbar tooltips and placeholders in English.
- **AI assistant tools (Grok)**: replies and error messages in English; the ready-to-paste "message for Grok" in English.
- **Report and CSV export**: column headers in English.
- **Page tab titles and link previews**: English titles and descriptions.

## Tone
Short, polished, calm. Examples: "Nothing due this week. Enjoy the quiet." / "Next action is required" / "Project DS-012 created" / "Ball in court: Client". No em or en dashes, matching the existing rule.

## Not changed
- Anything users already typed, sample project data, stored values (stage names like Pipeline, POC are already English).
- Look and feel, layout, permissions.

## Technical details
- Edit literal strings in place across `src/routes/**`, `src/components/app/**`, `src/lib/rules.ts` (labels/messages only, logic untouched), `src/lib/mcp/**`, `src/lib/mcp-keys*`; switch date formatting locale from `id-ID` to `en-GB`.
- Update `rules.test.ts` / other tests only where they assert message strings.
- Update project memory: UI copy is elegant English (replacing the Bahasa Indonesia rule).
- Re-extract the MCP manifest after tool text changes; run tests and typecheck.
