# UI lebih hidup dan tidak kaku

## Arah visual
Tetap palet IK (wine, plum, powder, krem) dan font Cormorant + Karla. Yang berubah: nuansa lebih "buatan tangan", ada ilustrasi, gerak halus, dan sentuhan personal.

## Ilustrasi
- Set ilustrasi custom bergaya editorial (garis tangan, warna wine/powder/krem) dibuat khusus, bukan stok:
  - Halaman masuk: ilustrasi besar tim kerja bareng.
  - Header "Minggu ini": ilustrasi kecil berganti sesuai kondisi (semua beres, ada yang merah, hari Jumat deadline).
  - Empty state tiap halaman (Board kosong, tidak ada task, standup belum ada) dengan ilustrasi masing-masing, bukan cuma ikon.
  - Halaman 404 dan error dengan ilustrasi ramah.
- Bentuk organik (blob, garis lengkung, tekstur grain halus) di latar header dan pojok halaman supaya tidak terasa kotak-kotak.

## Sentuhan personal
- Sapaan sesuai jam WIB di "Minggu ini": "Pagi, Faiz", "Sore, Dhania", plus kalimat santai berganti-ganti ("Jumat nih, yuk beresin update").
- Kartu ringkasan dengan angka yang menghitung naik saat muncul, plus sparkline kecil.
- Avatar inisial dengan warna lembut berbeda per orang, ditumpuk di kartu proyek.
- Stiker/label miring kecil untuk hal spesial ("Go-Live!", "Telat").

## Animasi
- Transisi halus antar halaman (fade + geser sedikit).
- Daftar dan kartu muncul berurutan (stagger), bukan sekaligus.
- Konfeti kecil saat proyek naik stage ke Go-Live atau semua update minggu ini selesai.
- Tombol "Masih sama" ada animasi centang.
- Progress bar terisi beranimasi, pill status berdenyut pelan untuk Red.
- Ikon nav bergerak sedikit saat disentuh kursor.
- Skeleton loading dengan kilau, bukan teks "Memuat".

## Tata letak lebih santai
- Ukuran kartu tidak semua seragam di Minggu ini (kartu fokus lebih besar).
- Judul halaman dengan garis bawah coretan tangan di kata kunci.
- Sudut dan bayangan sedikit bervariasi, latar dengan grain halus.
- Sidebar dengan ilustrasi kecil dan kutipan/tips di bawahnya.

## Technical details
- Generate ~8 illustrations via imagegen (transparent PNG) into `src/assets/illustrations/`; reusable `Illustration` + upgraded `Empty` with `art` prop.
- framer-motion: route transition wrapper in AppShell around Outlet, `StaggerList`, `CountUp`, animated progress; `canvas-confetti` for celebrations (client-only dynamic import).
- New tokens in styles.css: grain texture utility, blob shapes, per-person avatar hues, `animate-pulse-soft`, shimmer skeleton.
- Greeting/quote helpers in a small pure module (WIB-based). No database changes; rules.ts untouched.
- Respect `prefers-reduced-motion`.
