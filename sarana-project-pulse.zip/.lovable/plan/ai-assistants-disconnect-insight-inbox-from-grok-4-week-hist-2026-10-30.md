# AI Assistants: disconnect, insight inbox from Grok, 4-week history

## 1. Disconnecting an assistant
- Today the "Revoke" button already cuts the assistant off instantly (its URL stops working). Make it clearer:
  - Rename to **Disconnect**, with a confirm dialog: "Grok will lose access immediately. You can connect again with a new key."
  - Each key card shows status: Connected (green, "last used 2h ago"), Never used, or Disconnected (grey, with date).
  - Disconnected keys fold into a "Disconnected" list so the active ones stay on top.
  - Short "How to disconnect in Grok too" note (remove the connector in Grok settings).

## 2. Insight inbox (Grok routine)
How it works:
```text
WhatsApp groups --> Grok routine (reads, summarises) --> sends to Sarana via your key
                                                     --> AI Assistants > Inbox (you review)
```
- New assistant ability: **send insight**. Grok sends one item at a time:
  - Type: Insight or Action
  - Title + detail (rich text), linked project (matched by client name or DS id), optional suggested owner and due date, source (e.g. "WA group BPR KS, 30 Oct"), confidence.
- New **Inbox** tab on the AI Assistants page, next to Keys:
  - Cards grouped by project, with Insight / Action badges and the source line.
  - Buttons per card:
    - **Apply**: for actions, opens a prefilled weekly update or new task for that project (reuses the quick-fill highlights); nothing saves until you confirm.
    - **Accept** (mark useful, keep), **Dismiss**, **Snooze to next week**.
  - Counter badge on the AI Assistants menu item for unreviewed items.
- Grok can also read back what you accepted/dismissed (so it stops repeating itself).
- The "Message for Grok" copy text gets a ready-made routine prompt: "Every weekday 17:00, read the WhatsApp updates, then call send_insight for each insight or action…".

## 3. History, 4 weeks, per week
- Inbox has week sections: This week, Last week, 2 weeks ago, 3 weeks ago (Monday to Sunday, WIB), each with counts (new / accepted / dismissed / applied).
- Reviewed items stay visible with their outcome and who reviewed them.
- Items older than 4 weeks are removed automatically each night.

## Technical details
- Table `assistant_insights`: id, created_at, created_by (key owner uid), key_id, kind ('insight' | 'action'), title, body_html, project_id (nullable), suggested_owner, suggested_due, source, confidence, status ('new' | 'accepted' | 'dismissed' | 'applied' | 'snoozed'), snoozed_until, reviewed_by, reviewed_at. RLS: signed-in team can read; insert only as self; PIC/lead/admin can update status. GRANTs per rules. Index on (created_at desc), (status).
- MCP tools in `src/lib/mcp/tools/`: `send_insight` (validates project id/client, dedupes same title+project within 24h), `list_insights` (last 4 weeks, with status). No delete tool. Same tool available on both `/mcp` and key URL.
- Retention: nightly SQL `pg_cron` job deleting rows older than 28 days (database-only, no HTTP).
- UI: `asisten.tsx` gets Tabs (Inbox / Keys); week grouping via a pure `weekBucket(date, today)` in `rules.ts` with tests; Apply navigates to `/proyek/$id` or `/tasks/baru` with prefill passed through search params into the existing forms.
- Realtime: add table to the existing app channel so new insights appear live.
- Verify: send an insight with a test key via the MCP endpoint, see it in the Inbox, accept/dismiss/apply, disconnect the key and confirm the URL returns unauthorized.
