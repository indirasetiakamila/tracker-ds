# Make the app feel instant

## What causes the delay (found in the code)
1. **Every menu click checks your sign-in with the server first.** The page waits for that round trip before it starts loading.
2. **Page switch animation waits for the old page to fade out** before the new one appears, which adds about a quarter second to every click.
3. **Data is treated as out of date immediately**, so every page you open reloads all of its projects, tasks and to-dos from the server, even if you just saw them.
4. **"Who am I" is asked of the server again in many places** (each card and button). Until the answer arrives, you briefly count as a non-editor, which can hide or disable buttons for a moment.
5. **Changing a status, ticking a priority or reordering waits for the server, then reloads the whole list** before the screen changes. A move up or down is two separate saves in a row, and "carry over" saves one item at a time.

## Fixes
- Check sign-in from the session already saved in the browser (no server trip per click). The server still checks every request, so security stays the same.
- New page appears right away with a short fade-in; no waiting for the old page to leave.
- Keep loaded data fresh for 30 seconds and don't reload when you switch back to the tab. Live updates from teammates still refresh it right away.
- Start loading a page's data when you hover over its menu item, so it is ready when you click.
- Read "who am I" once from the saved session and share it everywhere.
- **Instant changes:** the screen updates the moment you click (task status and drag on Engineering tasks, priority tick/edit/delete/reorder/carry-over, project weekly check and status fields). If the save fails, the change is reverted with an error message.
- Reorder and carry-over save all items in one go instead of one by one.
- Afterwards, check This Week, Priorities and Engineering tasks in the browser, timing a status change and a menu switch, and confirm nothing reloads unnecessarily.

## Technical details
- `_authenticated/route.tsx`: `getSession()` instead of `getUser()` in `beforeLoad`.
- `AppShell.tsx`: remove `AnimatePresence mode="wait"`; keep a keyed `motion.div` with an enter-only fade (0.15s).
- `router.tsx`: `QueryClient` defaults `staleTime: 30_000`, `refetchOnWindowFocus: false`; `defaultPreload: "intent"`.
- `data.ts`: `useUserId` backed by a shared `["session"]` query (from `getSession`, updated on auth change); add a `useOptimistic(table, key)` helper built on `useMutation` with `onMutate` (`setQueryData`), `onError` rollback, and `onSettled` invalidate.
- Apply to `prioritas.tsx` (add/update/delete/swap/carry; swap and carry as one `upsert` of rows), `tasks.index.tsx` (status change/drag), `tasks.$key.tsx` (patch), `ProjectCard`/`proyek.$id.tsx` (`updateProject`, mark unchanged).
- Realtime: skip the invalidation echo for a change the user just made (it is already on screen) to avoid a flicker.
