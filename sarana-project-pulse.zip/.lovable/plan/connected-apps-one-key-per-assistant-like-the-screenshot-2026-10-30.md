# Connected apps: one key per assistant, like the screenshot

## What you'll see
A new **Connected apps** card on your profile page (and a menu link to it):
- Type a name ("Grok") and click **Buat kunci**.
- Once, and only once, you see:
  - **MCP server URL** with the key already in it, plus a copy button
  - **Pesan buat Grok**: "Add a custom MCP server called Sarana at …", plus a copy button
  - A folded **"Untuk app yang pakai URL + header"** section showing the plain `/mcp` URL and the `Authorization: Bearer …` header
- A list of your keys: name, when it was made, when it was last used, and a **Cabut** button. A revoked key stops working right away.
- A warning in plain words: anyone holding the URL can read and fill the register as you, and whatever it reads is sent to the assistant's company.

Grok can do what it does today: read projects, tasks and people, create projects and tasks, fill in weekly updates and change task status. It can't delete anything.

## Safety rules
- Only a fingerprint of the key is stored, never the key itself, so even the database can't show it again.
- Each key belongs to one person and acts with exactly that person's permissions (PIC, engineer, admin and so on). Revoked or deactivated accounts stop working.
- The Google login option for assistants stays, so either way works.

## Technical details
- New table `mcp_keys` (id, user_id, name, key_hash sha-256, created_at, last_used_at, revoked_at). RLS: owners can select and revoke their own keys. Inserts go only through a function.
- Key format `srn_<random 32 bytes base64url>`, generated on the server inside a `createServerFn` behind `requireSupabaseAuth`. Only the hash is saved; the plain key is returned once.
- Endpoint: in the MCP SDK, check for a custom bearer verifier. Accept either an OAuth token (current behavior) or a `srn_` key, sent either in the path `/mcp/<key>` or as a Bearer header. If the generated route can't take a path segment, add a small server route `src/routes/api/public/mcp.$key.ts` that moves the key into the Authorization header and forwards the request to the same MCP handler.
- No service-role key. Calls made with a key go through `SECURITY DEFINER` database functions (`mcp_key_user(hash)`, plus one function per tool: list/get/create/update). Each function resolves the user from the hash, rejects revoked keys, re-applies the same permission checks the RLS policies use (`has_role` / `has_any_role` / ownership), and updates `last_used_at`. The tools call these through a publishable-key client. OAuth calls keep using `supabaseForUser`.
- Activity triggers still record who made each change: the functions set the acting user for the triggers.
- Re-extract the MCP manifest, add tests for key hashing/revocation rules, and update AGENTS.md (MCP auth rule).
- Verify: create a key in the UI, call `list_projects` and `create_task` with curl through the key URL, revoke it, and confirm the next call gets 401.
